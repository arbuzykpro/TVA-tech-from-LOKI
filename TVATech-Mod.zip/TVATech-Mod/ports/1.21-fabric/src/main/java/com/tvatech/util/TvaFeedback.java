package com.tvatech.util;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.server.level.ServerPlayer;

/**
 * Sending text to players.
 *
 * <p>{@code Player#displayClientMessage} no longer exists in this Minecraft
 * version, so action-bar lines are sent as the vanilla packet instead and chat
 * lines go through the regular system-message path.</p>
 */
public final class TvaFeedback {

    private TvaFeedback() {}

    /** Briefly shown above the hotbar. */
    public static void actionBar(ServerPlayer player, Component message) {
        if (player.connection != null) {
            player.connection.send(new ClientboundSetActionBarTextPacket(message));
        }
    }

    /** Permanent chat line. */
    public static void chat(ServerPlayer player, Component message) {
        player.sendSystemMessage(message);
    }
}