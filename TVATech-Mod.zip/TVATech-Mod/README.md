# TVA Tech — Marvel's *Loki* tech for Minecraft

A **Forge mod for Minecraft 26.3 / Forge 66.0.12** that brings the Time Variance
Authority's gear into your world: the **TemPad**, the **Mobius Mobile**, the
glowing **Time Door**, **Arc Reactors**, **variant scanning** and **pruning**.

Built against the newest Minecraft release (26.3) using Mojang mappings and the
modern Forge 66.x event system.

---

## The gadgets

| Item / Block | What it does |
|---|---|
| **TemPad** | Right-click to open the **temporal atlas**: pick a saved mark, optionally dial in a day and time of day, and jump. Each jump costs charge, bumps your **variant number** and logs to your timeline. |
| **Mobius Mobile** | Right-click to open the in-game phone GUI: chrono-lock, variant scan, timeline log and the "time of death" anchor. |
| **Variant Scanner** | Tags any living thing with a variant number (e.g. *#1442*) and reads it back. |
| **Chrono Battery** | Hold a TemPad or Mobius Mobile in one hand and a battery in the other, then **sneak + right-click** a block to charge it (+2 per battery). Charging never steals an ordinary right-click, so you can still place and break blocks while carrying one. |
| **TVA Time Door** | The glowing amber portal frame. Right-click it with a TemPad to open the atlas; bare-hand right-click toggles it open/closed (light + particles). |
| **Arc Reactor** | Light source, powers the Mobius Mobile's chrono-lock, and acts as a **free charging station** — sneak-right-click it while holding a gadget to top it up without spending a battery. |
| **Chronovium Ingot / Block** | The alloy everything TVA is built from. |
| **TVA Terminal / Terminal Bank / Console** | Office furniture: amber data screens and desks, for building the Vault. They glow faintly. |
| **TVA Field Manual** | A real written book, 31 pages of the Authority's standing orders. Right-click to read it. |

### The TVA

Put the arrival dial on **day -1** (press `-` at day 0) and travel. You arrive
in the lobby of the Time Variance Authority, which is a real dimension
(`tvatech:tva`) — not an island, not a fake place. It is enclosed, it has no sky
light, and it is sealed.

**The Vault**, built once the first time anyone goes:

- **Five floors** around a full-height atrium, with a brass compass rose set
  into the lobby floor and amber window panels running the whole height.
- **Cubicles** on every floor with TVA Terminals on the desks.
- A **cafeteria** on the second floor and a **records hall** packed with
  bookshelves.
- A **reception desk** under a lit TVA sign.
- Underneath it all, the **sub-basement**: one plain room, one pedestal, and the
  reset lever.

**You cannot walk out.** The walls are solid, there is no opening anywhere, and
the world border is pulled in tight around the building. There is no way out on
foot, by boat, by tunnel or by flight — the only way out is a TemPad, which is
the entire premise of the place. Open the TemPad anywhere in the TVA and press
TRAVEL to be brought back to exactly where you stood.

**Six framed diagrams** hang in the atrium: the Authority's mark, a plan of the
ground floor, the TemPad from above, the reset lever in section, a timeline, and
the motto.

```
# TVA Tech — Marvel's *Loki* tech for Minecraft

A **Forge mod for Minecraft 26.3 / Forge 66.0.12** that brings the Time Variance
Authority's gear into your world: the **TemPad**, the **Mobius Mobile**, the
glowing **Time Door**, **Arc Reactors**, **variant scanning** and **pruning**.

Built against the newest Minecraft release (26.3) using Mojang mappings and the
modern Forge 66.x event system.

---

## The gadgets

| Item / Block | What it does |
|---|---|
| **TemPad** | Right-click to open the **temporal atlas**: pick a saved mark, optionally dial in a day and time of day, and jump. Each jump costs charge, bumps your **variant number** and logs to your timeline. |
| **Mobius Mobile** | Right-click to open the in-game phone GUI: chrono-lock, variant scan, timeline log and the "time of death" anchor. |
| **Variant Scanner** | Tags any living thing with a variant number (e.g. *#1442*) and reads it back. |
| **Chrono Battery** | Hold a TemPad or Mobius Mobile in one hand and a battery in the other, then **sneak + right-click** a block to charge it (+2 per battery). Charging never steals an ordinary right-click, so you can still place and break blocks while carrying one. |
| **TVA Time Door** | The glowing amber portal frame. Right-click it with a TemPad to open the atlas; bare-hand right-click toggles it open/closed (light + particles). |
| **Arc Reactor** | Light source, powers the Mobius Mobile's chrono-lock, and acts as a **free charging station** — sneak-right-click it while holding a gadget to top it up without spending a battery. |
| **Chronovium Ingot / Block** | The alloy everything TVA is built from. |
| **TVA Terminal / Terminal Bank / Console** | Office furniture: amber data screens and desks, for building the Vault. They glow faintly. |
| **TVA Field Manual** | A real written book, 31 pages of the Authority's standing orders. Right-click to read it. |

### The temporal atlas (TemPad menu)

Right-clicking with the TemPad anywhere — including a Time Door — opens the
menu instead of jumping immediately:

| Control | Effect |
|---|---|
| **Mark list** | Click a row to select it. Each row shows the mark's name and the day and hour it was made; the box below shows its coordinates and dimension. |
| **MARK HERE** | Drops a new mark at your current position. Up to 12 are kept; the oldest is dropped. |
| **DELETE** | Removes the selected mark. |
| **ARRIVAL TIME / PRESENT** | Toggles between arriving *now* (leaving the clock alone) and arriving at a chosen moment. The day and time dials are locked while in PRESENT. |
| **DAY `−` `+`** | Steps the world day (shown 1-based, so "day 1" is the first day of the world). |
| **TIME `−` `+`** | Steps the time of day by one hour in 12-hour form (e.g. `2:30 PM`). Greyed out while in PRESENT mode. |
| **TRAVEL** | Sets the world clock if you picked a time, then plays the portal jump to the selected mark. |
| **CLOSE** | Closes the menu. |

Sneak + right-click with the TemPad drops a mark where you stand without
opening the menu. Marks are stored on the player, so they survive losing the
gadget.

### Pruning
Right-click a living thing with a **TemPad** and it is removed from the
timeline: no drops, no experience, no corpse — just a burst of temporal
particles. Prune your variant counter with every prune.

### The time jump
Jumping is a three-beat animation, not a blink:

1. **Opening** — a time door assembles in front of you out of portal
   particles while the TemPad arms itself (charging chirp, then the portal
   tears open).
2. **Collapse** — the door implodes with a deep whoosh and you step through.
3. **Arrival** — the door rebuilds on the other side and fades out.

### Your builds are still there
The world remembers what it looked like at **every hour**. Build three blocks
up on day 3 at 10 am, smash them at 2 pm the same day, then jump back to 10 am -
and they are standing again. Set the clock to 2 pm and they are gone.

**Dropped items** work the same way: drop a stack of emeralds at 10 am, pick
them up at 2 pm, and going back to 10 am puts the stack back on the ground -
same place, same amount.

**Storage** keeps its own history too. Chests, barrels, shulker boxes and every
other container are recorded as you use them: put diamonds in at 10 am, empty
them at 2 pm, and the 10 am chest still has the diamonds.

How it works: every change is filed as one record - *which hour, what it was, what it became*. Landing on an hour rebuilds the world from those records. Records are keyed by a running count of world hours, so day 1 at midnight is hour 24. Only places somebody actually touched are stored, and a chunk is rebuilt the moment it loads, so builds far away come back correctly too.

Changes that no place/break event reports - fire spreading, leaves decaying,
pistons, fluids, other mods - are picked up by a periodic sweep
(`timelineSweepTicks`).

Two things worth knowing:

* A storage block starts being remembered the first time you **use** it. A
  chest you never open, that only a hopper feeds, is picked up whenever the
  sweep notices its contents changed, which can be a moment later.
* The clock is always set to a whole hour - the dial has no minutes - so every
  arrival lands on the hour.

Charge is spent the moment you trigger a jump; the variant bump and the
timeline entry happen when you land. If you log out, die or change dimension
mid-jump the animation is cancelled, so nobody is ever stranded. A jump also
has a **30 % chance of leaving you nauseous** for 15 seconds (see
`nauseaChance`).

The doorway itself is a **timedoor**: a real 3x4 doorway built out of real
blocks a few paces in front of you. It is 12 blocks of animated amber energy
field — eight hand-drawn swirl frames cycled twice a second, so the surface
really ripples — inside a chronovium surround. It takes a quarter of a second
to draw itself in from the middle outwards.

**Pressing TRAVEL does not move you.** It opens the door and leaves it standing
for ten seconds. Walk into it and you travel; do nothing and it closes itself
again, falling apart from the edges inwards with a puff of light off each block.
It closes early if you log out, die, or travel somewhere else first, and if
there is no clear space in front of you it skips the door and travels outright —
being unable to open a doorway is not a reason to be stranded.

Set `travelAnimationTicks = 0` in the config for instant teleports.

### The Mobius Mobile screen
| Button | Effect |
|---|---|
| **CHRONO-LOCK** | Freezes every mob in the configured radius for the configured duration (needs an Arc Reactor in range by default). Frozen mobs keep their timer through chunk unloading and are always released — including if you log out. |
| **SCAN VARIANT** | Reads the variant number of whatever you're looking at. |
| **TIMELINE** | Prints your personal timeline log in chat. |
| **SET ANCHOR** | Sets a "time of death" respawn point. If you die with an anchor set, you return to that spot instead of your bed — the TVA reset-button experience. |
| **CLOSE** | Closes the phone. |

---

## How to use it

1. Drop `tvatech-1.5.0.jar` into your `mods` folder (client + server, Forge 66.0.12+).
2. Craft an **Arc Reactor** (diamond + sea lantern + amethyst), then the **TemPad**
   (arc reactor surrounded by amethyst shards and glass panes).
4. **Charge it**: hold a Chrono Battery in the other hand and **sneak + right-click** any block (or sneak-right-click an Arc Reactor to charge for free).
   block (or sneak-right-click an Arc Reactor to charge for free).
4. **Right-click with the TemPad** to open the temporal atlas. Press **MARK HERE**
   where you are, walk somewhere else, open it again and press **TRAVEL**.

Everything else is in the creative tab **TVA Tech**.

## Configuration

`config/tvatech-common.toml` — all of it is live-reloadable:

| Key | Default | Meaning |
|---|---|---|
| `allowPruning` | `true` | Let players prune living things (disable for family servers). |
| `allowTemporalHop` | `true` | Allow TemPad jumps. |
| `shiftWorldTime` | `true` | Time jumps move the world clock when you did **not** pick a time yourself. |
| `timeShiftHours` | `6` | Max hours the clock may jump per jump. |
| `travelAnimationTicks` | `30` | Length of the portal animation. `0` = instant teleport. |
| `nauseaChance` | `0.3` | Chance (0-1) a jump leaves you nauseous. |
| `nauseaDurationTicks` | `300` | How long the nausea lasts. |
| `timelineBlocks` | `true` | Remember block changes per day so the past keeps your builds. |
| `timelineSweepTicks` | `40` | How often to catch changes no event reported. `0` disables the sweep. |
| `timelineMaxEntries` | `200000` | Cap on remembered block positions. `0` = unlimited. |
| `tempadMaxCharge` | `5` | Charge capacity of a gadget. |
| `hopCost` | `1` | Charge per jump. |
| `hopCooldownTicks` | `20` | Delay between jumps. |
| `batteryCharge` | `2` | Charge restored by one Chrono Battery. |
| `freezeRadius` | `8` | Chrono-lock radius. |
| `freezeDurationTicks` | `200` | How long the lock holds. |
| `freezeCooldownTicks` | `400` | Chrono-lock cooldown. |
| `freezeCost` | `2` | Charge per chrono-lock. |
| `freezeRequiresReactor` | `true` | Require an Arc Reactor in range. |
| `reactorRange` | `12` | How far a reactor can power your phone. |
| `timelineLogSize` | `12` | Timeline entries kept. |
| `announceTimeline` | `false` | Broadcast jumps to the whole server. |

---

## Admin commands

`/tva …` (gamemaster permission):

```
/tva give <tempad|mobile|scanner|battery|reactor|door|ingot|block> [count]
/tva pin [x y z]        pin your position (or explicit coords) on the held TemPad
/tva hop                force a jump (recharges and clears the cooldown first)
/tva info               variant, charge, pin state, timeline length, reactor status
/tva variant [n]        show or set your variant number
/tva prune              prune the nearest mob
/tva scan               read the variant of whatever you are looking at
/tva freeze [r] [ticks] chrono-lock
/tva anchor             set / clear the time-of-death anchor
/tva timeline           print the timeline log
```

---

## Building from source

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1 build        # jar -> build/libs
powershell -ExecutionPolicy Bypass -File build.ps1 runClient    # dev client
powershell -ExecutionPolicy Bypass -File build.ps1 runServer    # dev server
powershell -ExecutionPolicy Bypass -File build.ps1 clean        # clean (add --all to nuke the MC cache)
```

`build.ps1` mirrors the sources into `%LOCALAPPDATA%\Temp\opencode\mc-build`
before running Gradle. This is deliberate: ForgeGradle forks a JVM that receives
absolute project paths as command-line arguments, and Windows decodes those with
the system ANSI code page — which cannot represent this repository's folder
name, so an in-place build fails with `?????????` paths.

### Requirements

* **JDK 25** — Minecraft 26.3 ships with Java 25, and ForgeGradle needs a
  matching toolchain. Gradle auto-detects one in `~/.gradle/jdks`.
* Gradle 9.7.1 via the bundled wrapper.

### Other Minecraft versions

The mod is not source-portable: each Minecraft version has its own source set
under `ports/`, and `Tools/targets.ps1` is the single list of what exists.

```powershell
powershell -ExecutionPolicy Bypass -File Tools\targets.ps1 list        # the matrix
powershell -ExecutionPolicy Bypass -File Tools\targets.ps1 build 1.21.1-fabric
powershell -ExecutionPolicy Bypass -File Tools\targets.ps1 build all   # every ported target
```

Finished jars are copied to `build/libs/<minecraft version> <loader>/`.

| Target | Jar | Notes |
| ------ | --- | ----- |
| 26.3 Forge | `TVA_tech_26.3_2.1.0.jar` | JDK 25, Forge 66.0.12 |
| 26.3 Fabric | `TVA_tech_26.3_fabric-2.1.0.jar` | JDK 25, identity mappings — 26.3 ships deobfuscated, so there are no Mojang mappings to apply |
| 1.21.1 Fabric | `TVA_tech_1.21.1_fabric-2.1.0.jar` | JDK 21, Loom 1.9.2, official Mojang mappings, loader 0.16.9, Fabric API 0.115.1+1.21.1 |
| 1.21 Fabric | `TVA_tech_1.21_fabric-2.1.0.jar` | Same source as the 1.21.1 port, Fabric API 0.102.0+1.21 |

Remaining targets (`1.20.1` Forge/Fabric, `1.21` Forge and `1.21.1` Forge) are
scaffolded but have no ported source yet. 1.20.1 needs JDK 17, which is not
installed on this machine.

Ports build from their own directory, so stage the `ports/<target>` folder to an
ASCII path before running `gradlew.bat` (same Windows path problem as above).

The self-test runs on every delivered build: a real dedicated server of the exact
version (Forge 26.3, Fabric 26.3, Fabric 1.21, Fabric 1.21.1) is started with
`-Dtva.selftest=true` and must report 80/80 passing before a jar is shipped.

### Textures

All textures are generated procedurally, no external art:

```powershell
powershell -ExecutionPolicy Bypass -File Tools\generate_textures.ps1
```

---

## Self-test

`gradlew runServer` is configured with `-Dtva.selftest=true`, so the dev server
verifies the core logic on startup and logs the result:

```
[tva.TvaSelfTest] [PASS] tempad pin survives a stack copy
[tva.TvaSelfTest] [PASS] charge clamps to the configured maximum
[tva.TvaSelfTest] [PASS] chrono battery adds charge
[tva.TvaSelfTest] [PASS] world is loaded and blocks resolve
[tva.TvaSelfTest] [PASS] gadgets are registered in the item registry
[tva.TvaSelfTest] [PASS] network channel registered during mod load
[tva.TvaSelfTest] [PASS] time jump starts
[tva.TvaSelfTest] [PASS] charge is spent when the jump starts
[tva.TvaSelfTest] [PASS] the player has not moved yet
[tva.TvaSelfTest] [PASS] the portal animation lands the player
[tva.TvaSelfTest] [PASS] the variant bumps on arrival
[tva.TvaSelfTest] [PASS] the jump is no longer pending
[tva.TvaSelfTest] [PASS] variant numbers persist on entities
[tva.TvaSelfTest] [PASS] pruning removes the entity without drops
[tva.TvaSelfTest] [PASS] arrival day is applied to the world clock
[tva.TvaSelfTest] [PASS] arrival time of day is applied to the world clock
[tva.TvaSelfTest] [PASS] midnight (tick 0) reads back as 06:00
[tva.TvaSelfTest] [PASS] a mark is saved where the player stands
[tva.TvaSelfTest] [PASS] marks are named for the atlas list
[tva.TvaSelfTest] [PASS] the mark list is capped
[tva.TvaSelfTest] [PASS] a mark can be deleted
```

The network check exists because of a real bug: the channel used to be built
lazily the first time a player opened the phone, which crashed the game with
"registry phase is over". The jump checks exist because the animation is
time-based and therefore easy to break without noticing. The clock checks
exist because 26.x replaced `Level#setDayTime` with a world-clock system, and
the first implementation silently did nothing.

Set `tva.selftest` to `false` (or delete the line in `build.gradle`) to skip it.

### GUI preview

To eyeball the TemPad menu without a server or a world, launch the dev client
with the environment variable `TVA_SHOWMENU=1` — it opens the atlas with sample
marks at the main menu.

---

## Layout

```
TVATech-Mod/
├─ build.ps1                 build wrapper (mirrors sources to an ASCII path first)
├─ Tools/generate_textures.ps1
└─ src/main/
   ├─ java/com/tvatech/
   │  ├─ TVATech.java            mod entry point, registration, creative tabs
   │  ├─ TvaConfig.java          every tunable
   │  ├─ TvaMessages.java        all player-facing text
   │  ├─ ModContent.java         blocks / items / creative tab
   │  ├─ block/                  TimeDoorBlock, ArcReactorBlock, ChronoviumBlock
   │  ├─ client/                 MobileScreen, TempadMenuScreen, client entry point
   │  ├─ command/                /tva
   │  ├─ event/                  interactions, ticks, respawns, commands
   │  ├─ item/                   gadget items and tooltips
   │  ├─ network/                SimpleChannel + payloads
    |  |- system/                 TimeTravel, TemPadMenu, TvaMarks, WorldTime,
    |  |                          Timeline, TimelineObjects, TimelineItems, Pruning,
   │  └─ util/                   NBT helpers, feedback, entity names
   └─ resources/
      ├─ META-INF/mods.toml
      └─ assets|tvatech + data/tvatech
```

## Notes

* Uses Mojang official mappings (the default on Forge for 26.x), so class names
  match the vanilla names you see in-game.
* Client classes are **not** annotated `@OnlyIn`: Forge 26.x throws
  `UnsupportedOperationException` as soon as such a class loads. They are only
  reached from client-side code paths, which is enough.
* Gadget state (charge, last destination) lives in the stack's
  `minecraft:custom_data` component, so it survives crafting and dropping.
* Marks, variant numbers, timeline logs and anchors live in Forge's persistent
  entity data, so they are written to the player's save automatically.
* The block timeline is world data, not player data: one saved-data file per
  dimension (`data/tvatech/timeline.dat`), stored as block registry ids.
* The world clock is written through the 26.x clock API
  (`ServerClockManager#setTotalTicks`); the old `/time` command no longer
  exists in the form this mod needs.
* Sounds and particles are vanilla ones — no custom audio assets needed.
* Both GUIs were built against the new 26.x render API
  (`extractRenderState` / `GuiGraphicsExtractor`) and verified in the dev client
  with `TVA_SHOWMENU=1`; button feel in-game is still worth a sanity check on
  your resolution.
## Crafting

Everything is craftable at a normal crafting table. The progression runs
**chronovium -> power -> gadgets -> furniture**, so nothing needs a late-game
material except redstone. No netherite, no ender pearls.

### Chronovium Ingot (x4) - the base alloy

```
I C I      I = Iron Ingot
C A C      C = Copper Ingot
I C I      A = Amethyst Shard
```

Nine ingots make a Block of Chronovium; one block unpacks back into nine.

### Arc Reactor - power

```
I C I      I = Iron Ingot
C A C      C = Chronovium Ingot
C R C      A = Amethyst Shard    R = Block of Redstone
```

Gadgets need somewhere to stand and something to draw on. This is both at once:
plug it in and they all work.

### Chrono Battery (x2) - portable charge

```
  A          A = Amethyst Shard
C R C        C = Chronovium Ingot
  A          R = Redstone Dust
```

### Variant Scanner

```
G C G        G = Glass
C M C        C = Chronovium Ingot
  R          M = Comparator     R = Redstone Dust
```

### Mobius Mobile

```
C A C        C = Chronovium Ingot
S R S        A = Amethyst Shard
C A C        S = Variant Scanner  R = Arc Reactor
```

### TemPad

```
G C G        G = Glass
C R C        C = Chronovium Ingot
G C G        R = Arc Reactor
```

### TVA Time Door (x2)

```
C A C        C = Chronovium Ingot
A O A        A = Amethyst Shard   O = Orange Stained Glass
C A C
```

### TVA Field Manual

```
P L P        P = Paper
O O O        L = Leather         O = Orange Dye
P I P        I = Ink Sac
```

### TVA Terminal (x4)

```
Q Q Q        Q = Quartz Block
Q O Q        O = Orange Stained Glass
  R          R = Redstone Dust
```

### TVA Terminal Bank (x2)

```
Q Q Q        Q = Quartz Block
Q O Q        O = Orange Stained Glass
Q I Q        I = Iron Ingot
```

### TVA Console (x2)

```
O O O        O = Orange Stained Glass
I I I        I = Iron Ingot
S S S        S = Smooth Quartz Slab
```
