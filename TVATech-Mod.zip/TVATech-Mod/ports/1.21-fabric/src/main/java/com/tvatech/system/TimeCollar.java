package com.tvatech.system;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.tvatech.ModContent;
import com.tvatech.util.TvaData;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Time collars: wearable leashes on other people's timelines.
 *
 * <p>An agent clamps one on a player or a mob by right-clicking them with it
 * - and the collar refuses to close on the agent's own neck. It remembers
 * who put it there, and only that agent can take it back off, with a sneak
 * right-click on the collared creature.</p>
 *
 * <p>The point of a collar is the remote: with a Time Collar Remote in hand,
 * right-click a collared creature and its last five seconds are rolled back
 * - it blinks out of where it stands and pops back where it was standing
 * five seconds ago.</p>
 *
 * <p>To make that possible the collar keeps history while it is worn: every
 * server tick a collared creature's spot is filed away, and anything older
 * than the rewind window is quietly shredded.</p>
 */
public final class TimeCollar {

    private TimeCollar() {}

    /** How far back a rewind reaches: five seconds of ticks. */
    public static final int TICKS_BACK = 100;

    /** One remembered spot: which level, where, which way it faced, when. */
    private record Snap(long tick, ServerLevel level, double x, double y, double z,
                        float yaw, float pitch) {}

    /** Which dimension each collared creature was last seen in. */
    private static final Map<UUID, ServerLevel> COLLARED = new HashMap<>();
    private static final Map<UUID, ArrayDeque<Snap>> HISTORY = new HashMap<>();

    /** Rolling server tick counter, stamped onto every snapshot. */
    private static long now;

    // ------------------------------------------------------------------
    // Putting one on and taking one off
    // ------------------------------------------------------------------

    /**
     * Clamps a collar onto {@code target}.
     *
     * <p>Returns false (and does nothing) when the target already wears
     * someone else's collar, or when the agent tries it on itself.
     * Re-clamping your own collar on is fine - it just snaps tight again.</p>
     */
    public static boolean put(Entity target, UUID placer) {
        if (!(target instanceof LivingEntity) || target.getUUID().equals(placer)) {
            return false;
        }
        UUID holder = TvaData.collarPlacer(target);
        if (holder != null && !holder.equals(placer)) {
            return false;
        }
        boolean fresh = holder == null;
        TvaData.setCollar(target, placer);
        if (fresh && target.level() instanceof ServerLevel level) {
            COLLARED.put(target.getUUID(), level);
            HISTORY.put(target.getUUID(), new ArrayDeque<>());
            level.sendParticles(ParticleTypes.PORTAL,
                    target.getX(), target.getY() + target.getBbHeight() * 0.8, target.getZ(),
                    12, 0.25, 0.3, 0.25, 0.04);
            level.playSound(null, target.blockPosition(), SoundEvents.CHAIN_BREAK,
                    SoundSource.PLAYERS, 0.8F, 1.3F);
        }
        return true;
    }

    /**
     * Takes the collar back off - only works when {@code placer} is the one
     * who clamped it on. The item pops out of the creature.
     */
    public static boolean remove(Entity target, UUID placer) {
        if (!wearingFor(target, placer)) {
            return false;
        }
        TvaData.clearCollar(target);
        forget(target.getUUID());
        if (target.level() instanceof ServerLevel level) {
            ItemEntity drop = new ItemEntity(level, target.getX(),
                    target.getY() + 0.6, target.getZ(),
                    new ItemStack(ModContent.TIME_COLLAR.get()));
            drop.setPickUpDelay(10);
            level.addFreshEntity(drop);
            level.sendParticles(ParticleTypes.PORTAL,
                    target.getX(), target.getY() + target.getBbHeight() * 0.8, target.getZ(),
                    12, 0.25, 0.3, 0.25, 0.04);
            level.playSound(null, target.blockPosition(), SoundEvents.ITEM_PICKUP,
                    SoundSource.PLAYERS, 0.8F, 0.7F);
        }
        return true;
    }

    /**
     * The wearer died: the collar pops off and lies where they fell, so
     * death no longer swallows the item. Returns true when a collar
     * actually came off.
     */
    public static boolean dropOnDeath(Entity target) {
        if (TvaData.collarPlacer(target) == null) {
            return false;
        }
        TvaData.clearCollar(target);
        forget(target.getUUID());
        if (target.level() instanceof ServerLevel level) {
            ItemEntity drop = new ItemEntity(level, target.getX(),
                    target.getY() + 0.4, target.getZ(),
                    new ItemStack(ModContent.TIME_COLLAR.get()));
            drop.setPickUpDelay(10);
            level.addFreshEntity(drop);
        }
        return true;
    }

    /** Is this creature wearing a collar this agent put on? */
    public static boolean wearingFor(Entity target, UUID placer) {
        if (!(target instanceof LivingEntity)) {
            return false;
        }
        UUID holder = TvaData.collarPlacer(target);
        return holder != null && holder.equals(placer);
    }

    // ------------------------------------------------------------------
    // History and the rewind
    // ------------------------------------------------------------------

    /** Called once per server tick: files collared creatures' positions. */
    public static void tick(MinecraftServer server) {
        now++;
        if (COLLARED.isEmpty()) {
            return;
        }
        for (Map.Entry<UUID, ServerLevel> line : new ArrayList<>(COLLARED.entrySet())) {
            Entity worn = find(line.getValue(), line.getKey());
            if (worn == null) {
                // Left play, died or fell out of tracking: the trail is gone.
                forget(line.getKey());
                continue;
            }
            ArrayDeque<Snap> snaps = HISTORY.computeIfAbsent(line.getKey(), k -> new ArrayDeque<>());
            snaps.addLast(new Snap(now, (ServerLevel) worn.level(),
                    worn.getX(), worn.getY(), worn.getZ(), worn.getYRot(), worn.getXRot()));
            // The buffer only needs to remember the rewind window plus slack.
            while (!snaps.isEmpty() && now - snaps.peekFirst().tick() > TICKS_BACK + 40) {
                snaps.removeFirst();
            }

            // A collar is visible: a quiet arc of sparks at the neck.
            if (now % 30 == 0 && worn.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.PORTAL,
                        worn.getX(), worn.getY() + worn.getBbHeight() * 0.85, worn.getZ(),
                        3, 0.25, 0.1, 0.25, 0.02);
            }
        }
    }

    /** Looks up an entity, trying other dimensions if its level lost track. */
    private static Entity find(ServerLevel level, UUID who) {
        Entity entity = level.getEntity(who);
        if (entity != null) {
            return entity;
        }
        for (ServerLevel other : level.getServer().getAllLevels()) {
            entity = other.getEntity(who);
            if (entity != null) {
                COLLARED.put(who, other);
                return entity;
            }
        }
        return null;
    }

    private static void forget(UUID who) {
        COLLARED.remove(who);
        HISTORY.remove(who);
    }

    /**
     * Rolls a collared creature back to where it stood five seconds ago.
     *
     * @return true when the rewind actually landed
     */
    public static boolean rewind(Entity target, UUID holder) {
        if (!wearingFor(target, holder)) {
            return false;
        }
        ArrayDeque<Snap> snaps = HISTORY.get(target.getUUID());
        if (snaps == null) {
            return false;
        }
        // The middle of the window: five seconds back, give or take a tick.
        long want = now - TICKS_BACK;
        Snap picked = null;
        for (Snap snap : snaps) {
            picked = snap;
            if (snap.tick() >= want) {
                break;
            }
        }
        if (picked == null) {
            return false;
        }
        ServerLevel level = picked.level();
        if (target.level() != level) {
            // History written in another dimension is not this one's business.
            return false;
        }

        double x = picked.x();
        double y = picked.y();
        double z = picked.z();
        float yaw = picked.yaw();
        float pitch = picked.pitch();

        if (target instanceof ServerPlayer player) {
            player.teleportTo(level, x, y, z, java.util.Set.of(), yaw, pitch);
        } else {
            TimedoorPortal.moveEntity(target, level, x, y, z);
            target.setYRot(yaw);
            target.setXRot(pitch);
        }
        target.resetFallDistance();
        target.setDeltaMovement(Vec3.ZERO);

        // The same passage puff the doors use, at both ends.
        level.sendParticles(ParticleTypes.PORTAL,
                target.getX(), target.getY() + 1.0, target.getZ(), 24, 0.3, 0.6, 0.3, 0.06);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y + 1.0, z,
                14, 0.3, 0.6, 0.3, 0.04);
        level.playSound(null, x, y, z, SoundEvents.PORTAL_TRAVEL,
                SoundSource.PLAYERS, 0.7F, 1.4F);
        return true;
    }
}
