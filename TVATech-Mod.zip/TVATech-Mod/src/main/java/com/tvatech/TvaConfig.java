package com.tvatech;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;

/**
 * All tunables live here. Values are read once on config load and cached in
 * plain static fields so gameplay code can read them cheaply.
 */
@Mod.EventBusSubscriber(modid = TVATech.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class TvaConfig {

    private static final ForgeConfigSpec.Builder BUILDER_SPEC = new ForgeConfigSpec.Builder();

    // --- general ----------------------------------------------------------
    private static final ForgeConfigSpec.BooleanValue ALLOW_PRUNING = BUILDER_SPEC
            .comment("Allow players to prune living things with the TemPad.",
                    "Pruned entities drop no items and grant no experience.")
            .define("allowPruning", true);

    private static final ForgeConfigSpec.BooleanValue ALLOW_TEMPORAL_HOP = BUILDER_SPEC
            .comment("Allow the TemPad to jump to its pinned coordinates.")
            .define("allowTemporalHop", true);

    private static final ForgeConfigSpec.BooleanValue SHIFT_WORLD_TIME = BUILDER_SPEC
            .comment("Every time jump also nudges the local world clock (day/night changes).")
            .define("shiftWorldTime", true);

    private static final ForgeConfigSpec.IntValue TRAVEL_ANIMATION_TICKS = BUILDER_SPEC
            .comment("Length of the TemPad's time-jump animation.",
                    "The portal opens in front of you, you step through, and it rebuilds",
                    "on the other side. Set to 0 for an instant teleport.")
            .defineInRange("travelAnimationTicks", 30, 0, 200);

    private static final ForgeConfigSpec.IntValue TIME_SHIFT_HOURS = BUILDER_SPEC
            .comment("Maximum number of in-game hours the world clock may jump per time travel.")
            .defineInRange("timeShiftHours", 6, 0, 48);

    // --- tempad -----------------------------------------------------------
    private static final ForgeConfigSpec.IntValue TEMPAD_MAX_CHARGE = BUILDER_SPEC
            .comment("How many temporal charges a TemPad can hold.")
            .defineInRange("tempadMaxCharge", 5, 1, 64);

    private static final ForgeConfigSpec.IntValue HOP_COST = BUILDER_SPEC
            .comment("Charge consumed by one time jump.")
            .defineInRange("hopCost", 1, 0, 16);

    private static final ForgeConfigSpec.IntValue HOP_COOLDOWN_TICKS = BUILDER_SPEC
            .comment("Ticks the player must wait between time jumps.")
            .defineInRange("hopCooldownTicks", 20, 0, 1200);

    private static final ForgeConfigSpec.IntValue BATTERY_CHARGE = BUILDER_SPEC
            .comment("Charge restored by one Chrono Battery.")
            .defineInRange("batteryCharge", 2, 1, 16);

    // --- chrono freeze ----------------------------------------------------
    private static final ForgeConfigSpec.IntValue FREEZE_RADIUS = BUILDER_SPEC
            .comment("Radius (blocks) of the Mobius Mobile chrono-freeze.")
            .defineInRange("freezeRadius", 8, 1, 32);

    private static final ForgeConfigSpec.IntValue FREEZE_DURATION_TICKS = BUILDER_SPEC
            .comment("How long (ticks) the chrono-freeze holds entities still.")
            .defineInRange("freezeDurationTicks", 200, 20, 12000);

    private static final ForgeConfigSpec.IntValue FREEZE_COOLDOWN_TICKS = BUILDER_SPEC
            .comment("Cooldown between chrono-freezes, in ticks.")
            .defineInRange("freezeCooldownTicks", 400, 0, 12000);

    private static final ForgeConfigSpec.IntValue FREEZE_COST = BUILDER_SPEC
            .comment("Charge consumed by one chrono-freeze.")
            .defineInRange("freezeCost", 2, 0, 16);

    private static final ForgeConfigSpec.BooleanValue FREEZE_REQUIRES_REACTOR = BUILDER_SPEC
            .comment("Require a powered Arc Reactor within freezeRadius for the mobile's abilities.",
                    "Disable to let the mobile run on its own battery.")
            .define("freezeRequiresReactor", true);

    private static final ForgeConfigSpec.IntValue REACTOR_RANGE = BUILDER_SPEC
            .comment("How far (blocks) a player may be from an Arc Reactor for it to power their mobile.")
            .defineInRange("reactorRange", 12, 1, 64);

    private static final ForgeConfigSpec.DoubleValue NAUSEA_CHANCE = BUILDER_SPEC
            .comment("Chance (0.0 - 1.0) that a time jump leaves you nauseous.")
            .defineInRange("nauseaChance", 0.3, 0.0, 1.0);

    private static final ForgeConfigSpec.IntValue NAUSEA_DURATION_TICKS = BUILDER_SPEC
            .comment("How long the nausea lasts after a jump, in ticks.")
            .defineInRange("nauseaDurationTicks", 300, 0, 24000);


    private static final ForgeConfigSpec.BooleanValue TIMELINE_BLOCKS = BUILDER_SPEC
            .comment("Remember block changes per day so travelling back shows the world",
                    "as it was: builds you broke later are still there when you return.")
            .define("timelineBlocks", true);

    private static final ForgeConfigSpec.IntValue TIMELINE_SWEEP_TICKS = BUILDER_SPEC
            .comment("How often (in ticks) the world is checked for changes that no",
                    "place/break event reported - fire, decay, pistons, fluids.")
            .defineInRange("timelineSweepTicks", 40, 0, 1200);

    private static final ForgeConfigSpec.IntValue TIMELINE_MAX_ENTRIES = BUILDER_SPEC
            .comment("Safety cap on remembered block positions (0 = unlimited).",
                    "At roughly 20 bytes each, 200000 is a few megabytes.")
            .defineInRange("timelineMaxEntries", 200000, 0, 2000000);

    // --- variants ---------------------------------------------------------
    private static final ForgeConfigSpec.IntValue TIMELINE_LOG_SIZE = BUILDER_SPEC
            .comment("How many events the mobile keeps in its timeline log.")
            .defineInRange("timelineLogSize", 12, 1, 64);

    private static final ForgeConfigSpec.BooleanValue ANNOUNCE_TIMELINE = BUILDER_SPEC
            .comment("Broadcast time travel to the whole server in chat.")
            .define("announceTimeline", false);

    static final ForgeConfigSpec SPEC = BUILDER_SPEC.build();

    // Cached, config-load-populated values.
    public static boolean allowPruning;
    public static boolean allowTemporalHop;
    public static boolean shiftWorldTime;
    public static int travelAnimationTicks;
    public static int timeShiftHours;
    public static int tempadMaxCharge;
    public static int hopCost;
    public static int hopCooldownTicks;
    public static int batteryCharge;
    public static int freezeRadius;
    public static int freezeDurationTicks;
    public static int freezeCooldownTicks;
    public static int freezeCost;
    public static boolean freezeRequiresReactor;
    public static int reactorRange;
    public static double nauseaChance;
    public static int nauseaDurationTicks;
    public static boolean timelineBlocks;
    public static int timelineSweepTicks;
    public static int timelineMaxEntries;
    public static int timelineLogSize;    public static boolean announceTimeline;

    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {
        allowPruning = ALLOW_PRUNING.get();
        allowTemporalHop = ALLOW_TEMPORAL_HOP.get();
        shiftWorldTime = SHIFT_WORLD_TIME.get();
        travelAnimationTicks = TRAVEL_ANIMATION_TICKS.get();
        timeShiftHours = TIME_SHIFT_HOURS.get();
        tempadMaxCharge = TEMPAD_MAX_CHARGE.get();
        hopCost = HOP_COST.get();
        hopCooldownTicks = HOP_COOLDOWN_TICKS.get();
        batteryCharge = BATTERY_CHARGE.get();
        freezeRadius = FREEZE_RADIUS.get();
        freezeDurationTicks = FREEZE_DURATION_TICKS.get();
        freezeCooldownTicks = FREEZE_COOLDOWN_TICKS.get();
        freezeCost = FREEZE_COST.get();
        freezeRequiresReactor = FREEZE_REQUIRES_REACTOR.get();
        reactorRange = REACTOR_RANGE.get();
        nauseaChance = NAUSEA_CHANCE.get();
        nauseaDurationTicks = NAUSEA_DURATION_TICKS.get();
        timelineBlocks = TIMELINE_BLOCKS.get();
        timelineSweepTicks = TIMELINE_SWEEP_TICKS.get();
        timelineMaxEntries = TIMELINE_MAX_ENTRIES.get();
        timelineLogSize = TIMELINE_LOG_SIZE.get();        announceTimeline = ANNOUNCE_TIMELINE.get();
    }
}