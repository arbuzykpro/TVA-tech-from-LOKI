package com.tvatech.system;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Named locations ("marks") stored per player, as shown in the TemPad menu.
 *
 * <p>Marks live in the world save ({@link TvaMarksStore}), keyed by player
 * uuid, kept in the overworld's storage so every dimension reads the same
 * list. Being world data rather than player data, they survive death,
 * respawn, relog and server restart - none of which can be said of the
 * player NBT bag this used to sit in.</p>
 */
public final class TvaMarks {

    private TvaMarks() {}

    /** How many marks one player may keep. */
    public static final int MAX_MARKS = 12;

    /** The player-NBT key marks used to live in, read once to port them over. */
    static final String KEY = "tva_marks";

    /** One saved location. */
    public record Mark(String label, String dimension, int x, int y, int z,
                       long markedDay, int markedHour) {

        public String coordinates() {
            return x + ", " + y + ", " + z;
        }

        public String stamped() {
            int h = Math.floorMod(markedHour, 24);
            int display = h % 12;
            if (display == 0) {
                display = 12;
            }
            return String.format("day %d AT %d %s", markedDay, display, h < 12 ? "AM" : "PM");
        }
    }

    // ------------------------------------------------------------------
    // Storage
    // ------------------------------------------------------------------

    private static TvaMarksStore store(ServerPlayer player) {
        // Always the overworld's storage: it is the one place every dimension
        // shares, so a mark made in the nether waits for you back home too.
        ServerLevel overworld = player.level().getServer().overworld();
        return overworld.getDataStorage().computeIfAbsent(TvaMarksStore.TYPE);
    }

    public static List<Mark> of(Entity entity) {
        List<Mark> marks = new ArrayList<>();
        if (!(entity instanceof ServerPlayer player)
                || !(entity.level() instanceof ServerLevel)) {
            return marks;
        }
        TvaMarksStore store = store(player);
        String json = store.players.get(player.getStringUUID());
        if (json == null || json.isEmpty()) {
            // Older builds kept marks in the player NBT; lift them into the
            // world save one time so nothing a player already collected is lost.
            json = legacyJson(player);
            if (json == null) {
                return marks;
            }
            store.players.put(player.getStringUUID(), json);
            store.setDirty();
        }
        return TvaMarksStore.readList(json);
    }

    /**
     * Any marks still sitting in the old player-NBT bag, as store JSON.
     *
     * <p>{@code null} when the player has none - the common case.</p>
     */
    private static String legacyJson(Entity entity) {
        if (!(entity instanceof ServerPlayer player)) {
            return null;
        }
        CompoundTag data = com.tvatech.util.TvaData.data(player);
        ListTag list = data.getListOrEmpty(KEY);
        if (list.isEmpty()) {
            return null;
        }
        List<Mark> marks = new ArrayList<>();
        for (var tag : list) {
            if (tag instanceof CompoundTag entry) {
                marks.add(new Mark(
                        entry.getString("label").orElse("MARK"),
                        entry.getString("dim").orElse("minecraft:overworld"),
                        entry.getInt("x").orElse(0),
                        entry.getInt("y").orElse(0),
                        entry.getInt("z").orElse(0),
                        entry.getLong("day").orElse(0L),
                        entry.getInt("hour").orElse(0)));
            }
        }
        return TvaMarksStore.writeList(marks);
    }

    /** Drops the oldest mark when the player is at the cap. */
    public static void add(ServerPlayer player, ServerLevel level, int x, int y, int z) {
        List<Mark> marks = new ArrayList<>(of(player));
        if (marks.size() >= MAX_MARKS) {
            marks.remove(0);
        }

        long[] now = WorldTime.now(level);
        marks.add(new Mark(nextLabel(marks), level.dimension().identifier().toString(),
                x, y, z, now[0], (int) now[1]));
        write(player, marks);
    }

    /** Counts past the highest existing number so labels stay unique. */
    private static String nextLabel(List<Mark> existing) {
        int next = 1;
        for (Mark mark : existing) {
            if (mark.label().startsWith("MARK-")) {
                try {
                    next = Math.max(next, Integer.parseInt(mark.label().substring(5)) + 1);
                } catch (NumberFormatException ignored) {
                    // A hand-edited label; just keep counting.
                }
            }
        }
        return String.format("MARK-%02d", next);
    }

    /** The automatic label, exposed for the menu's manual-mark entry. */
    public static String nextLabelPublic(List<Mark> existing) {
        return nextLabel(existing);
    }

    public static void writePublic(ServerPlayer player, List<Mark> marks) {
        write(player, marks);
    }

    public static void remove(ServerPlayer player, int index) {
        List<Mark> marks = of(player);
        if (index < 0 || index >= marks.size()) {
            return;
        }
        marks.remove(index);
        write(player, marks);
    }

    public static void clear(ServerPlayer player) {
        write(player, List.of());
    }

    /** The longest name a mark can carry. */
    public static final int MAX_LABEL = 32;

    /**
     * Renames a mark.
     *
     * <p>Blank names fall back to the automatic one, so a mark can never end up
     * as an empty row you cannot read.</p>
     */
    public static boolean rename(ServerPlayer player, int index, String name) {
        List<Mark> marks = of(player);
        if (index < 0 || index >= marks.size()) {
            return false;
        }
        String trimmed = name == null ? "" : name.strip();
        if (trimmed.length() > MAX_LABEL) {
            trimmed = trimmed.substring(0, MAX_LABEL);
        }
        Mark old = marks.get(index);
        marks.set(index, new Mark(
                trimmed.isEmpty() ? defaultLabel(marks) : trimmed,
                old.dimension(), old.x(), old.y(), old.z(),
                old.markedDay(), old.markedHour()));
        write(player, marks);
        return true;
    }

    /** The name a mark gets when nobody has given it one. */
    private static String defaultLabel(List<Mark> marks) {
        for (int i = 1; i <= marks.size() + 1; i++) {
            String candidate = String.format("MARK-%02d", i);
            boolean taken = false;
            for (Mark mark : marks) {
                if (mark.label().equals(candidate)) {
                    taken = true;
                    break;
                }
            }
            if (!taken) {
                return candidate;
            }
        }
        return "MARK";
    }

    private static void write(ServerPlayer player, List<Mark> marks) {
        TvaMarksStore store = store(player);
        if (marks == null || marks.isEmpty()) {
            store.players.remove(player.getStringUUID());
        } else {
            store.players.put(player.getStringUUID(), TvaMarksStore.writeList(marks));
        }
        store.setDirty();
    }

    /** Convenience for the menu: the mark at {@code index}, or null. */
    public static Mark at(ServerPlayer player, int index) {
        List<Mark> marks = of(player);
        return index >= 0 && index < marks.size() ? marks.get(index) : null;
    }

    public static boolean sameDimension(ServerLevel level, Mark mark) {
        return mark.dimension().equals(level.dimension().identifier().toString());
    }
}
