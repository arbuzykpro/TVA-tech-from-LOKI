package com.tvatech.util;

/**
 * A tiny stand-in for Forge's {@code RegistryObject}.
 *
 * <p>Fabric registers eagerly, so there is no deferred supplier to keep around -
 * but every gameplay class is written against {@code .get()}, and keeping that
 * shape means the port touches the registry file instead of forty other
 * files.</p>
 */
public final class Reg<T> {

    private final T value;

    public Reg(T value) {
        this.value = value;
    }

    public T get() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
