package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

/**
 * Drives the block-timeline with real block edits instead of synthetic records,
 * so the self-test exercises the same path the game does.
 */
public final class TimelineTestHelper {

    private TimelineTestHelper() {}

    /**
     * Places {@code after} at {@code pos} while the clock says {@code hour},
     * going through the same stash/commit pair a player's placement would.
     *
     * @param hour an hour index, as {@link WorldTime#hourIndex(long, int)} makes them
     */
    public static void editAs(ServerLevel level, BlockPos pos,
                              net.minecraft.world.level.block.state.BlockState before,
                              net.minecraft.world.level.block.state.BlockState after, long hour) {
        WorldTime.setTime(level, Math.floorDiv(hour, 24), (int) Math.floorMod(hour, 24));
        Timeline.stashPlace(pos, before);
        level.setBlock(pos, after, net.minecraft.world.level.block.Block.UPDATE_ALL, 0);
        Timeline.commit(level, pos);
    }

    /** Convenience: solid stone at the position, whatever it was before. */
    public static void placeStone(ServerLevel level, BlockPos pos, long hour) {
        editAs(level, pos, level.getBlockState(pos), Blocks.STONE.defaultBlockState(), hour);
    }

    /** Convenience: air at the position, whatever it was before. */
    public static void breakBlock(ServerLevel level, BlockPos pos, long hour) {
        editAs(level, pos, level.getBlockState(pos), Blocks.AIR.defaultBlockState(), hour);
    }
}