package com.tvatech.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.server.network.Filterable;
import net.minecraft.server.network.FilteredText;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.ArrayList;
import java.util.List;

/**
 * The TVA field manual.
 *
 * <p>A normal written book, but written by the Authority: the standing orders
 * every branch of the TVA works from, the doctrine behind the reset button, and
 * the regulations on pruning and on those who go looking for the end of
 * everything.</p>
 *
 * <p>Every page is a plain string. Pages are padded with blank lines so the
 * contents line up, because a book that reflows halfway through is a manual
 * nobody trusts.</p>
 */
public final class TvaManual {

    private TvaManual() {}

    private static final String TITLE = "TVA FIELD MANUAL";
    private static final String AUTHOR = "Time Variance Authority";

    /** Builds the manual. The result is an ordinary {@code written_book}. */
    public static ItemStack create() {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        book.set(DataComponents.WRITTEN_BOOK_CONTENT, content());
        return book;
    }

    /**
     * The pages, on their own.
     *
     * <p>The manual item is a real written book, so it needs these on the stack
     * it is holding before vanilla will open it.</p>
     */
    public static net.minecraft.world.item.component.WrittenBookContent content() {
        List<String> lines = new ArrayList<>(PAGES.length);
        for (String page : PAGES) {
            lines.add(pad(page));
        }
        // Written books hold their pages as filtered text, resolved to components.
        List<Filterable<net.minecraft.network.chat.Component>> pages = new ArrayList<>(lines.size());
        for (String line : lines) {
            pages.add(Filterable.passThrough(
                    net.minecraft.network.chat.Component.literal(line)));
        }

        return new net.minecraft.world.item.component.WrittenBookContent(
                Filterable.from(FilteredText.passThrough(TITLE)),
                AUTHOR,
                0,
                pages,
                false);
    }

    /** Keeps each page the same length so the book reads like a printed manual. */
    private static String pad(String page) {
        if (page.length() >= WIDTH * LINES) {
            return page;
        }
        return page + "\n".repeat(WIDTH * LINES - page.length());
    }

    /** Characters per line, roughly. */
    private static final int WIDTH = 38;
    /** Lines per page. */
    private static final int LINES = 9;

    // ------------------------------------------------------------------
    // The text
    // ------------------------------------------------------------------

    private static final String[] PAGES = {
        "TIME VARIANCE AUTHORITY\nFIELD MANUAL, REVISED EDITION\n\nISSUED TO: ALL BRANCHES\nCLEARANCE: BRANCH-OR-BELOW\n\nFOR ALL TIME ALWAYS.",
        "I. THE MANDATE\n\nWe are the Time Variance\nAuthority. We hold the line\nagainst those who would\ntake what is not theirs.\n\nWe do not conquer. We\ndo not profit. We prune.",
        "II. WHAT WE BELIEVE\n\nA thing belongs to the\nmoment it was earned.\n\nIt may be bought. It may\nbe found. It may be built.\n\nWhatever the hour, the\nhour it was made in\nstill belongs to its maker.",
        "III. WHY WE EXIST\n\nEvery moment is a door,\nand behind each door\nstands a version of the\none who stands in front\nof it.\n\nThe Authority exists to\nmake sure that version\ncan never act.",
        "IV. THE VARIANT RULE\n\nFor all time always, no\nvariant may act outside\nthe hour of its origin.\n\nA variant may live.\nA variant may want.\n\nA variant may not do.\nThat is the whole law.",
        "V. ON TEMPORAL ANCHORS\n\nThe one hour a version\nmay not leave is the\nhour of its origin.\n\nWe call it the Sacred\nHour. Nothing else is\nprotected. Nothing else\nneeds to be.",
        "VI. THE TEMPAD\n\nThe TemPad is a doorway\nyou carry. Hold it, and\nthe hour folds toward you.\n\nDo not call it magic.\nCall it engineering, and\nbe grateful for it.",
        "VII. MARKING AN HOUR\n\nThe TemPad opens onto the\nAtlas. From it you name\nthe hours you would keep.\n\nDrop a mark where you\nstand. It will hold for\nyou until you delete it.",
        "VIII. THE ARRIVAL DIAL\n\nSet the day, and set the\nhour within it.\n\nLeave the dial on PRESENT\nand you arrive in the\npresent, and nothing about\nthe world will have moved.",
        "IX. A WARNING ABOUT\nROOMS\n\nThe world remembers. It is\nnot a polite memory. It\ndoes not forget a wall\nyou pulled down, and it\ndoes not forget a chest\nyou emptied.\n\nTravel back and find both.",
        "X. THE MOBIUS MOBILE\n\nA phone. A scanner. A way\nto freeze a street for\nthe length of a held\nbreath.\n\nMobius built it. Mobius\nalways built it first.",
        "XI. THE ARTERY\n\nThe Artery is the machine\nbeneath the Vault that\nmoves a door between\nhours.\n\nIt is not ours. We only\nfeed it.",
        "XII. ON VARIANTS\n\nWhen a man goes back, a\nversion of him is already\nstanding there, having\nlived the years he has\nnot.\n\nThat version is not a\nghost. That version is\na man further into the\nsame argument.",
        "XIII. ON UNBEARABLE\nVARIANTS\n\nOne variant has endured\nsince the hour the first\nstone was laid, and has\nnever broken.\n\nWe do not name it in\nwriting. This page is\nthe closest we get.",
        "XIV. PRUNING\n\nPruning is not murder.\nPruning is bookkeeping.\n\nA variant removed from an\nhour it should not act in\nwas never in the record to\nbegin with.",
        "XV. THE ARTERY'S TOOTH\n\nEvery branch eventually\nasks what the reset\nbutton in the Vault is\nfor.\n\nRead on.",
        "XVI. THE RESET BUTTON\n\nUnder the floor of the\nVault there is a room. In\nit there is a lever.\n\nPulling it returns\nhim. All of him. Every\nvariant, every hour, back\nto the hour he began.",
        "XVII. WHY WE DO NOT\nTELL HIM\n\nHe has sat in that room\nfor a long time now. Long\nenough to have stopped\nlooking at the door.\n\nHe has made peace with\nit. That is the damage.",
        "XVIII. ON THE ONES\nWHO DEBATE IT\n\nSome among us hold that\nhe should be allowed to\nchoose.\n\nWe answer: he chose once.\nWe will not ask again.",
        "XIX. THE BRANCH THAT\nASKED\n\nA branch of the Authority\nonce questioned whether a\nman should be made to live\nout his life twice.\n\nThe question was referred\nupward. It has not been\nanswered. He is still\nwaiting.",
        "XX. THE EMPTY WORD\n\nAgents have asked what\nword is carved above his\ndoor.\n\nIt is two words.\nFor all time always.\n\nWrite it on your badge and\nyou will be asked to\nresign by morning.",
        "XXI. THE BRANCH THAT\nASKED AGAIN\n\nOne of ours saw the word\nand went back a week.\n\nThe word was the same.\n\nHe has not filed his\nreport. He files nothing\nnow. He has taken a post\nin the Vault and does not\nspeak.",
        "XXII. ON DREAMS\n\nThose who have been close\nto the house dream of a\ntown that is not theirs.\n\nThis is expected. The\nman dreams of a town as\nwell, every night, and\nhas for a very long time.\n\nDo not treat the dreams as\na warning.",
        "XXIII. THE DARKER HOURS\n\nPast the Vault's founding\nthere is a stretch where\nnobody was keeping track.\n\nWe cannot confirm what\nwas built then. We can\nconfirm that it was\nlevel, and that it was\nours.",
        "XXIV. ON THE TWELVE\n\nThere are no twelve\nvariants. There is one\nvariant with a very good\nimagination.\n\nNumbering them is a\nconvenience of the field\nand should not be taken\nas theology.",
        "XXV. WHAT HAPPENS IF\nHE LEAVES\n\nHe will not leave. He has\nnever once tried to leave,\nand there is nothing out\nthere for him to walk to,\nand that is the point of\nthe house and always was.",
        "XXVI. ON SPEAKING TO\nHIM\n\nYou will not be scheduled.\nThere is no slot in the\ndiary for it, and there\nhas not been one since\nthe first century of the\nAuthority.\n\nIf you find yourself in the\nroom anyway, do not say\nhis name first.",
        "XXVII. THE HOUR OF\nTHE RESET\n\nEvery branch has an hour\nit considers sacred. The\nhour of the reset is the\nmost sacred of all, and no\nvariant is ever permitted\nnear it.\n\nThis includes the one who\nremains.",
        "XXVIII. THE STANDING ORDER\n\nIf, having read all of\nthis, you still believe the\nAuthority is doing a\nnecessary thing, then you\nare in the wrong branch\nand we will find you a\nbetter one.",
        "XXIX. THE MANUAL ENDS\n\nThe Authority thanks you\nfor your service and asks\nthat you return this volume\nto the shelves at the next\nopportunity.\n\nIf there are no further\nopportunities, return it\nto the house.\n\nHe does not ask. He\nsimply leaves the door\nopen, which is the same\nthing, and always has\nbeen the same thing.\n\nFOR ALL TIME ALWAYS.",
        "APPENDIX I - THE VAULT\n\nThe Authority works in a\nsingle sealed building.\n\nNobody walks in or out.\nThe doors are for staff and\nstaff arrive by appointment\nwith the timeline.\n\nPLAN OF THE GROUND FLOOR\n  +-----------------+\n  | T  cubicles    |\n  |                |\n  |   +--------+   |\n  | T | ATRIUM | T |\n  |   | compass|   |\n  |   +--------+   |\n  | T cubicles    |\n  +-------+--------+\n          | reception\n          |____ gate ____|",
        "APPENDIX II - THE TEMPAD\n\nSeen from above. The\ndevice does not store\nan hour. It stores the\nright to stand in one.\n\n        .-------.\n       | | glass | |\n       | |chrono | |\n       | |  vium | |\n       . |reactor| .\n        '-------'\n\nHold it flat. Press the\nrim. Wait.\n\nIf it is cold, it is\nnot charged. If it\nsmells of ozone, it\nis about to open a\ndoor whether you\nasked it to or not.",
        "APPENDIX III - THE\nRESET LEVER\n\nIn section. One room,\none pedestal, one\nlever, two chains.\n\n     ceiling\n        |  |\n     --+--+--\n       |  |\n    |  |  |\n     --+--+--\n      |    |\n     [ LEVER ]\n\nPulling it returns\nevery variant to the\nhour of his origin.\n\nIt is not a control.\nIt is a decision, made\nonce, by one person,\nand it cannot be taken\nback.",
        "APPENDIX IV - HOURS\n\n  --+--+--+--+--+--+-->\n     |  |  |  |  |  |\n  ---+--+--+--+--+--+--->\n        |  |  |  |\n  --------+--+--+--+--->\n\nThe hour of a variant's\norigin is marked and\nmay not be crossed.\n\nAll other hours are\nopen to anyone who\ncan hold a TemPad.",
        "APPENDIX V - NOTICES\n\nThe Authority does not\nrecognise the End of\nTime as a place.\n\nIt is a term for the hour\nbefore the first hour.\n\nThe house is there. The\nword is over the door.\n\nFOR ALL TIME ALWAYS.",
    };
}
