package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import com.tvatech.TvaConfig;
import com.tvatech.TvaMessages;
import com.tvatech.util.TvaData;
import com.tvatech.util.TvaEntityName;
import com.tvatech.util.TvaFeedback;
import com.tvatech.util.TvaEntityName;

import java.util.List;
import java.util.Random;

/**
 * Temporal Access Device logic: pinning destinations, jumping through time,
 * keeping track of your variant number and your personal timeline.
 */
public final class TimeTravel {

    private TimeTravel() {}

    private static final Random RANDOM = new Random();

    // NBT keys on the gadget itself
    public static final String KEY_CHARGE = "tva_charge";
    public static final String KEY_PIN_POS = "tva_pin_pos";
    public static final String KEY_PIN_DIM = "tva_pin_dimension";
    public static final String KEY_LAST_HOP = "tva_last_hop";

    // ------------------------------------------------------------------
    // Charge
    // ------------------------------------------------------------------

    public static int charge(ItemStack gadget) {
        return TvaData.getInt(gadget, KEY_CHARGE, 0);
    }

    public static void setCharge(ItemStack gadget, int value) {
        TvaData.setInt(gadget, KEY_CHARGE, Math.max(0, Math.min(value, TvaConfig.tempadMaxCharge)));
    }

    public static void addCharge(ItemStack gadget, int amount) {
        setCharge(gadget, charge(gadget) + amount);
    }

    // ------------------------------------------------------------------
    // Pinning
    // ------------------------------------------------------------------

    public static boolean hasPin(ItemStack gadget) {
        return TvaData.getIntArray(gadget, KEY_PIN_POS).length == 3;
    }

    public static void setPin(ItemStack gadget, Level level, BlockPos pos) {
        setPin(gadget, level.dimension().location().toString(), pos);
    }

    public static void setPin(ItemStack gadget, String dimensionId, BlockPos pos) {
        TvaData.setIntArray(gadget, KEY_PIN_POS, new int[]{pos.getX(), pos.getY(), pos.getZ()});
        TvaData.setString(gadget, KEY_PIN_DIM, dimensionId);
    }

    public static void clearPin(ItemStack gadget) {
        TvaData.remove(gadget, KEY_PIN_POS);
        TvaData.remove(gadget, KEY_PIN_DIM);
    }

    public static String pinDimension(ItemStack gadget) {
        return TvaData.getString(gadget, KEY_PIN_DIM);
    }

    // ------------------------------------------------------------------
    // Variant numbers
    // ------------------------------------------------------------------

    public static int variant(Entity entity) {
        return TvaData.variantOf(entity);
    }

    public static int bumpVariant(Entity entity) {
        int next = variant(entity) + 1;
        TvaData.setVariant(entity, next);
        return next;
    }

    /** Flags a living thing with a variant number (0 = never scanned). */
    public static void setVariant(Entity entity, int variant) {
        TvaData.setVariant(entity, variant);
    }

    // ------------------------------------------------------------------
    // Timeline log
    // ------------------------------------------------------------------

    public static void log(ServerPlayer player, String entry) {
        TvaData.pushTimeline(player, entry, TvaConfig.timelineLogSize);
        if (TvaConfig.announceTimeline) {
            ServerLevel level = player.serverLevel();
            level.getServer().sendSystemMessage(
                    Component.literal("[" + TvaEntityName.of(player) + "] " + entry));
        }
    }

    public static List<String> log(ServerPlayer player) {
        return TvaData.timeline(player);
    }

    // ------------------------------------------------------------------
    // Hopping
    // ------------------------------------------------------------------

    /**
     * Starts a time jump to the pinned coordinates (or, with nothing pinned,
     * performs a small unanchored "temporal flutter" nearby).
     *
     * <p>Charge and the cooldown are spent immediately; the variant bump and
     * the timeline entry happen on arrival, once the portal has closed behind
     * the player.</p>
     */
    public static boolean hop(ServerPlayer player, ItemStack gadget) {
        boolean started = startHop(player, gadget);
        if (!started) {
            // The menu sets the clock before asking for the jump, so a refused
            // jump has to drop that flag instead of leaving it set forever.
            EXPLICIT_CLOCK.remove(player.getUUID());
        }
        return started;
    }

    /**
     * Wipes the cooldown stamp so a self-test is not sensitive to when it runs.
     *
     * <p>The cooldown is measured against level game time, which restarts at
     * zero on a fresh world - so on a brand new save the very first jump is
     * refused, and a test that never thought about that reads as a broken
     * gadget rather than a brand new world.</p>
     */
    public static void clearCooldown(ItemStack gadget) {
        TvaData.setInt(gadget, KEY_LAST_HOP, Integer.MIN_VALUE / 2);
    }

    private static boolean startHop(ServerPlayer player, ItemStack gadget) {
        if (!TvaConfig.allowTemporalHop) {
            TvaFeedback.actionBar(player, TvaMessages.travelDisabled());
            return false;
        }

        if (TemporalTravelFX.isTravelling(player)) {
            TvaFeedback.actionBar(player, TvaMessages.alreadyTravelling());
            return false;
        }

        long now = player.serverLevel().getGameTime();
        long lastHop = TvaData.getLong(gadget, KEY_LAST_HOP, 0L);
        if (TvaConfig.hopCooldownTicks > 0 && now - lastHop < TvaConfig.hopCooldownTicks) {
            long remaining = TvaConfig.hopCooldownTicks - (now - lastHop);
            TvaFeedback.actionBar(player, TvaMessages.cooldown(remaining));
            return false;
        }

        if (charge(gadget) < TvaConfig.hopCost) {
            TvaFeedback.actionBar(player, TvaMessages.outOfCharge());
            return false;
        }

        ServerLevel from = player.serverLevel();
        BlockPos destination;

        if (hasPin(gadget)) {
            String pinnedDim = pinDimension(gadget);
            if (!pinnedDim.equals(from.dimension().location().toString())) {
                TvaFeedback.actionBar(player, TvaMessages.wrongDimension());
                return false;
            }
            int[] pin = TvaData.getIntArray(gadget, KEY_PIN_POS);
            destination = new BlockPos(pin[0], pin[1], pin[2]);
            if (!isSafe(from, destination)) {
                destination = nearestSafe(from, destination);
            }
        } else {
            // Unpinned TemPad: a short uncontrolled flutter around the player.
            BlockPos base = player.blockPosition();
            destination = nearestSafe(from, base.offset(
                    RANDOM.nextInt(48) - 24,
                    RANDOM.nextInt(16) - 6,
                    RANDOM.nextInt(48) - 24));
        }

        // Spend the charge up front so a second tap cannot double-jump.
        addCharge(gadget, -TvaConfig.hopCost);
        TvaData.setInt(gadget, KEY_LAST_HOP, (int) now);

        int duration = TemporalTravelFX.durationTicks();
        if (duration > 0) {
            return TemporalTravelFX.begin(player, destination, duration);
        }

        // Animation disabled in the config: move straight away.
        travel(player, from, destination);
        onArrived(player, destination);
        return true;
    }

    /** Bookkeeping that happens once the player has actually landed. */
    public static void onArrived(ServerPlayer player, BlockPos destination) {
        ServerLevel level = player.serverLevel();
        boolean clockWasChosen = consumeExplicitClock(player);
        if (!clockWasChosen) {
            shiftClock(level);
        } else {
            // Rebuild the world for the moment we just arrived in, so builds
            // from that hour are there and later ones are not.
            long hour = WorldTime.hourIndex(level);
            int rebuilt = Timeline.switchTo(level, hour);
            String moved = com.tvatech.system.TimelineItems.switchTo(level, hour);
            long[] clock = WorldTime.now(level);
            log(player, "Landed on " + WorldTime.format(clock[0], (int) clock[1]) + " - "
                    + rebuilt + " blocks, " + moved + " restored to how they were");
        }
        int variant = bumpVariant(player);
        log(player, "Time jump to " + describe(level, destination) + " - variant #" + variant);
        TvaFeedback.actionBar(player, TvaMessages.hopped(describe(level, destination)));

        // Nausea and the past self that got left behind.
        com.tvatech.system.TemPadMenu.onArrived(player, destination);
    }

    /** Performs the actual move plus a puff of particles. */
    public static void travel(ServerPlayer player, ServerLevel level, BlockPos destination) {
        BlockPos origin = player.blockPosition();

        level.sendParticles(ParticleTypes.PORTAL,
                origin.getX() + 0.5, origin.getY() + 1.0, origin.getZ() + 0.5,
                48, 0.6, 1.0, 0.6, 0.08);
        level.playSound(null, origin, SoundEvents.PORTAL_TRIGGER, SoundSource.PLAYERS, 0.8F, 1.2F);

        // Full player teleport (resets the camera and chunk tracking).
        player.teleportTo(level,
                destination.getX() + 0.5, destination.getY(), destination.getZ() + 0.5,
                java.util.Set.of(), player.getYRot(), player.getXRot());

        ServerLevel target = player.serverLevel();
        target.sendParticles(ParticleTypes.PORTAL,
                destination.getX() + 0.5, destination.getY() + 1.0, destination.getZ() + 0.5,
                48, 0.6, 1.0, 0.6, 0.08);
        target.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                destination.getX() + 0.5, destination.getY() + 1.2, destination.getZ() + 0.5,
                30, 0.5, 0.8, 0.5, 0.1);
        target.playSound(null, destination, SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.7F, 1.0F);
    }

    /** Time travel nudges the local clock so day/night visibly changes. */
    public static void shiftClock(ServerLevel level) {
        if (!TvaConfig.shiftWorldTime || TvaConfig.timeShiftHours <= 0) {
            return;
        }
        int hours = RANDOM.nextInt(TvaConfig.timeShiftHours * 2 + 1) - TvaConfig.timeShiftHours;
        if (hours == 0) {
            hours = 1;
        }
        WorldTime.shiftHours(level, hours);
    }

    /**
     * Marks a player whose clock was just set explicitly from the menu.
     *
     * <p>The random nudge in {@link #shiftClock} would immediately undo a time
     * the player picked on purpose, so arrival skips it once for them.</p>
     */
    public static void markExplicitClock(ServerPlayer player) {
        EXPLICIT_CLOCK.add(player.getUUID());
    }

    private static boolean consumeExplicitClock(ServerPlayer player) {
        return EXPLICIT_CLOCK.remove(player.getUUID());
    }

    private static final java.util.Set<java.util.UUID> EXPLICIT_CLOCK =
            java.util.concurrent.ConcurrentHashMap.newKeySet();

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    public static String describe(ServerLevel level, BlockPos pos) {
        return "x=" + pos.getX() + " y=" + pos.getY() + " z=" + pos.getZ();
    }

    public static boolean isSafe(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty();
    }

    /** Searches outwards for somewhere that will not drop the player into lava. */
    public static BlockPos nearestSafe(ServerLevel level, BlockPos wanted) {
        if (isSafe(level, wanted)) {
            return wanted;
        }
        for (int radius = 1; radius <= 24; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        if (Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) != radius) {
                            continue;
                        }
                        BlockPos candidate = wanted.offset(dx, dy, dz);
                        if (isSafe(level, candidate)) {
                            return candidate;
                        }
                    }
                }
            }
        }
        return wanted;
    }
}
