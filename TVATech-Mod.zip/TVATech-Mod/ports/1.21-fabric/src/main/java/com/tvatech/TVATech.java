package com.tvatech;

import com.mojang.logging.LogUtils;
import net.fabricmc.api.ModInitializer;
import com.tvatech.event.TvaEvents;
import com.tvatech.network.TvaNetwork;
import com.tvatech.worldgen.ChronoviumOre;
import org.slf4j.Logger;

/**
 * TVA Tech - Marvel's Loki (TVA) technology for Minecraft.
 *
 * <p>Adds the TemPad, the Mobius Mobile, variant scanning, pruning,
 * chrono-freeze and the glowing Time Door blocks.</p>
 */
public final class TVATech implements ModInitializer {

    public static final String MODID = "tvatech";

    private static final Logger LOGGER = LogUtils.getLogger();

    /** Shared logger, also used by the client-only helpers. */
    public static final Logger LOG = LOGGER;

    @Override
    public void onInitialize() {
        // Registries first: everything below assumes the items exist.
        ModContent.init();

        TvaNetwork.init();
        TvaEvents.register();
        ChronoviumOre.register();

        LOGGER.info("TVA Tech initialised - mind the reset button.");
    }
}
