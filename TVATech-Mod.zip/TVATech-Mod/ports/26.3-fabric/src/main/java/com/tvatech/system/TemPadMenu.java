package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import com.tvatech.ModContent;
import com.tvatech.TvaConfig;
import com.tvatech.TvaMessages;
import com.tvatech.network.TvaNetwork;
import com.tvatech.util.TvaFeedback;

import java.util.ArrayList;
import java.util.List;

/**
 * Server side of the TemPad destination menu.
 *
 * <p>The player picks a saved mark (or drops a new one where they stand) and
 * optionally a point in history - an hour of the world, day and hour together.
 * Leaving the time untouched simply keeps the clock where it is, which is the
 * present.</p>
 */
public final class TemPadMenu {

    private TemPadMenu() {}

    /** The key of the Authority's own dimension. */
    public static final net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level>
            TVA = net.minecraft.resources.ResourceKey.create(
                    net.minecraft.core.registries.Registries.DIMENSION,
                    net.minecraft.resources.Identifier.fromNamespaceAndPath(
                            com.tvatech.TVATech.MODID, "tva"));

    /** Where the player came from, so the way back exists. */
    private static final String KEY_RETURN_X = "tva_eot_x";
    private static final String KEY_RETURN_Y = "tva_eot_y";
    private static final String KEY_RETURN_Z = "tva_eot_z";
    private static final String KEY_RETURN_DIM = "tva_eot_dim";

    /** Pushes the current mark list (and the world's clock as a default) to the client. */
    public static void pushState(ServerPlayer player, int selected, long day, int hour) {
        List<TvaMarks.Mark> marks = TvaMarks.of(player);
        List<String> labels = new ArrayList<>();
        List<String> dims = new ArrayList<>();
        int[] xs = new int[marks.size()];
        int[] ys = new int[marks.size()];
        int[] zs = new int[marks.size()];
        long[] days = new long[marks.size()];
        int[] hours = new int[marks.size()];

        for (int i = 0; i < marks.size(); i++) {
            TvaMarks.Mark mark = marks.get(i);
            labels.add(mark.label());
            dims.add(mark.dimension());
            xs[i] = mark.x();
            ys[i] = mark.y();
            zs[i] = mark.z();
            days[i] = mark.markedDay();
            hours[i] = mark.markedHour();
        }

        TvaNetwork.sendToPlayer(player, new TvaNetwork.OpenTemPadMenuPayload(
                labels, dims, xs, ys, zs, days, hours, day, hour));
    }

    /** Opens the menu with sensible defaults. */
    public static void open(ServerPlayer player) {
        long[] now = WorldTime.now(player.level());
        // Someone already past the first hour has no hour to dial back to.
        long day = atTva(player) ? 0 : now[0];
        pushState(player, 0, day, (int) now[1]);
    }

    public static void handle(ServerPlayer player, TvaNetwork.TemPadMenuActionPayload action) {
        ServerLevel level = player.level();
        switch (action.action()) {
            case TvaNetwork.MENU_MAKE_MARK -> {
                BlockPos standing = player.blockPosition();
                BlockPos safe = TimeTravel.nearestSafe(level, standing);
                TvaMarks.add(player, level, safe.getX(), safe.getY(), safe.getZ());
                long[] now = WorldTime.now(level);
                TvaFeedback.actionBar(player, TvaMessages.markMade(
                        String.valueOf(TvaMarks.of(player).size())));
                pushState(player, TvaMarks.of(player).size() - 1, now[0], (int) now[1]);
            }
            case TvaNetwork.MENU_MANUAL_MARK -> {
                // A mark typed into the MANUAL view. Need a dimension at least.
                if (action.mdim() == null || action.mdim().isBlank()) {
                    long[] now = WorldTime.now(level);
                    pushState(player, action.index(), now[0], (int) now[1]);
                    break;
                }
                List<TvaMarks.Mark> marks = new ArrayList<>(TvaMarks.of(player));
                if (marks.size() >= TvaMarks.MAX_MARKS) {
                    marks.remove(0);
                }
                String dim = action.mdim().strip();
                if (!dim.contains(":")) {
                    dim = "minecraft:" + dim;
                }
                long[] now = WorldTime.now(level);
                marks.add(new TvaMarks.Mark(TvaMarks.nextLabelPublic(marks), dim,
                        action.mx(), action.my(), action.mz(), now[0], (int) now[1]));
                TvaMarks.writePublic(player, marks);
                TvaFeedback.actionBar(player, TvaMessages.markMade(String.valueOf(marks.size())));
                pushState(player, marks.size() - 1, now[0], (int) now[1]);
            }
            case TvaNetwork.MENU_DELETE_MARK -> {
                TvaMarks.remove(player, action.index());
                long[] now = WorldTime.now(level);
                pushState(player, Math.max(0, action.index() - 1), now[0], (int) now[1]);
            }
            case TvaNetwork.MENU_RENAME_MARK -> {
                if (TvaMarks.rename(player, action.index(), action.name())) {
                    TvaFeedback.actionBar(player, TvaMessages.markRenamed());
                }
                long[] now = WorldTime.now(level);
                pushState(player, action.index(), now[0], (int) now[1]);
            }
            case TvaNetwork.MENU_TRAVEL -> travel(player, action);
            case TvaNetwork.MENU_CLOSE -> {
            }
            default -> {
            }
        }
    }

    private static void travel(ServerPlayer player, TvaNetwork.TemPadMenuActionPayload action) {
        // Standing in the End of Time, any journey is the way out.
        if (atTva(player)) {
            travelBackFromTva(player);
            return;
        }

        ItemStack gadget = gadgetInHand(player);
        if (gadget == null) {
            TvaFeedback.actionBar(player, TvaMessages.holdTemPad());
            return;
        }

        // Day -1 is not a day at all. It is the End of Time, and it works from
        // any mark, or from nowhere at all.
        if (action.day() < 0) {
            TimedoorPortal.Destination out = TimedoorPortal.Destination.toTva();
            if (action.cell()) {
                out = out.withCell();
            }
            openDoor(player, out);
            return;
        }

        ServerLevel level = player.level();
        TvaMarks.Mark mark = TvaMarks.at(player, action.index());
        if (mark == null) {
            TvaFeedback.actionBar(player, TvaMessages.noMarkSelected());
            return;
        }
        if (!TvaMarks.sameDimension(level, mark)) {
            TvaFeedback.actionBar(player, TvaMessages.wrongDimension());
            return;
        }

        // The TemPad opens a doorway rather than moving you itself. The clock
        // is dialled in when you step through, not now, so standing in front of
        // an open door does not quietly move the world under your feet.
        BlockPos destination = new BlockPos(mark.x(), mark.y(), mark.z());
        TimedoorPortal.Destination door = action.useTime()
                ? TimedoorPortal.Destination.timed(level, destination, action.day(), action.hour())
                : TimedoorPortal.Destination.to(level, destination);
        if (action.cell()) {
            door = door.withCell();
        }
        openDoor(player, door);
    }

    /**
     * Stands a doorway up in front of the player.
     *
     * <p>If there is no clear space for one, the travel still happens - being
     * unable to open a door is not a reason to be stranded where you stand.</p>
     */
    private static void openDoor(ServerPlayer player, TimedoorPortal.Destination destination) {
        if (TimedoorPortal.open(player, destination)) {
            return;
        }
        TvaFeedback.actionBar(player, TvaMessages.noRoomForDoor());
        TimedoorPortal.stepThroughNow(player, destination);
    }

    private static ItemStack gadgetInHand(ServerPlayer player) {
        var main = player.getMainHandItem();
        if (main.is(ModContent.TEMPAD.get())) {
            return main;
        }
        var off = player.getOffhandItem();
        return off.is(ModContent.TEMPAD.get()) ? off : null;
    }

    /** Sends the player past the first hour. */
    public static void goToTva(ServerPlayer player) {
        ServerLevel target = player.level().getServer().getLevel(TVA);
        if (target == null) {
            TvaFeedback.actionBar(player, TvaMessages.tvaUnavailable());
            return;
        }

        // Remember where they left off, so the way back works.
        BlockPos here = player.blockPosition();
        var data = com.tvatech.util.TvaData.data(player);
        data.putInt(KEY_RETURN_X, here.getX());
        data.putInt(KEY_RETURN_Y, here.getY());
        data.putInt(KEY_RETURN_Z, here.getZ());
        data.putString(KEY_RETURN_DIM,
                player.level().dimension().identifier().toString());

        TvaVault.ensureBuilt(target, new BlockPos(0, TvaVault.FLOOR_Y, 0));

        // Stand on the landing out in front of the gate, looking at it.
        BlockPos arrival = new BlockPos(0, TvaVault.FLOOR_Y + 1, TvaVault.ARRIVAL_Z);
        player.teleportTo(target,
                arrival.getX() + 0.5, arrival.getY(), arrival.getZ() + 0.5,
                java.util.Set.of(), 0.0F, 0.0F, true);

        target.playSound(null, arrival,
                net.minecraft.sounds.SoundEvents.PORTAL_TRAVEL,
                net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 0.5F);
        target.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                arrival.getX() + 0.5, arrival.getY() + 1.0, arrival.getZ() + 0.5,
                120, 1.2, 1.6, 1.2, 0.05);

        TimeTravel.log(player, "Went past the first hour - to the End of Time");
        TvaFeedback.actionBar(player, TvaMessages.arrivedTva());
    }

    /** Brings a stranded traveller back out of the End of Time. */
    private static void travelBackFromTva(ServerPlayer player) {
        var data = com.tvatech.util.TvaData.data(player);
        String dimId = data.getString(KEY_RETURN_DIM).orElse("");
        var key = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.DIMENSION,
                net.minecraft.resources.Identifier.parse(
                        dimId.isEmpty() ? "minecraft:overworld" : dimId));
        ServerLevel home = player.level().getServer().getLevel(key);
        if (home == null) {
            home = player.level().getServer().overworld();
        }

        BlockPos back = new BlockPos(
                data.getInt(KEY_RETURN_X).orElse(0),
                data.getInt(KEY_RETURN_Y).orElse(64),
                data.getInt(KEY_RETURN_Z).orElse(0));
        BlockPos safe = TimeTravel.nearestSafe(home, back);
        player.teleportTo(home,
                safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5,
                java.util.Set.of(), player.getYRot(), player.getXRot(), true);

        home.playSound(null, safe, net.minecraft.sounds.SoundEvents.PORTAL_TRAVEL,
                net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 0.6F);
        TimeTravel.log(player, "Came back out of the End of Time");
        TvaFeedback.actionBar(player, TvaMessages.returnedFromTva());
    }

    /** True when the player is standing in the End of Time. */
    public static boolean atTva(ServerPlayer player) {
        return player.level().dimension().equals(TVA);
    }

    /** Post-arrival effect: the jump sometimes leaves you nauseous. */
    public static void onArrived(ServerPlayer player, BlockPos destination) {
        // Applying an effect syncs a packet, which needs a live connection.
        if (player.connection != null
                && TvaConfig.nauseaChance > 0 && TvaConfig.nauseaDurationTicks > 0
                && RANDOM.nextDouble() < TvaConfig.nauseaChance) {
            player.addEffect(new MobEffectInstance(MobEffects.NAUSEA, TvaConfig.nauseaDurationTicks, 0));
            TvaFeedback.actionBar(player, TvaMessages.nauseous());
        }
    }

    private static final java.util.Random RANDOM = new java.util.Random();
}