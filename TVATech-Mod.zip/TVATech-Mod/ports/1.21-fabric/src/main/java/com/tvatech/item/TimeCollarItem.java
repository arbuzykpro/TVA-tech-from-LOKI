package com.tvatech.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import com.tvatech.system.TimeCollar;
import com.tvatech.util.TvaFeedback;

import java.util.function.Consumer;

/**
 * The time collar: a shackle other people wear on their timeline.
 *
 * <p>Right-click a mob or a fellow agent with it and the collar snaps shut
 * around them - but it refuses to close on the agent's own neck. Whoever had
 * it clamped on them can only have it taken back by the very same agent, and
 * only with a sneak right-click on the collared creature. The collar pops
 * off and drops as an item.</p>
 */
public class TimeCollarItem extends TvaGadgetItem {

    public TimeCollarItem(Properties properties) {
        super(properties, TimeCollarItem::tooltip);
    }

    private static void tooltip(TvaGadgetItem item, ItemStack stack, Consumer<Component> lines) {
        lines.accept(grey("tvatech.tooltip.collar_1"));
        lines.accept(grey("tvatech.tooltip.collar_2"));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                  LivingEntity target, InteractionHand hand) {
        if (!(player.level() instanceof ServerLevel level)
                || !(player instanceof net.minecraft.server.level.ServerPlayer agent)) {
            return InteractionResult.PASS;
        }

        // Sneaking on a collared creature returns the collar - only ever for
        // the agent who clamped it on in the first place.
        if (player.isShiftKeyDown()) {
            return TimeCollar.remove(target, agent.getUUID())
                    ? InteractionResult.SUCCESS
                    : InteractionResult.PASS;
        }

        if (TimeCollar.put(target, agent.getUUID())) {
            stack.shrink(1);
            return InteractionResult.SUCCESS;
        }
        // Either yourself, or a creature answering to a different agent.
        if (target == player) {
            TvaFeedback.actionBar(agent, noCollarSelf());
        } else {
            TvaFeedback.actionBar(agent, noCollarOther());
        }
        return InteractionResult.FAIL;
    }

    private static Component noCollarSelf() {
        return Component.translatable("tvatech.collar.self");
    }

    private static Component noCollarOther() {
        return Component.translatable("tvatech.collar.other");
    }
}
