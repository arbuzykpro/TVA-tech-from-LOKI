<#
    targets.ps1 - the build matrix for TVA Tech.

    Why this file exists:
    The mod is not source-portable across Minecraft versions. A handful of the
    APIs it leans on only exist from 1.21.4 onwards (the assets/<ns>/items
    model folder), some only from 1.20.5 (WrittenBookContent and the component
    system), and the dimension JSON gained a whole attributes block in 1.21.2.
    A single source tree therefore cannot compile against every target.

    So each target is its own Gradle project under ports/, with its own source
    set, and this file is the single place that says what they are. Adding a
    target means adding a row here and a directory next to it - not editing
    eight copies of a build file by hand.

    Usage:
        pwsh -File Tools\targets.ps1 list                 # show the matrix
        pwsh -File Tools\targets.ps1 build <target>      # build one
        pwsh -File Tools\targets.ps1 build all           # build every ported target
        pwsh -File Tools\targets.ps1 dist                # build the main one + copy jars

    A target is only listed as ready once its directory exists AND has been
    compiled. Everything else is reported as pending rather than quietly
    skipped, so a missing port is always visible.
#>

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string] $Task = 'list',

    [Parameter(Position = 1)]
    [string] $Target = 'all'
)

$ErrorActionPreference = 'Stop'

$projectDir = Split-Path -Parent $PSScriptRoot
$portsDir   = Join-Path $projectDir 'ports'

# ---------------------------------------------------------------------------
# The matrix.
#
# java      - the toolchain the target needs
# forge     - the Forge version, or $null for Fabric
# kind      - forge | fabric
# source    - the source set it is built from
#
# The 26.x Forge row shares src/main/java with Minecraft 26.3; 26.2 was tried
# but its datapack schema differs (worldgen/feature vs worldgen/configured_feature,
# biome/dimension_type attributes, timelines) so it cannot be built from the same
# resources and is not one of the requested targets.
#
# The 26.x line ships deobfuscated, so it needs no Mojang mappings: 26.3 Fabric
# builds against an identity mapping file (ports/26.3-fabric/mappings) and is a
# finished target.
#
# 1.21 and 1.21.1 Fabric are finished targets: ports/1.21-fabric and
# ports/1.21.1-fabric both compile against official Mojang mappings with Loom
# 1.9.2 on JDK 21, and their jars each pass the in-game self-test (80/80) on a
# real Fabric dedicated server. Their Java/data sources are identical except
# fabric.mod.json.
# ---------------------------------------------------------------------------
$MATRIX = @(
    [pscustomobject]@{ Key = '26.3-forge';    Mc = '26.3';   Loader = 'forge';  Kind = 'forge';  Java = 25; Forge = '66.0.12'; Source = 'src/main/java' },
    [pscustomobject]@{ Key = '26.3-fabric';   Mc = '26.3';   Loader = 'fabric'; Kind = 'fabric'; Java = 25; Forge = $null;     Source = 'ports/26.3-fabric/src/main/java' },
    [pscustomobject]@{ Key = '1.21.1-forge';  Mc = '1.21.1'; Loader = 'forge';  Kind = 'forge';  Java = 21; Forge = '52.1.20'; Source = 'ports/1.21.1-forge/src/main/java' },
    [pscustomobject]@{ Key = '1.21.1-fabric'; Mc = '1.21.1'; Loader = 'fabric'; Kind = 'fabric'; Java = 21; Forge = $null;     Source = 'ports/1.21.1-fabric/src/main/java' },
    [pscustomobject]@{ Key = '1.21-forge';    Mc = '1.21';   Loader = 'forge';  Kind = 'forge';  Java = 21; Forge = '51.0.3';  Source = 'ports/1.21-forge/src/main/java' },
    [pscustomobject]@{ Key = '1.21-fabric';   Mc = '1.21';   Loader = 'fabric'; Kind = 'fabric'; Java = 21; Forge = $null;     Source = 'ports/1.21-fabric/src/main/java' },
    [pscustomobject]@{ Key = '1.20.1-forge';  Mc = '1.20.1'; Loader = 'forge';  Kind = 'forge';  Java = 17; Forge = '47.4.28'; Source = 'ports/1.20.1-forge/src/main/java' },
    [pscustomobject]@{ Key = '1.20.1-fabric'; Mc = '1.20.1'; Loader = 'fabric'; Kind = 'fabric'; Java = 17; Forge = $null;     Source = 'ports/1.20.1-fabric/src/main/java' }
)

# Where each finished jar belongs.
$libsDir = Join-Path $projectDir 'build\libs'

function Get-State($row) {
    # built      - there is a jar in that target's folder
    # porting    - the source tree has been filled in and work is under way
    # scaffolded - the Gradle project exists but no source has been put in yet
    $jar = Get-ChildItem (Join-Path $libsDir "$($row.Mc) $($row.Loader)") -Filter '*.jar' -ErrorAction SilentlyContinue
    if ($jar) { return 'built' }

    $src = Join-Path $projectDir $row.Source
    if (Test-Path $src) {
        $files = @(Get-ChildItem $src -Recurse -Filter '*.java' -ErrorAction SilentlyContinue)
        if ($files.Count -gt 0) { return 'porting' }
    }
    $project = Join-Path $portsDir $row.Key
    if (Test-Path (Join-Path $project 'build.gradle')) { return 'scaffolded' }
    return 'not ported'
}

function Show-Matrix {
    Write-Host ''
    Write-Host '  TVA Tech build matrix' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ('  {0,-15} {1,-9} {2,-8} {3}' -f 'target', 'mc', 'loader', 'state')
    Write-Host ('  ' + ('-' * 52))
    foreach ($row in $MATRIX) {
        $state = Get-State $row
        $colour = switch ($state) {
            'built'      { 'Green' }
            'porting'    { 'Yellow' }
            'scaffolded' { 'DarkGray' }
            default      { 'DarkGray' }
        }
        Write-Host ('  {0,-15} {1,-9} {2,-8} ' -f $row.Key, $row.Mc, $row.Loader) -NoNewline
        Write-Host $state -ForegroundColor $colour
    }
    Write-Host ''
    $built = @($MATRIX | Where-Object { (Get-State $_) -eq 'built' }).Count
    Write-Host ('  {0} of {1} targets built' -f $built, $MATRIX.Count) -ForegroundColor Cyan
    Write-Host ''
}

if ($Task -eq 'list') {
    Show-Matrix
    return
}

if ($Task -eq 'dist') {
    # The main target only: the one this workspace is actually developed against.
    & (Join-Path $projectDir 'build.ps1') build
    Show-Matrix
    return
}

if ($Task -eq 'build') {
    $rows = if ($Target -eq 'all') { $MATRIX } else { $MATRIX | Where-Object { $_.Key -eq $Target } }
    if (-not $rows) {
        throw "unknown target '$Target'. Known: $(($MATRIX.Key) -join ', ')"
    }

    $built = 0
    foreach ($row in $rows) {
        $dir = Join-Path $portsDir $row.Key
        if (-not (Test-Path $dir)) {
            Write-Host "==> skipping $($row.Key): no port directory" -ForegroundColor DarkGray
            continue
        }
        Write-Host "==> building $($row.Key)" -ForegroundColor Cyan
        Push-Location $dir
        try {
            & (Join-Path $dir 'gradlew.bat') build '--console=plain'
            if ($LASTEXITCODE -ne 0) { throw "$($row.Key) failed with exit code $LASTEXITCODE" }
        } finally {
            Pop-Location
        }
        $dest = Join-Path $libsDir "$($row.Mc) $($row.Loader)"
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        Get-ChildItem (Join-Path $dir 'build\libs') -Filter '*.jar' -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -notmatch 'sources|dev' } |
            ForEach-Object {
                $name = "TVA_tech_$($row.Mc)_$($_.BaseName -replace '^.*?_', '').jar"
                Copy-Item -Force $_.FullName (Join-Path $dest $name)
                Write-Host "    -> $dest\$name" -ForegroundColor Green
            }
        $built++
    }
    Write-Host ''
    Write-Host "built $built target(s)" -ForegroundColor Cyan
    Show-Matrix
    return
}

throw "unknown task '$Task'. Use list, build or dist."
