package com.tvatech.event;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import com.tvatech.ModContent;
import com.tvatech.TvaConfig;
import com.tvatech.TvaMessages;
import com.tvatech.block.TimeDoorBlock;
import com.tvatech.system.ChronoFreeze;
import com.tvatech.system.MobileAbilities;
import com.tvatech.system.Pruning;
import com.tvatech.system.TemPadMenu;
import com.tvatech.system.Timeline;
import com.tvatech.system.TimelineItems;
import com.tvatech.system.TimeTravel;
import com.tvatech.system.TvaMarks;
import com.tvatech.system.TvaSelfTest;
import com.tvatech.util.TvaData;
import com.tvatech.util.TvaEntityName;
import com.tvatech.util.TvaFeedback;

/**
 * All gameplay wiring in one place.
 *
 * <p>Listeners are registered from the mod constructor
 * ({@link #register()}) so there is no hidden scanning.</p>
 */
public final class TvaEvents {

    private TvaEvents() {}

    public static void register() {
        // Right clicking with the gadgets.
        PlayerInteractEvent.RightClickItem.BUS.addListener(TvaEvents::onRightClickItem);
        PlayerInteractEvent.RightClickBlock.BUS.addListener(TvaEvents::onRightClickBlock);
        PlayerInteractEvent.EntityInteractSpecific.BUS.addListener(TvaEvents::onEntityInteract);

        // Death must not swallow a worn collar: it pops off and drops.
        LivingDeathEvent.BUS.addListener(TvaEvents::onLivingDeath);

        // Per player maintenance: chrono cooldowns and releasing frozen mobs.
        TickEvent.PlayerTickEvent.Post.BUS.addListener(TvaEvents::onPlayerTick);

        // Drives the TemPad portal animation.
        TickEvent.ServerTickEvent.Post.BUS.addListener(event -> {
            com.tvatech.system.TemporalTravelFX.tick(event.server());
            // Time doors you can walk through: ripple, notice the player, shut.
            com.tvatech.system.TimedoorPortal.tick(event.server());
            // Time cells: prisoners drop and drop, and the clock burns hot.
            com.tvatech.system.TimeCells.tick(event.server());
            // Collared creatures file where they stand, for the rewind.
            com.tvatech.system.TimeCollar.tick(event.server());
            // Miss Minutes runs her orientations on the new.
            com.tvatech.system.MissMinutes.tick(event.server());
            // Chunks that finished loading since the last tick get the version
            // of themselves that belongs to the current day.
            Timeline.drainPendingChunks(event.server().overworld());
        });

        // Catch-up sweep for block changes no event reported, and a one-off
        // resync at startup so the world matches the clock after a restart.
        TickEvent.ServerTickEvent.Post.BUS.addListener(event -> {
            if (!TvaConfig.timelineBlocks || TvaConfig.timelineSweepTicks <= 0) {
                return;
            }
            var server = event.server();
            if (server.getTickCount() == 40) {
                for (ServerLevel level : server.getAllLevels()) {
                    long hour = com.tvatech.system.WorldTime.hourIndex(level);
                    com.tvatech.system.Timeline.switchTo(level, hour);
                    TimelineItems.switchTo(level, hour);
                }
                return;
            }
            if (server.getTickCount() % TvaConfig.timelineSweepTicks == 0) {
                com.tvatech.system.Timeline.sweep(server.overworld());
                TimelineItems.sweep(server.overworld());
            }
        });

        // A jump in flight must never outlive the player who started it.
        PlayerEvent.PlayerLoggedOutEvent.BUS.addListener(event -> {
            ChronoFreeze.releaseAllLockedBy(event.getEntity());
            com.tvatech.system.TemporalTravelFX.cancel(event.getEntity().getUUID());
            // Nor may a doorway: it holds blocks in the world.
            com.tvatech.system.TimedoorPortal.close(event.getEntity().getUUID());
            // Nor may Miss Minutes on a mid-orientation exit.
            com.tvatech.system.MissMinutes.clear(event.getEntity().getUUID());
        });
        PlayerEvent.PlayerChangedDimensionEvent.BUS.addListener(event ->
                com.tvatech.system.TemporalTravelFX.cancel(event.getEntity().getUUID()));

        // A first craft of any of the gadgets is orientation time.
        PlayerEvent.ItemCraftedEvent.BUS.addListener(event -> {
            if (event.getEntity() != null && !event.getCrafting().isEmpty()
                    && event.getEntity() instanceof ServerPlayer player) {
                com.tvatech.system.MissMinutes.onCraft(player, event.getCrafting());
            }
        });

        // /tva admin + testing commands.
        RegisterCommandsEvent.BUS.addListener(com.tvatech.command.TvaCommands::register);

        // The world remembers what it looked like on every day.
        //
        // IMPORTANT: these are registered as Consumers, never as Predicates.
        // EntityPlaceEvent has no Result, so its cancellation is decided purely
        // by what a Predicate listener returns - and returning true vetoes the
        // placement. A Consumer returns void and therefore cannot cancel
        // anything, which makes it impossible for this mod to block building.
        BlockEvent.BreakEvent.BUS.addListener(
                (java.util.function.Consumer<BlockEvent.BreakEvent>) event -> {
                    // A time door is held together by the TemPad. It is not
                    // something you can mine apart while it is open.
                    if (event.getState().is(ModContent.TIMEDOOR_FIELD.get())) {
                        event.setResult(net.minecraftforge.common.util.Result.DENY);
                        event.getLevel().playSound(null, event.getPos(),
                                net.minecraft.sounds.SoundEvents.BEACON_POWER_SELECT,
                                net.minecraft.sounds.SoundSource.BLOCKS, 0.4F, 2.0F);
                        return;
                    }
                    if (event.getLevel() instanceof ServerLevel serverLevel) {
                        Timeline.stashBreak(event.getPos(), event.getState());
                    }
                });
        BlockEvent.EntityPlaceEvent.BUS.addListener(
                (java.util.function.Consumer<BlockEvent.EntityPlaceEvent>) event -> {
                    if (event.getLevel() instanceof ServerLevel serverLevel) {
                        Timeline.stashPlace(event.getPos(),
                                event.getBlockSnapshot().getReplacedBlock());
                    }
                });
        // Fires once the block has really changed, which is where records are
        // written.
        BlockEvent.NeighborNotifyEvent.BUS.addListener(
                (java.util.function.Consumer<BlockEvent.NeighborNotifyEvent>) event -> {
                    if (event.getLevel() instanceof ServerLevel serverLevel) {
                        Timeline.commit(serverLevel, event.getPos());
                    }
                });
        ChunkEvent.Load.BUS.addListener(event -> {
            if (event.getLevel() instanceof ServerLevel serverLevel) {
                Timeline.onChunkLoaded(serverLevel, event.getChunk().getPos());
            }
        });

        // Dropped items and storage blocks follow the timeline as well.
        net.minecraftforge.event.entity.EntityJoinLevelEvent.BUS.addListener(
                (java.util.function.Consumer<net.minecraftforge.event.entity.EntityJoinLevelEvent>)
                        event -> {
                            if (event.getLevel() instanceof ServerLevel serverLevel) {
                                TimelineItems.onJoin(serverLevel, event.getEntity());
                            }
                        });
        net.minecraftforge.event.entity.EntityLeaveLevelEvent.BUS.addListener(
                (java.util.function.Consumer<net.minecraftforge.event.entity.EntityLeaveLevelEvent>)
                        event -> {
                            if (event.getLevel() instanceof ServerLevel serverLevel) {
                                TimelineItems.onLeave(serverLevel, event.getEntity());
                            }
                        });
        net.minecraftforge.event.entity.player.PlayerContainerEvent.Close.BUS.addListener(
                (java.util.function.Consumer<net.minecraftforge.event.entity.player.PlayerContainerEvent.Close>)
                        event -> {
                            // Whatever was moved in or out is the new normal for
                            // this day.
                            if (event.getEntity() instanceof ServerPlayer serverPlayer) {
                                TimelineItems.onAnyContainerChanged(serverPlayer);
                            }
                        });

        // Dev-only GUI preview (-Dtva.showmenu=true). Guarded by a dist check so
        // a dedicated server never touches the client classes.
        TickEvent.ClientTickEvent.Post.BUS.addListener(event -> {
            if (net.minecraftforge.fml.loading.FMLEnvironment.dist.isClient()) {
                com.tvatech.client.TvaClient.debugOpenMenuIfRequested();
            }
        });

        // Optional startup self-check (launch with -Dtva.selftest=true).
        ServerStartedEvent.BUS.addListener(TvaSelfTest::onServerStarted);

        // "Time of death" respawn.
        PlayerEvent.PlayerRespawnEvent.BUS.addListener(TvaEvents::onRespawn);

        // Persistent data (marks, return points) must survive death/respawn/clone.
        PlayerEvent.Clone.BUS.addListener(TvaEvents::onPlayerClone);
    }

    private static void onPlayerClone(PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof Player newPlayer)) {
            return;
        }
        CompoundTag original = event.getOriginal().getPersistentData();
        CompoundTag clone = newPlayer.getPersistentData();
        String[] keys = {"tva_marks", "tva_eot_x", "tva_eot_y", "tva_eot_z", "tva_eot_dim",
                "tva_anchor", "tva_charge_tempad", "tva_freeze_cooldown"};
        for (String key : keys) {
            if (original.contains(key)) {
                clone.put(key, original.get(key).copy());
            }
        }
    }

    // ==================================================================
    // Interaction
    // ==================================================================

    private static boolean onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();

        // Charging in mid-air needs sneaking so it never steals a travel tap.
        if (player.isShiftKeyDown() && tryChargeFromHand(player, event.getHand(), player.blockPosition())) {
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        if (stack.is(ModContent.TEMPAD.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                TemPadMenu.open(serverPlayer);
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }
        if (stack.is(ModContent.MOBIUS_MOBILE.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                MobileAbilities.pushState(serverPlayer);
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }
        if (stack.is(ModContent.VARIANT_SCANNER.get())) {
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        return false;
    }

    private static boolean onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        BlockPos pos = event.getPos();
        Level level = event.getLevel();
        BlockState state = level.getBlockState(pos);
        InteractionHand hand = event.getHand();

        // Using a storage block starts tracking it, whatever else this click
        // ends up doing.
        if (player instanceof ServerPlayer serverPlayer) {
            TimelineItems.onContainerTouched(serverPlayer.level(), pos);
        }

        // A Chrono Battery in either hand tops up the gadget in the other one.
        //
        // Sneaking is required. Without it, simply having a battery in your
        // offhand silently ate every block right-click, so the player could not
        // place or break anything - charging must never steal an ordinary
        // interaction.
        if (player.isShiftKeyDown() && tryChargeFromHand(player, hand, pos)) {
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        // Arc Reactors are a free charging station: sneak-right-click one while
        // holding a gadget to top it up without burning a battery.
        if (state.is(ModContent.ARC_REACTOR.get()) && player.isShiftKeyDown()) {
            ItemStack gadget = gadgetInEitherHand(player);
            if (gadget != null) {
                if (player instanceof ServerPlayer serverPlayer) {
                    chargeGadget(serverPlayer, gadget, pos, false);
                }
                event.setCancellationResult(InteractionResult.SUCCESS);
                return true;
            }
        }

        // Time doors.
        if (state.is(ModContent.TIME_DOOR.get())) {
            ItemStack gadget = gadgetInEitherHand(player);
            if (gadget != null && gadget.is(ModContent.TEMPAD.get())) {
                // The TemPad always opens its destination menu, door or not.
                if (player instanceof ServerPlayer serverPlayer) {
                    TemPadMenu.open(serverPlayer);
                }
                event.setCancellationResult(InteractionResult.SUCCESS);
                return true;
            }

            // Bare handed: toggle the door.
            TimeDoorBlock.setOpen(level, pos, !state.getValue(TimeDoorBlock.OPEN));
            level.playSound(null, pos,
                    state.getValue(TimeDoorBlock.OPEN) ? SoundEvents.BEACON_DEACTIVATE : SoundEvents.BEACON_ACTIVATE,
                    SoundSource.BLOCKS, 0.7F, 1.2F);
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.PORTAL,
                        pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5, 24, 0.4, 0.6, 0.4, 0.05);
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        // Right-clicking anything with the TemPad opens the destination menu.
        // Sneaking drops a mark where you stand without opening it.
        if (stack.is(ModContent.TEMPAD.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                if (player.isShiftKeyDown()) {
                    markHere(serverPlayer);
                } else {
                    TemPadMenu.open(serverPlayer);
                }
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        return false;
    }

    /**
     * Drops a mark where the player is standing - the quick version of the
     * menu's "make mark" button.
     */
    private static void markHere(ServerPlayer player) {
        ServerLevel level = player.level();
        BlockPos standing = player.blockPosition();
        BlockPos safe = TimeTravel.nearestSafe(level, standing);

        TvaMarks.add(player, level, safe.getX(), safe.getY(), safe.getZ());
        TvaFeedback.actionBar(player, TvaMessages.markMade(String.valueOf(TvaMarks.of(player).size())));

        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                safe.getX() + 0.5, safe.getY() + 1.0, safe.getZ() + 0.5, 16, 0.4, 0.6, 0.4, 0.02);
        level.playSound(null, safe, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8F, 1.6F);
    }

    private static boolean onEntityInteract(PlayerInteractEvent.EntityInteractSpecific event) {
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        Entity target = event.getTarget();

        // Bare hands work too: sneaking on a collared creature with an
        // empty hand pops your collar straight back off, before any
        // vanilla or held-item interaction gets a look in. Only runs on
        // the server, where the collar ledger lives.
        if (stack.isEmpty() && player.isShiftKeyDown()
                && player instanceof ServerPlayer agent
                && com.tvatech.system.TimeCollar.remove(target, agent.getUUID())) {
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        if (stack.is(ModContent.VARIANT_SCANNER.get())) {
            if (player instanceof ServerPlayer serverPlayer && target.isAlive()) {
                if (TimeTravel.variant(target) == 0) {
                    int variant = 100 + Math.abs(target.getUUID().hashCode() % 900);
                    TimeTravel.setVariant(target, variant);
                    TvaFeedback.actionBar(serverPlayer, TvaMessages.scannerTagged(TvaEntityName.of(target), variant));
                    serverPlayer.level().playSound(null, target.blockPosition(),
                            SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.9F, 1.6F);
                } else {
                    TvaFeedback.actionBar(serverPlayer, TvaMessages.alreadyScanned(TvaEntityName.of(target),
                            TimeTravel.variant(target)));
                }
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        if (stack.is(ModContent.TEMPAD.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                if (!TvaConfig.allowPruning) {
                    TvaFeedback.actionBar(serverPlayer, TvaMessages.pruningDisabled());
                } else if (target instanceof net.minecraft.world.entity.LivingEntity) {
                    Pruning.prune(target, serverPlayer);
                } else {
                    Pruning.pruneNonLiving(target);
                }
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            return true;
        }

        return false;
    }

    /** Sells the collar back at the death spot instead of losing it. */
    private static void onLivingDeath(LivingDeathEvent event) {
        com.tvatech.system.TimeCollar.dropOnDeath(event.getEntity());
    }

    // ==================================================================
    // Ticks
    // ==================================================================

    private static void onPlayerTick(TickEvent.PlayerTickEvent.Post event) {
        Player player = event.player();
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        if (serverPlayer.tickCount % 20 == 0) {
            MobileAbilities.tickCooldown(serverPlayer);
        }
        ChronoFreeze.tickFor(serverPlayer);
    }

    // ==================================================================
    // Respawn
    // ==================================================================

    private static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        var anchor = TvaData.anchor(player);
        if (anchor == null) {
            return;
        }
        TvaData.clearAnchor(player);

        var dimString = anchor.getString("dim").orElse("");
        ServerLevel level = null;
        for (var candidate : player.level().getServer().getAllLevels()) {
            if (candidate.dimension().identifier().toString().equals(dimString)) {
                level = candidate;
                break;
            }
        }
        if (level == null) {
            return;
        }
        var wanted = new BlockPos(
                anchor.getInt("x").orElse(0),
                anchor.getInt("y").orElse(0),
                anchor.getInt("z").orElse(0));
        var safe = TimeTravel.nearestSafe(level, wanted);

        // The event fires straight after vanilla placed the player, so this wins.
        player.teleportTo(level, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5,
                java.util.Set.of(), player.getYRot(), player.getXRot(), true);

        TimeTravel.log(player, "Returned from the void at " + TimeTravel.describe(level, safe));
        TvaFeedback.actionBar(player, TvaMessages.prunedRespawn());
        level.sendParticles(ParticleTypes.PORTAL,
                safe.getX() + 0.5, safe.getY() + 1.0, safe.getZ() + 0.5, 60, 0.6, 1.0, 0.6, 0.1);
        level.playSound(null, safe, SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.8F, 0.9F);
    }

    // ==================================================================
    // Small helpers
    // ==================================================================

    private static ItemStack otherHand(InteractionHand hand, Player player) {
        return hand == InteractionHand.MAIN_HAND ? player.getOffhandItem() : player.getMainHandItem();
    }

    /** The TemPad or Mobius Mobile in either hand, or null. */
    private static ItemStack gadgetInEitherHand(Player player) {
        ItemStack main = player.getMainHandItem();
        if (isGadget(main)) {
            return main;
        }
        ItemStack off = player.getOffhandItem();
        return isGadget(off) ? off : null;
    }

    private static boolean isGadget(ItemStack stack) {
        return stack.is(ModContent.TEMPAD.get()) || stack.is(ModContent.MOBIUS_MOBILE.get());
    }

    /** The Chrono Battery in either hand, or null. */
    private static ItemStack batteryInEitherHand(Player player) {
        ItemStack main = player.getMainHandItem();
        if (main.is(ModContent.CHRONO_BATTERY.get())) {
            return main;
        }
        ItemStack off = player.getOffhandItem();
        return off.is(ModContent.CHRONO_BATTERY.get()) ? off : null;
    }

    /**
     * Charges the gadget with a Chrono Battery held in the other hand.
     *
     * <p>Works in both hand arrangements - which matters, because when the
     * gadget is in the main hand the offhand is never consulted by vanilla:
     * the gadget's own handling runs first and cancels the event.</p>
     *
     * @return true when a charge was consumed (the caller should cancel)
     */
    private static boolean tryChargeFromHand(Player player, InteractionHand hand, BlockPos pos) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return false;
        }
        ItemStack battery = batteryInEitherHand(player);
        ItemStack gadget = gadgetInEitherHand(player);
        if (battery == null || gadget == null) {
            return false;
        }
        // Only spend the battery if it actually went into the gadget.
        if (chargeGadget(serverPlayer, gadget, pos, true) && !serverPlayer.getAbilities().instabuild) {
            battery.shrink(1);
        }
        return true;
    }

    /**
     * Adds charge to a gadget and plays the feedback.
     *
     * @param fromBattery {@code true} when a Chrono Battery is spent for it,
     *                    {@code false} when an Arc Reactor powered it
     * @return {@code true} if the gadget gained charge
     */
    private static boolean chargeGadget(ServerPlayer player, ItemStack gadget, BlockPos pos, boolean fromBattery) {
        int before = TimeTravel.charge(gadget);
        TimeTravel.addCharge(gadget, TvaConfig.batteryCharge);

        ServerLevel level = player.level();
        boolean gained = TimeTravel.charge(gadget) > before;
        if (gained) {
            TvaFeedback.actionBar(player, TvaMessages.charged(TvaConfig.batteryCharge));
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8F, 1.4F);
        } else {
            TvaFeedback.actionBar(player, TvaMessages.alreadyCharged());
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                fromBattery ? 12 : 24, 0.4, 0.5, 0.4, 0.03);
        if (!fromBattery) {
            level.playSound(null, pos, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 0.7F, 1.5F);
        }
        return gained;
    }
}