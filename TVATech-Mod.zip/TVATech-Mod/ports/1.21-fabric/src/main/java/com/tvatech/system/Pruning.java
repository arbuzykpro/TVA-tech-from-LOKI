package com.tvatech.system;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import com.tvatech.TvaMessages;
import com.tvatech.util.TvaData;
import com.tvatech.util.TvaEntityName;
import com.tvatech.util.TvaFeedback;
import com.tvatech.util.TvaEntityName;

/**
 * Pruning: the TVA's way of removing a variant from the timeline.
 *
 * <p>A pruned living thing simply drops out of existence - no drops, no
 * experience, no death animation, just a burst of temporal particles and a
 * purple flash. Exactly what should happen to something that stopped being
 * canon.</p>
 */
public final class Pruning {

    private Pruning() {}

    /** Removes an entity from the timeline without any loot or experience. */
    public static boolean prune(Entity target, ServerPlayer pruner) {
        if (!(target instanceof LivingEntity living) || !living.isAlive()) {
            return false;
        }
        if (!(target.level() instanceof ServerLevel level)) {
            return false;
        }

        String name = TvaEntityName.of(living);

        // Visual: a column of soul fire collapsing inward.
        level.sendParticles(ParticleTypes.SOUL, living.getX(), living.getY() + living.getBbHeight() / 2.0,
                living.getZ(), 40, living.getBbWidth() / 2.0, living.getBbHeight() / 2.0,
                living.getBbWidth() / 2.0, 0.02);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, living.getX(), living.getY() + living.getBbHeight() / 2.0,
                living.getZ(), 25, 0.4, living.getBbHeight() / 2.0, 0.4, 0.05);
        level.playSound(null, living.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.6F, 0.7F);
        level.playSound(null, living.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.8F, 1.6F);

        // DISCARDED removal = no death handling, therefore no drops and no XP.
        living.remove(Entity.RemovalReason.DISCARDED);

        if (pruner != null) {
            TvaFeedback.actionBar(pruner, TvaMessages.pruned(name));
            TimeTravel.log(pruner, "Pruned variant " + name);
            TimeTravel.bumpVariant(pruner);
        }
        return true;
    }

    /** Keeps a "just pruned" marker useful even for non-living extras (item frames, paintings). */
    public static void pruneNonLiving(Entity target) {
        if (target.level() instanceof ServerLevel level) {
            level.playSound(null, target.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.6F, 1.8F);
        }
        target.discard();
    }

    /** Damage sources that count as pruning for the sake of the mobile's log. */
    public static boolean isTemporal(DamageSource source) {
        return source != null && source.getMsgId().contains("tvatech");
    }
}