package com.tvatech.util;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

/**
 * Display names for entities and players.
 *
 * <p>Players expose a profile name ({@code Optional<String>} in this Minecraft
 * version) while mobs go through the entity's display name, so the mod routes
 * every lookup through here.</p>
 */
public final class TvaEntityName {

    private TvaEntityName() {}

    public static String of(Entity entity) {
        if (entity instanceof net.minecraft.world.entity.player.Player player) {
            return player.getName().getString();
        }
        Component name = entity.getName();
        return name == null ? "?" : name.getString();
    }
}