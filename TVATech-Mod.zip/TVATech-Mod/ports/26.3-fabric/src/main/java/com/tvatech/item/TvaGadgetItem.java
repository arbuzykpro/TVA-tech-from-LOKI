package com.tvatech.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

import java.util.function.Consumer;

/**
 * Base class for the TVA gadgets: a plain item that adds a few lore lines.
 *
 * <p>Tooltips are generated here rather than in a central table so each gadget
 * can show the numbers that actually matter for it.</p>
 */
public class TvaGadgetItem extends Item {

    @FunctionalInterface
    public interface TooltipBuilder {
        void build(TvaGadgetItem item, ItemStack stack, Consumer<Component> lines);
    }

    private final TooltipBuilder tooltipBuilder;

    public TvaGadgetItem(Properties properties, TooltipBuilder tooltipBuilder) {
        super(properties);
        this.tooltipBuilder = tooltipBuilder;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display,
                                Consumer<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, context, display, lines, flag);
        if (tooltipBuilder != null) {
            tooltipBuilder.build(this, stack, lines);
        }
    }

    public static Component grey(String key, Object... args) {
        return Component.translatable(key, args).withStyle(ChatFormatting.GRAY);
    }

    public static Component aqua(String key, Object... args) {
        return Component.translatable(key, args).withStyle(ChatFormatting.AQUA);
    }
}