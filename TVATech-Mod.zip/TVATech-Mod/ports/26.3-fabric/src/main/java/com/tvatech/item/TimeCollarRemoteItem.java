package com.tvatech.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.tvatech.system.TimeCollar;
import com.tvatech.util.TvaFeedback;

import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * The time collar remote: the little order-giver.
 *
 * <p>Right-click while facing a creature wearing one of your collars and its
 * last five seconds are rolled back: it blinks out of where it stands and
 * pops back where it was standing when the rewind began. Anybody facing the
 * wrong way - or facing something that is not wearing your collar - gets a
 * gentle reminder about the rules.</p>
 */
public class TimeCollarRemoteItem extends TvaGadgetItem {

    /** How far the remote's gaze reaches. */
    private static final double REACH = 20.0;

    public TimeCollarRemoteItem(Properties properties) {
        super(properties, TimeCollarRemoteItem::tooltip);
    }

    private static void tooltip(TvaGadgetItem item, ItemStack stack, Consumer<Component> lines) {
        lines.accept(grey("tvatech.tooltip.remote_1"));
        lines.accept(grey("tvatech.tooltip.remote_2"));
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(player instanceof net.minecraft.server.level.ServerPlayer agent)) {
            return InteractionResult.PASS;
        }
        LivingEntity target = lookTarget(player);
        if (target == null) {
            TvaFeedback.actionBar(agent, Component.translatable("tvatech.remote.nobody"));
            return InteractionResult.FAIL;
        }
        if (TimeCollar.rewind(target, agent.getUUID())) {
            return InteractionResult.SUCCESS;
        }
        TvaFeedback.actionBar(agent, Component.translatable("tvatech.remote.noback"));
        return InteractionResult.FAIL;
    }

    /**
     * Finds the collared creature the holder is facing: the closest one whose
     * body meets the gaze line within reach.
     */
    private static LivingEntity lookTarget(Player player) {
        UUID placer = player.getUUID();
        Vec3 eye = player.getEyePosition();
        Vec3 dir = player.getLookAngle().normalize();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (double d = 0.5; d <= REACH; d += 0.5) {
            Vec3 at = eye.add(dir.scale(d));
            List<LivingEntity> found = player.level().getEntitiesOfClass(LivingEntity.class,
                    new AABB(at, at).inflate(0.9, 0.9, 0.9),
                    e -> e != player && TimeCollar.wearingFor(e, placer));
            for (LivingEntity candidate : found) {
                double dist = candidate.getEyePosition().distanceTo(eye);
                if (dist < bestDist) {
                    best = candidate;
                    bestDist = dist;
                }
            }
            if (best != null && d > 1.0 && bestDist < d - 1.0) {
                // Nothing closer can appear further along the ray.
                break;
            }
        }
        return best;
    }
}
