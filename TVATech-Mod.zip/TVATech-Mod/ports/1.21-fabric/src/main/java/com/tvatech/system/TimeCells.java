package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import com.tvatech.TVATech;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Time cells: the red doorway you cannot walk out of.
 *
 * <p>With the TemPad's TIME CELLS setting on, the door it opens runs red -
 * and whoever steps through it is taken by it: they land high in the sky
 * above the destination and are lifted straight back up the moment they
 * touch ground, falling again and again. Nothing in the cell hurts them
 * (fall damage simply does not apply while the cell holds you), but the
 * cell does twist the clock instead: the world runs twenty times faster
 * while somebody is held in one.</p>
 *
 * <p>There is exactly one way out: opening a door with your own TemPad.
 * The moment a prisoner pulls out a TemPad again - to travel anywhere, or
 * even just to open another door - the cell lets them go. That is the
 * "come back" clause.</p>
 */
public final class TimeCells {

    private TimeCells() {}

    /** How much faster the clock runs while a cell holds someone. */
    public static final int TIME_BOOST = 20;

    /** How high above the ground a prisoner starts falling from. */
    private static final int DROP_ABOVE_GROUND = 80;

    /**
     * Id of the fall-damage-off modifier. 26.3 keys attribute modifiers by
     * Identifier; the 1.21 branches key them by ResourceLocation, so this one
     * line is the only thing that differs between the two flavors.
     */
    private static final net.minecraft.resources.ResourceLocation CELL_KEY =
            net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(TVATech.MODID, "time_cell");

    /** Where one prisoner is held. */
    private record Trap(ServerLevel level, BlockPos anchor) {}

    private static final Map<UUID, Trap> VICTIMS = new HashMap<>();

    // ------------------------------------------------------------------
    // Taking someone
    // ------------------------------------------------------------------

    /**
     * Puts one creature into a cell at the destination: remembered, made
     * fall-damage-proof, then launched from the sky.
     */
    public static void trap(Entity entity, TimedoorPortal.Destination destination) {
        ServerLevel target;
        BlockPos anchor;
        if (destination.tva()) {
            // Past the first hour: held in a fall above the landing gate.
            ServerLevel tva = entity.level().getServer().getLevel(TemPadMenu.TVA);
            if (tva == null) {
                return;
            }
            TvaVault.ensureBuilt(tva, new BlockPos(0, TvaVault.FLOOR_Y, 0));
            target = tva;
            anchor = new BlockPos(0, TvaVault.FLOOR_Y + 1, TvaVault.ARRIVAL_Z);
        } else {
            target = destination.level();
            anchor = destination.pos().immutable();
        }
        dropIn(entity, target, anchor);
    }

    private static void dropIn(Entity entity, ServerLevel target, BlockPos anchor) {
        VICTIMS.put(entity.getUUID(), new Trap(target, anchor));
        suppressFallDamage(entity);
        launch(entity, target, anchor);    }

    /** Throws a prisoner back up and lets them drop. */
    private static void launch(Entity entity, ServerLevel level, BlockPos anchor) {
        int x = anchor.getX();
        int z = anchor.getZ();
        int ground = Math.max(anchor.getY(),
                level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z));
        int sky = ground + DROP_ABOVE_GROUND;
        double sx = x + 0.5;
        double sz = z + 0.5;

        TimedoorPortal.moveEntity(entity, level, sx, sky, sz);
        entity.setDeltaMovement(Vec3.ZERO);
        entity.resetFallDistance();

        level.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                sx, sky, sz, 30, 0.6, 0.8, 0.6, 0.05);
        level.playSound(null, x, sky, z, SoundEvents.PORTAL_TRAVEL,
                SoundSource.PLAYERS, 0.8F, 0.6F);
    }

    // ------------------------------------------------------------------
    // Holding
    // ------------------------------------------------------------------

    /** Called once per server tick: the clock runs hot and prisoners drop. */
    public static void tick(MinecraftServer server) {
        if (VICTIMS.isEmpty()) {
            return;
        }
        // 20x faster: the natural tick still moves the clock by one, so the
        // boost is the remaining nineteen.
        WorldTime.fastForward(server.overworld(), TIME_BOOST - 1);

        for (Map.Entry<UUID, Trap> line : new ArrayList<>(VICTIMS.entrySet())) {
            Trap trap = line.getValue();
            Entity victim = trap.level().getEntity(line.getKey());
            if (victim == null || victim.isRemoved()) {
                // Offline or out of tracking: the cell keeps the reservation.
                continue;
            }
            suppressFallDamage(victim);
            boolean grounded = victim.onGround() || victim.isInWater();
            if (grounded) {
                launch(victim, trap.level(), trap.anchor());
            }
        }
    }

    // ------------------------------------------------------------------
    // Letting someone go
    // ------------------------------------------------------------------

    /**
     * Releases a prisoner. Only ever called for someone who reached for
     * their TemPad again - a door builds, the cell gives up its hold.
     */
    public static void release(UUID who) {
        Trap trap = VICTIMS.remove(who);
        if (trap == null) {
            return;
        }
        Entity entity = trap.level().getEntity(who);
        if (entity instanceof LivingEntity living) {
            AttributeInstance attr = living.getAttribute(Attributes.FALL_DAMAGE_MULTIPLIER);
            if (attr != null && attr.hasModifier(CELL_KEY)) {
                AttributeModifier mod = attr.getModifier(CELL_KEY);
                if (mod != null) {
                    attr.removeModifier(mod);
                }
            }
        }
    }

    /** Anybody in a cell? (Unused today; the menu may want to ask later.) */
    public static boolean isHeld(UUID who) {
        return VICTIMS.containsKey(who);
    }

    // ------------------------------------------------------------------
    // the fall-damage switch
    // ------------------------------------------------------------------

    /** While the cell holds you, hitting the ground never hurts. */
    private static void suppressFallDamage(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return;
        }
        AttributeInstance attr = living.getAttribute(Attributes.FALL_DAMAGE_MULTIPLIER);
        if (attr != null && !attr.hasModifier(CELL_KEY)) {
            attr.addTransientModifier(new AttributeModifier(CELL_KEY, -1.0,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }
}
