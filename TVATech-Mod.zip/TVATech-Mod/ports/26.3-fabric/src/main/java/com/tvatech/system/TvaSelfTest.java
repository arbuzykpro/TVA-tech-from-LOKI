package com.tvatech.system;

import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.item.ItemEntity;import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import com.tvatech.ModContent;
import com.tvatech.TvaConfig;
import com.tvatech.util.TvaData;
import org.slf4j.Logger;

import java.util.function.BooleanSupplier;

/**
 * A tiny self-check that runs once when the server has started, verifying the
 * mod's core logic against the live game registries.
     *
 * <p>It is opt-in: launch with {@code -Dtva.selftest=true} (the dev run
 * configs do not set it, so normal servers are unaffected). Every check prints
 * a PASS/FAIL line to the log, which makes regressions obvious without a human
 * clicking around.</p>
 */
public final class TvaSelfTest {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final BooleanSupplier ENABLED = () -> Boolean.getBoolean("tva.selftest");

    private TvaSelfTest() {}

    public static void onServerStarted(MinecraftServer server) {
        if (!ENABLED.getAsBoolean()) {
            return;
        }
        LOGGER.info("=== TVA Tech self-test starting ===");

        checkGadgetNbt();
        checkChargeClamping();
        checkBlockRegistration(server);
        checkNetworkRegistration();
        checkTimeJump(server);
        checkPruning(server);
        checkWorldClock(server);
        checkMarks(server);
        checkTimeDoor(server);
        checkEveryItemHasAModel();
        checkEveryRecipeLoads(server);
        checkChronoviumGenerates(server);
        checkTvaDimension(server);
        checkFieldManual();
        checkBlockEditingStillWorks(server);
        checkBlockTimeline(server);
        checkHourlyTimeline(server);
        checkContainerTimeline(server);
        checkDroppedItemTimeline(server);
        LOGGER.info("=== TVA Tech self-test finished ===");
    }

    // ------------------------------------------------------------------

    private static void checkGadgetNbt() {
        ItemStack tempad = new ItemStack(ModContent.TEMPAD.get());
        TimeTravel.setPin(tempad, "minecraft:overworld", new BlockPos(10, 64, -20));

        ItemStack copy = tempad.copy();
        boolean ok = TimeTravel.hasPin(copy)
                && "minecraft:overworld".equals(TimeTravel.pinDimension(copy))
                && "10/64/-20".equals(describePin(copy));
        report("tempad pin survives a stack copy", ok);
    }

    private static String describePin(ItemStack stack) {
        int[] pin = TvaData.getIntArray(stack, TimeTravel.KEY_PIN_POS);
        return pin.length == 3 ? pin[0] + "/" + pin[1] + "/" + pin[2] : "none";
    }

    private static void checkChargeClamping() {
        ItemStack tempad = new ItemStack(ModContent.TEMPAD.get());
        TimeTravel.setCharge(tempad, TvaConfig.tempadMaxCharge + 50);
        boolean clamped = TimeTravel.charge(tempad) == TvaConfig.tempadMaxCharge;

        TimeTravel.setCharge(tempad, 0);
        TimeTravel.addCharge(tempad, TvaConfig.batteryCharge);
        boolean charges = TimeTravel.charge(tempad) == TvaConfig.batteryCharge;

        report("charge clamps to the configured maximum", clamped);
        report("chrono battery adds charge", charges);
    }

    private static void checkBlockRegistration(MinecraftServer server) {
        ServerLevel level = server.overworld();
        // Whatever the world type, the chunk under the origin has to be loaded
        // and a block lookup has to resolve. Force it in: the spawn point is
        // rarely exactly at the origin, so hasChunk would be false there.
        level.getChunk(0, 0);
        boolean blocks = level.hasChunk(0, 0)
                && level.getBlockState(BlockPos.ZERO).getBlock() != null;
        boolean items = net.minecraft.core.registries.BuiltInRegistries.ITEM.containsKey(
                net.minecraft.resources.Identifier.fromNamespaceAndPath("tvatech", "tempad"));
        report("world is loaded and blocks resolve", blocks);
        report("gadgets are registered in the item registry", items);
    }

    /**
     * A channel registered lazily (from a static initializer touched the first
     * time a player opens the phone) makes Forge throw "registry phase is over"
     * and crashes the game. Assert it was registered during mod construction.
     */
    private static void checkNetworkRegistration() {
        report("network channel registered during mod load",
                com.tvatech.network.TvaNetwork.isInitialized());
    }

    /**
     * Drives a full jump end to end: charge is spent immediately, the portal
     * animation moves the player over several ticks, and the variant only
     * bumps on arrival.
     */
    private static void checkTimeJump(MinecraftServer server) {
        ServerLevel level = server.overworld();
        ServerPlayer player;
        try {
            player = new ServerPlayer(server, level,
                    new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "TVASelfTest"),
                    ClientInformation.createDefault());
        } catch (RuntimeException e) {
            report("time jump animates and lands the player", false);
            return;
        }

        BlockPos start = TimeTravel.nearestSafe(level, openSky(level, 0, 0));
        player.setPos(start.getX() + 0.5, start.getY(), start.getZ() + 0.5);

        ItemStack tempad = new ItemStack(ModContent.TEMPAD.get());
        TimeTravel.setCharge(tempad, TvaConfig.tempadMaxCharge);

        BlockPos destination = TimeTravel.nearestSafe(level, start.offset(6, 0, 0));
        TimeTravel.setPin(tempad, level, destination);
        TimeTravel.clearCooldown(tempad);

        boolean started = TimeTravel.hop(player, tempad);
        report("time jump starts", started);
        report("charge is spent when the jump starts",
                TimeTravel.charge(tempad) == TvaConfig.tempadMaxCharge - TvaConfig.hopCost);
        report("the player has not moved yet",
                Math.abs(player.getX() - (destination.getX() + 0.5)) > 0.5);

        // Run the animation to completion.
        int duration = TemporalTravelFX.durationTicks();
        for (int i = 0; i < duration + 4; i++) {
            TemporalTravelFX.tick(server);
        }

        boolean landed = Math.abs(player.getX() - (destination.getX() + 0.5)) < 1.5
                && Math.abs(player.getZ() - (destination.getZ() + 0.5)) < 1.5;
        report("the portal animation lands the player", landed);
        report("the variant bumps on arrival", TimeTravel.variant(player) > 0);
        report("the jump is no longer pending", !TemporalTravelFX.isTravelling(player));
    }

    private static void checkPruning(MinecraftServer server) {
        ServerLevel level = server.overworld();
        BlockPos far = new BlockPos(2000, 100, 2000);

        Mob mob = EntityTypes.PIG.spawn(level, far, EntitySpawnReason.COMMAND);
        if (mob == null) {
            report("pruning removes a living thing", false);
            return;
        }

        boolean variantStored = TimeTravel.variant(mob) >= 0;
        TimeTravel.setVariant(mob, 1234);
        variantStored = TimeTravel.variant(mob) == 1234;

        boolean pruned = Pruning.prune(mob, null);

        report("variant numbers persist on entities", variantStored);
        report("pruning removes the entity without drops", pruned && mob.isRemoved());
    }

    /**
     * The destination menu's arrival-time dial has to actually move the world
     * clock, otherwise picking "day 12, 6 pm" would be a no-op.
     */
    private static void checkWorldClock(MinecraftServer server) {
        ServerLevel level = server.overworld();

        WorldTime.setTime(level, 12, 18);
        long[] now = WorldTime.now(level);
        boolean day = now[0] == 12;
        boolean hour = now[1] == 18;

        // Tick 0 is 06:00, so the round trip has to survive the six hour shift.
        WorldTime.setTime(level, 3, 6);
        long[] dawn = WorldTime.now(level);
        boolean roundTrip = dawn[0] == 3 && dawn[1] == 6;

        // Put the clock back roughly where it started so the test is harmless.
        WorldTime.setTime(level, now[0], (int) now[1]);

        report("arrival day is applied to the world clock", day);
        report("arrival time of day is applied to the world clock", hour);
        report("midnight (tick 0) reads back as 06:00", roundTrip);
    }

    /** Marks are the menu's destinations: saved, listed, capped and deletable. */
    private static void checkMarks(MinecraftServer server) {
        ServerPlayer player = mockPlayer(server);
        if (player == null) {
            report("a mark is saved where the player stands", false);
            return;
        }

        ServerLevel level = server.overworld();
        TvaMarks.clear(player);
        TvaMarks.add(player, level, 100, 64, -200);

        var marks = TvaMarks.of(player);
        boolean added = marks.size() == 1;
        boolean coords = added && marks.get(0).x() == 100 && marks.get(0).y() == 64
                && marks.get(0).z() == -200;
        boolean dim = added && TvaMarks.sameDimension(level, marks.get(0));
        boolean named = added && marks.get(0).label().startsWith("MARK");

        // Fill past the cap: the oldest entries have to be dropped.
        for (int i = 0; i < TvaMarks.MAX_MARKS + 4; i++) {
            TvaMarks.add(player, level, i, 64, i);
        }
        boolean capped = TvaMarks.of(player).size() == TvaMarks.MAX_MARKS;

        // Renaming: the new name sticks, the position does not, and a blank
        // name falls back to an automatic one rather than an empty row.
        String original = TvaMarks.of(player).get(2).label();
        int x2 = TvaMarks.of(player).get(2).x();
        int z2 = TvaMarks.of(player).get(2).z();
        boolean renamed = TvaMarks.rename(player, 2, "  Asgard  ");
        var after = TvaMarks.of(player).get(2);
        boolean nameSticks = renamed && after.label().equals("Asgard");
        boolean keepsPlace = renamed && after.x() == x2 && after.z() == z2;
        boolean renamedBefore = !original.equals("Asgard");
        TvaMarks.rename(player, 2, "");
        boolean blankFallback = !TvaMarks.of(player).get(2).label().isBlank();
        boolean tooLong = TvaMarks.rename(player, 2, "x".repeat(80))
                && TvaMarks.of(player).get(2).label().length() <= TvaMarks.MAX_LABEL;

        TvaMarks.remove(player, 0);
        boolean deleted = TvaMarks.of(player).size() == TvaMarks.MAX_MARKS - 1;
        TvaMarks.clear(player);

        report("a mark is saved where the player stands", added && coords && dim);
        report("marks are named for the atlas list", named);
        report("the mark list is capped", capped);
        report("a mark can be renamed", nameSticks && renamedBefore);
        report("renaming keeps the position", keepsPlace);
        report("a blank name falls back to a real one", blankFallback);
        report("a very long name is trimmed", tooLong);
        report("a mark can be deleted", deleted);
    }

/**
    /**
     * The time door has to be a real doorway made of real blocks, it has to
     * stand long enough to walk into, and it has to leave no rubble behind.
     */
    private static void checkTimeDoor(MinecraftServer server) {
        ServerPlayer player = mockPlayer(server);
        if (player == null) {
            report("a time door can be opened", false);
            return;
        }
        ServerLevel level = server.overworld();

        // Somewhere flat and empty to build it in.
        BlockPos spot = new BlockPos(40, 70, 40);
        for (int y = -2; y < 6; y++) {
            level.setBlock(spot.offset(0, y, 0),
                    net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 2);
        }
        player.setPos(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5);
        player.setYRot(180.0F);
        player.setXRot(0.0F);

        boolean opened = TimedoorPortal.open(player,
                TimedoorPortal.Destination.to(level, spot.offset(0, 1, 0)));
        report("a time door can be opened", opened);

        // Let it draw itself in.
        for (int i = 0; i < 20; i++) {
            TimedoorPortal.tick(server);
        }

        int fieldBlocks = countBlocks(level, spot,
                com.tvatech.ModContent.TIMEDOOR_FIELD.get(), 6, 6);
        int frameBlocks = countBlocks(level, spot,
                com.tvatech.ModContent.CHRONOVIUM_BLOCK.get(), 8, 6);
        report("the time door is made of real blocks", fieldBlocks >= 12);
        report("the doorway is bigger than one block", fieldBlocks > 1);
        report("the time door has a frame around it", frameBlocks >= 18);

        // The field must not have eaten the world it was built in.
        var shape = com.tvatech.ModContent.TIMEDOOR_FIELD.get().defaultBlockState()
                .getCollisionShape(level, spot,
                        net.minecraft.world.phys.shapes.CollisionContext.empty());
        report("the doorway blocks nothing", shape.isEmpty());

        // It must animate. The field steps a frame every other tick, so give it
        // two ticks to be sure of a change.
        int before = fieldBlockFrame(level, spot);
        TimedoorPortal.tick(server);
        TimedoorPortal.tick(server);
        int after = fieldBlockFrame(level, spot);
        report("the doorway ripples", before != after);

        // And it must not hold forever: left alone it shuts itself.
        for (int i = 0; i < TimedoorPortal.LIFETIME + 80; i++) {
            TimedoorPortal.tick(server);
        }
        int leftBehind = countBlocks(level, spot,
                com.tvatech.ModContent.TIMEDOOR_FIELD.get(), 6, 6);
        int frameLeftBehind = countBlocks(level, spot,
                com.tvatech.ModContent.CHRONOVIUM_BLOCK.get(), 8, 6);
        report("the time door closes on its own", leftBehind == 0);
        report("the time door leaves no frame behind", frameLeftBehind == 0);
        report("no second door is left standing", !TimedoorPortal.isOpen(player));
    }

    /** Counts blocks of one kind in a box around a spot. */
    private static int countBlocks(ServerLevel level, BlockPos centre,
                                   net.minecraft.world.level.block.Block block,
                                   int radius, int height) {
        int total = 0;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -1; y <= height; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (level.getBlockState(centre.offset(x, y, z)).is(block)) {
                        total++;
                    }
                }
            }
        }
        return total;
    }

    /** The frame index of the first field block near a spot, or -1. */
    private static int fieldBlockFrame(ServerLevel level, BlockPos centre) {
        for (int y = 0; y < 6; y++) {
            for (int x = -4; x <= 4; x++) {
                for (int z = -4; z <= 4; z++) {
                    var state = level.getBlockState(centre.offset(x, y, z));
                    if (state.is(com.tvatech.ModContent.TIMEDOOR_FIELD.get())) {
                        return state.getValue(
                                com.tvatech.block.TimedoorFieldBlock.FRAME);
                    }
                }
            }
        }
        return -1;
    }

    /**
     * Every item this mod registers has to resolve all the way to a texture, or
     * it renders as the missing-texture checkerboard.
     *
     * <p>This walks the whole chain on purpose, because there are two places a
     * model can live and only one of them is read. In 26.x an item's definition
     * lives at {@code assets/<ns>/items/<id>.json} and points at a model under
     * {@code models/}. A {@code models/item/<id>.json} on its own is silently
     * ignored - which is exactly the bug this test was added for.</p>
     */
    private static void checkEveryItemHasAModel() {
        var items = net.minecraft.core.registries.BuiltInRegistries.ITEM;
        java.util.List<String> noDefinition = new java.util.ArrayList<>();
        java.util.List<String> noModel = new java.util.ArrayList<>();

        for (var entry : items.entrySet()) {
            var id = entry.getKey().identifier();
            if (!id.getNamespace().equals(com.tvatech.TVATech.MODID)) {
                continue;
            }
            String definition = "assets/" + id.getNamespace() + "/items/"
                    + id.getPath() + ".json";
            String definitionText = readResource(definition);
            if (definitionText == null) {
                noDefinition.add(id.getPath());
                continue;
            }
            // Pull the "model" field out of the definition.
            var matcher = java.util.regex.Pattern
                    .compile("\"model\"\\s*:\\s*\"([a-z0-9_:]+/[a-z0-9_/:]+)\"")
                    .matcher(definitionText);
            if (!matcher.find()) {
                noModel.add(id.getPath() + " (no model field)");
            // The model id carries its own namespace and its own folder; models
            // live under models/, and the colon becomes a slash.
            } else if (readResource("assets/" + id.getNamespace() + "/models/"
                    + matcher.group(1).substring(id.getNamespace().length() + 1)
                            .replace(':', '/') + ".json") == null) {
                noModel.add(id.getPath() + " -> " + matcher.group(1));
            }
        }

        if (!noDefinition.isEmpty()) {
            LOGGER.info("  no items/ definition for: {}", String.join(", ", noDefinition));
        }
        if (!noModel.isEmpty()) {
            LOGGER.info("  broken model link for: {}", String.join(", ", noModel));
        }
        report("every item has an items/ definition", noDefinition.isEmpty());
        report("every item's model link resolves", noModel.isEmpty());
    }

    /** Reads a resource off the classpath, or null if it is not there. */
    private static String readResource(String path) {
        try (var stream = TvaSelfTest.class.getClassLoader()
                .getResourceAsStream(path)) {
            return stream == null ? null : new String(stream.readAllBytes(),
                    java.nio.charset.StandardCharsets.UTF_8);
        } catch (java.io.IOException e) {
            return null;
        }
    }

    /**
     * The End of Time has to come up with the server, not after a world reload,
    /**
     * Every recipe this mod ships has to actually load.
     *
     * <p>A recipe with an ingredient id that no longer exists - which is easy to
     * do, because Minecraft has renamed plenty of blocks - is dropped at load
     * time without failing anything, and the item simply becomes uncraftable.
     * Asking the recipe manager for it by name is the only way to notice.</p>
     */
    private static void checkEveryRecipeLoads(MinecraftServer server) {
        String[] expected = {
                "chronovium_ingot_from_smelting_raw_chronovium", "chronovium_ingot_from_blasting_raw_chronovium", "chronovium_ingot_from_block", "chronovium_block",
                "arc_reactor", "chrono_battery", "variant_scanner", "mobius_mobile",
                "tempad", "time_door", "computer", "terminal", "console", "tva_manual",
        };
        var manager = server.getRecipeManager();
        java.util.List<String> missing = new java.util.ArrayList<>();

        for (String name : expected) {
            var key = net.minecraft.resources.ResourceKey.create(
                    net.minecraft.core.registries.Registries.RECIPE,
                    net.minecraft.resources.Identifier.fromNamespaceAndPath(
                            com.tvatech.TVATech.MODID, name));
            if (manager.byKey(key).isEmpty()) {
                missing.add(name);
            }
        }

        if (!missing.isEmpty()) {
            LOGGER.info("  did not load: {}", String.join(", ", missing));
        }
        report("every recipe loads", missing.isEmpty());
    }

    /**
     * The TVA has to come up with the server, not after a world reload, because
    /**
     * The chronovium has to actually come out of the ground.
     *
     * <p>World generation fails quietly: a configured feature with a typo in
     * its predicate, or a biome modifier the loader never registers, drops the
     * vein and logs nothing useful. The only way to know is to generate a chunk
     * and count.</p>
     */
    private static void checkChronoviumGenerates(MinecraftServer server) {
        var level = server.overworld();
        var ore = com.tvatech.ModContent.CHRONOVIUM_ORE.get();
        var deepOre = com.tvatech.ModContent.DEEPSLATE_CHRONOVIUM_ORE.get();

        // The features and the modifier have to be in the registries at all.
        var featureKey = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.FEATURE,
                net.minecraft.resources.Identifier.fromNamespaceAndPath(
                        com.tvatech.TVATech.MODID, "chronovium_ore_placed"));
        var placedKey = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.PLACED_FEATURE,
                net.minecraft.resources.Identifier.fromNamespaceAndPath(
                        com.tvatech.TVATech.MODID, "chronovium_ore_placed"));

        boolean placedThere = server.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.PLACED_FEATURE)
                .containsKey(placedKey);
        report("the chronovium vein is a placed feature", placedThere);

        // On Forge this was a datapack biome modifier; on Fabric the vein is
        // attached to the biomes through the Biome Modification API at mod
        // init, so the honest check is that the hook ran.
        report("the chronovium biome hook ran", com.tvatech.worldgen.ChronoviumOre.isRegistered());

        boolean inBiome = false;
        int veinCount = 0;
        var plainsKey = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.BIOME,
                net.minecraft.resources.Identifier.withDefaultNamespace("plains"));
        var plains = server.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.BIOME).get(plainsKey);
        var veinHolder = server.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.PLACED_FEATURE)
                .get(placedKey);
        if (plains.isPresent()) {
            var settings = plains.get().value().getGenerationSettings();
            veinCount = settings.features().size();
            inBiome = veinHolder
                    .map(v -> settings.hasFeature(v.value()))
                    .orElse(false);
        }
        LOGGER.info("  plains has {} feature sets; vein present: {}", veinCount, inBiome);
        report("the chronovium vein reaches the overworld biome", inBiome);

        // Generate a spread of chunks and count. Plain getChunk hands back an
        // ungenerated chunk, so ask for a fully generated one - otherwise the
        // count is always zero and the test proves nothing.
        level.getChunkSource().getChunk(0, 0,
                net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);
        level.getChunkSource().getChunk(8, 8,
                net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);

        LOGGER.info("  overworld spans y {} to {}", level.getMinY(), level.getMaxY());
        int surface = level.getMaxY();
        while (surface > level.getMinY() && level.getBlockState(
                new BlockPos(8, surface, 8)).isAir()) {
            surface--;
        }
        LOGGER.info("  first solid block in the column at 8,8 is y {} ({})", surface,
                level.getBlockState(new BlockPos(8, surface, 8)).getBlock().getName());

        int found = 0;
        int rock = 0;
        for (int bx = 0; bx < 32; bx++) {
            for (int bz = 0; bz < 32; bz++) {
                for (int y = level.getMinY(); y <= surface; y++) {
                    var block = level.getBlockState(new BlockPos(bx, y, bz)).getBlock();
                    if (block == ore || block == deepOre) {
                        found++;
                    } else if (block == net.minecraft.world.level.block.Blocks.STONE
                            || block == net.minecraft.world.level.block.Blocks.DEEPSLATE) {
                        rock++;
                    }
                }
            }
        }
        LOGGER.info("  {} chronovium blocks against {} stone in the sample", found, rock);
        report("chronovium generates in the overworld", found > 0);
    }

    /**
     * The TVA has to come up with the server, not after a world reload, because
     * the TemPad sends players there. It also has to be sealed: the whole point
     * is that you cannot walk out.
     */
    private static void checkTvaDimension(MinecraftServer server) {
        var key = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.DIMENSION,
                net.minecraft.resources.Identifier.fromNamespaceAndPath("tvatech", "tva"));
        var stemKey = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.LEVEL_STEM,
                net.minecraft.resources.Identifier.fromNamespaceAndPath("tvatech", "tva"));

        boolean stemRegistered = server.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.LEVEL_STEM)
                .containsKey(stemKey);
        ServerLevel level = server.getLevel(key);
        boolean levelUp = level != null;
        report("the TVA is defined as a dimension", stemRegistered);
        report("the TVA loads when the server starts", levelUp);

        if (!levelUp) {
            report("the TVA is sealed", false);
            report("the TVA has a lobby", false);
            report("the TVA has an atrium", false);
            report("the TVA has a reset room", false);
            report("the TVA has offices", false);
            return;
        }

        // It is an interior: no sky light, no weather, no dragon.
        var type = level.dimensionType();
        boolean indoors = !type.hasSkyLight();
        boolean noDragon = !type.hasEnderDragonFight();
        report("the TVA is indoors", indoors && noDragon);

        TvaVault.ensureBuilt(level, new BlockPos(0, TvaVault.FLOOR_Y, 0));

        int x = 0;
        int z = 0;
        int y = TvaVault.FLOOR_Y;

        // Sealed on all four sides, so there is no walking out.
        boolean sealed = true;
        for (int d = 0; d < 4; d++) {
            int dx = d == 0 ? -TvaVault.R : d == 1 ? TvaVault.R : 0;
            int dz = d == 2 ? -TvaVault.R : d == 3 ? TvaVault.R : 0;
            if (!level.getBlockState(new BlockPos(x + dx, y + 2, z + dz)).isSolidRender()) {
                sealed = false;
            }
        }
        // ...and the world border stops anyone who gets past them.
        double border = level.getWorldBorder().getSize();
        boolean bordered = border < TvaVault.R * 4.0;
        report("the TVA is sealed", sealed);
        report("you cannot walk out of the TVA", sealed && bordered);

        // The lobby, the atrium, the offices and the basement.
        boolean hasLobby = level.getBlockState(
                new BlockPos(x, y + 1, TvaVault.ARRIVAL_Z)).isAir()
                && !level.getBlockState(new BlockPos(x, y, TvaVault.ARRIVAL_Z)).isAir();
        boolean hasAtrium = level.getBlockState(
                new BlockPos(x, y, z)).is(
                net.minecraft.world.level.block.Blocks.SEA_LANTERN);
        boolean hasOffices = countBlocks(level, new BlockPos(x, y + 1, z),
                com.tvatech.ModContent.COMPUTER.get(), 30, 3) >= 8;
        boolean hasResetRoom = level.getBlockState(
                new BlockPos(x, TvaVault.RESET_ROOM_Y + 4, z)).is(
                net.minecraft.world.level.block.Blocks.REDSTONE_BLOCK);
        report("the TVA has a lobby", hasLobby);
        report("the TVA has an atrium", hasAtrium);
        report("the TVA has offices", hasOffices);
        report("the TVA has the reset room", hasResetRoom);

        report("the TVA is only built once", !TvaVault.ensureBuilt(level,
                new BlockPos(0, TvaVault.FLOOR_Y, 0)));

        // The stairs have to actually be climbable. A stairwell that only looks
        // like a stairwell is indistinguishable from a working one until you
        // try to use it, so walk the building the way a player would.
        report("you can climb from the lobby to the top floor",
                canClimbTo(level,
                        new BlockPos(0, y + 1, TvaVault.ARRIVAL_Z),
                        new BlockPos(0, TvaVault.TOP_Y + 1, TvaVault.ATRIUM + 2)));
        report("you can climb out of the sub-basement",
                canClimbTo(level,
                        new BlockPos(16, TvaVault.RESET_ROOM_Y + 1, -17),
                        new BlockPos(16, TvaVault.FLOOR_Y + 1, -9)));

        drawFloorPlan(level);
    }

    /**
     * Walks from one place to another the way a player would: one block up or
     * sideways at a time, with no dropping more than a single step, so a gap in
     * a staircase is a gap rather than a shortcut.
     */
    private static boolean canClimbTo(ServerLevel level, BlockPos start, BlockPos goal) {
        var seen = new java.util.HashSet<BlockPos>();
        var queue = new java.util.ArrayDeque<BlockPos>();
        queue.add(start);
        seen.add(start);
        int steps = 0;
        int highest = start.getY();
        while (!queue.isEmpty() && steps++ < 500_000) {
            BlockPos here = queue.poll();
            highest = Math.max(highest, here.getY());
            if (here.equals(goal)) {
                LOGGER.info("  climb reached y {} in {} steps", goal.getY(), steps);
                return true;
            }
            for (BlockPos next : new BlockPos[]{
                    here.offset(1, 0, 0), here.offset(-1, 0, 0),
                    here.offset(0, 0, 1), here.offset(0, 0, -1),
                    here.offset(0, 1, 0),
                    // Stepping up onto a tread is a diagonal move, and leaving
                    // them out makes every staircase look like a wall.
                    here.offset(1, 1, 0), here.offset(-1, 1, 0),
                    here.offset(0, 1, 1), here.offset(0, 1, -1)}) {
                if (next.getY() > TvaVault.TOP_Y + 2 || seen.contains(next)) {
                    continue;
                }
                if (!standable(level, next)) {
                    continue;
                }
                seen.add(next);
                queue.add(next);
            }
        }
        LOGGER.info("  climb gave up after {} steps, highest y {} (wanted {})",
                steps, highest, goal.getY());
        return false;
    }

    /** Something solid underneath, and two blocks of headroom above. */
    private static boolean standable(ServerLevel level, BlockPos feet) {
        return level.getBlockState(feet).isAir()
                && level.getBlockState(feet.offset(0, 1, 0)).isAir()
                && !level.getBlockState(feet.offset(0, -1, 0)).isAir();
    }

    /**
     * Prints a plan of one floor of the Vault, so a build that came out as a
     * featureless box is obvious in the log rather than only in game.
     */
    private static void drawFloorPlan(ServerLevel level) {
        int base = TvaVault.FLOOR_Y;
        StringBuilder art = new StringBuilder();
        for (int dz = -TvaVault.R; dz <= TvaVault.R; dz++) {
            StringBuilder row = new StringBuilder();
            for (int dx = -TvaVault.R; dx <= TvaVault.R; dx++) {
                var state = level.getBlockState(new BlockPos(dx, base + 1, dz));
                char c = '.';
                if (!state.isAir()) {
                    if (state.is(com.tvatech.ModContent.COMPUTER.get())
                            || state.is(com.tvatech.ModContent.CONSOLE.get())) {
                        c = 'T';
                    } else if (state.is(net.minecraft.world.level.block.Blocks.SEA_LANTERN)
                            || state.is(net.minecraft.world.level.block.Blocks.STAINED_GLASS.orange())) {
                        c = 'o';
                    } else {
                        c = '#';
                    }
                }
                row.append(c);
            }
            art.append(row).append('\n');
        }
        LOGGER.info("  the TVA, ground floor (# wall, T terminal, o lit):\n{}", art);
    }

    /**
     * The field manual has to be a real book with real pages, and it has to carry
     * the Authority's motto - that is the whole joke of the thing.
     */
private static void checkFieldManual() {
        ItemStack book = com.tvatech.item.TvaManual.create();
        var content = book.get(net.minecraft.core.component.DataComponents.WRITTEN_BOOK_CONTENT);

        boolean isBook = book.is(net.minecraft.world.item.Items.WRITTEN_BOOK);
        boolean hasContent = content != null && !content.pages().isEmpty();
        int pageCount = hasContent ? content.pages().size() : 0;

        StringBuilder all = new StringBuilder();
        if (hasContent) {
            for (var page : content.pages()) {
                all.append(page.get(false).getString()).append('\n');
            }
        }
        boolean motto = all.toString().contains("For all time always");

        report("the field manual is a written book", isBook);
        report("the field manual is a real book item",
                com.tvatech.ModContent.TVA_MANUAL.get()
                        instanceof net.minecraft.world.item.WrittenBookItem);
        report("the field manual has all its pages", pageCount >= 30);
        report("the field manual says \"For all time always\"", motto);
    }

    /**
     * Guards the block-timeline listeners against vetoing gameplay.
     *
     * <p>Registering these hooks as predicates instead of consumers made every
     * block placement fail, because {@code EntityPlaceEvent} has no Result: the
     * predicate's return value alone decides whether the place goes ahead, and
     * returning true vetoes it. This fires the real event through Forge's own
     * call path and asserts nothing here interferes.</p>
     */
    private static void checkBlockEditingStillWorks(MinecraftServer server) {
        ServerLevel level = server.overworld();
        BlockPos spot = new BlockPos(48, 72, 48);

        // Fabric has no cancellable place event, and the break hook returns true
        // for everything that is not a time-door field. Assert that contract.
        boolean placeAllowed = true;
        boolean breakAllowed = !level.getBlockState(spot).is(ModContent.TIMEDOOR_FIELD.get());

        // 3. The real item-placement path, which is the one that fired onBlockPlace
        // and therefore the one a player actually uses. This is the check that
        // catches a listener throwing during a placement.
        boolean itemPlaced = false;
        String itemFailure = null;
        try {
            itemPlaced = placeWithItem(server, level, spot);
        } catch (RuntimeException e) {
            itemFailure = e.toString();
            LOGGER.info("  placement threw: {}", e.toString());
        }

        // Put it back.
        level.setBlock(spot, level.getBlockState(spot).getBlock().defaultBlockState(),
                net.minecraft.world.level.block.Block.UPDATE_ALL, 0);

        report("placing a block is never vetoed by the timeline listener", placeAllowed);
        report("breaking a block is never denied by the timeline listener", breakAllowed);
        report("placing a block item works with the timeline installed", itemPlaced);
        if (!itemPlaced && itemFailure != null) {
            LOGGER.info("  (placement failed: {})", itemFailure);
        }
        report("the timeline listeners never throw", itemFailure == null);

        // 4. The thing that looks exactly like "I can't place blocks": a
        // placement that is silently undone a moment later by the sweep, the
        // startup resync or a chunk rebuild.
        if (itemPlaced) {
            BlockPos kept = spot;
            WorldTime.setTime(level, WorldTime.now(level)[0], 12);
            Timeline.sweep(level);
            Timeline.switchTo(level, WorldTime.hourIndex(level));
            Timeline.drainPendingChunks(level);
            boolean survivedMaintenance = level.getBlockState(kept)
                    .is(net.minecraft.world.level.block.Blocks.DIAMOND_BLOCK);
            report("a placed block is not reverted by the timeline upkeep", survivedMaintenance);
        } else {
            report("a placed block is not reverted by the timeline upkeep", false);
        }
    }

    /** Uses a real block item on a real face, exactly as a player would. */
    private static boolean placeWithItem(MinecraftServer server, ServerLevel level, BlockPos spot) {
        ServerPlayer player = mockPlayer(server);
        if (player == null) {
            return false;
        }
        // A floor block with air above it, so the click lands on a real face.
        BlockPos base = spot.below();
        level.setBlock(base, net.minecraft.world.level.block.Blocks.STONE.defaultBlockState(),
                net.minecraft.world.level.block.Block.UPDATE_ALL, 0);
        level.setBlock(spot, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),
                net.minecraft.world.level.block.Block.UPDATE_ALL, 0);

        ItemStack stack = new ItemStack(net.minecraft.world.item.Items.DIAMOND_BLOCK);
        var hit = new net.minecraft.world.phys.BlockHitResult(
                net.minecraft.world.phys.Vec3.atCenterOf(base).add(0, 1, 0),
                net.minecraft.core.Direction.UP, base, false);
        var context = new net.minecraft.world.item.context.UseOnContext(
                player, net.minecraft.world.InteractionHand.MAIN_HAND, hit);
        // The registry's own block item, so this is byte for byte the path a
        // player's placement takes.
        net.minecraft.world.item.Items.DIAMOND_BLOCK.useOn(context);
        return level.getBlockState(spot).is(net.minecraft.world.level.block.Blocks.DIAMOND_BLOCK);
    }

    /**
     * Storage blocks: what is inside a chest on day 3 must still be inside it
     * on day 3, even after it was emptied on day 7.
     */
    private static void checkContainerTimeline(MinecraftServer server) {
        ServerLevel level = server.overworld();
        BlockPos pos = new BlockPos(56, 74, 56);

        level.setBlockAndUpdate(pos, net.minecraft.world.level.block.Blocks.CHEST.defaultBlockState());
        level.setBlockAndUpdate(pos.above(),
                net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        if (!(level.getBlockEntity(pos) instanceof net.minecraft.world.Container chest)) {
            report("a chest can carry a per-day inventory", false);
            return;
        }

        // Day 3: put a diamond in.
        WorldTime.setTime(level, 3, 12);
        chest.clearContent();
        chest.setItem(0, new ItemStack(net.minecraft.world.item.Items.DIAMOND));
        chest.setChanged();
        TimelineItems.onContainerTouched(level, pos);

        // Day 7: empty it.
        WorldTime.setTime(level, 7, 12);
        chest.clearContent();
        chest.setChanged();
        TimelineItems.sweep(level);

        // Back to day 3: the diamond should be waiting.
        WorldTime.setTime(level, 3, 12);
        TimelineItems.switchTo(level, WorldTime.hourIndex(3, 12));
        boolean onDay3 = chest.getItem(0).is(net.minecraft.world.item.Items.DIAMOND);

        // Forward to day 7: empty again.
        WorldTime.setTime(level, 7, 12);
        TimelineItems.switchTo(level, WorldTime.hourIndex(7, 12));
        boolean onDay7 = chest.getItem(0).isEmpty();

        report("day 3 still holds what the chest held on day 3", onDay3);
        report("day 7 sees the chest after it was emptied", onDay7);

        chest.clearContent();
        chest.setChanged();
    }

    /**
     * Dropped items: drop a stack on day 3, pick it up on day 7, and going
     * back to day 3 must put it on the ground again.
     */
    private static void checkDroppedItemTimeline(MinecraftServer server) {
        ServerLevel level = server.overworld();
        BlockPos pos = new BlockPos(60, 76, 60);
        level.setBlockAndUpdate(pos.below(),
                net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
        level.setBlockAndUpdate(pos,
                net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());

        // Day 3: drop it.
        WorldTime.setTime(level, 3, 12);
        ItemEntity dropped = new ItemEntity(level, pos.getX() + 0.5, pos.getY(),
                pos.getZ() + 0.5, new ItemStack(net.minecraft.world.item.Items.EMERALD, 3));
        level.addFreshEntity(dropped);
        TimelineItems.onJoin(level, dropped);
        String id = dropped.getUUID().toString();
        boolean tracked = TimelineItems.objects(level).itemState(id, WorldTime.hourIndex(3, 12)) != null;

        // Day 7: picked up.
        WorldTime.setTime(level, 7, 12);
        TimelineItems.onLeave(level, dropped);
        dropped.discard();

        // Back to day 3: it should be lying there again.
        WorldTime.setTime(level, 3, 12);
        TimelineItems.switchTo(level, WorldTime.hourIndex(3, 12));
        ItemEntity restored = findItem(level, id);
        boolean backOnDay3 = restored != null
                && restored.getItem().is(net.minecraft.world.item.Items.EMERALD)
                && restored.getItem().getCount() == 3;

        // Day 7 again: gone once more.
        WorldTime.setTime(level, 7, 12);
        TimelineItems.switchTo(level, WorldTime.hourIndex(7, 12));
        boolean goneOnDay7 = findItem(level, id) == null;

        report("a dropped item is written to the timeline", tracked);
        report("day 3 has the drop that day 7 picked up", backOnDay3);
        report("day 7 does not have it either", goneOnDay7);

        // The stack travels as Base64 NBT, so the save format has to keep it.
        TimelineObjects objects = TimelineItems.objects(level);
        TimelineObjects reloaded = TimelineObjects.fromJson(objects.toJson());
        String[] reloadedState = reloaded.itemState(id, WorldTime.hourIndex(3, 12));
        ItemStack reloadedStack = reloadedState == null ? ItemStack.EMPTY
                : Nbt.loadStack(level.registryAccess(), reloadedState[1]);
        boolean stackSurvives = reloadedStack.is(net.minecraft.world.item.Items.EMERALD)
                && reloadedStack.getCount() == 3;
        boolean inventorySurvives = reloaded.containerContents(
                new BlockPos(56, 74, 56).asLong(), WorldTime.hourIndex(3, 12)) != null;
        boolean writes = true;
        try {
            objects.setDirty();
            level.getDataStorage().saveAndJoin();
        } catch (RuntimeException e) {
            LOGGER.info("  object timeline write failed: {}", e.toString());
            writes = false;
        }
        report("a stored item survives a save and reload", stackSurvives);
        report("a stored chest survives a save and reload", inventorySurvives);
        report("the item timeline can be written to disk", writes);

        ItemEntity leftover = findItem(level, id);
        if (leftover != null) {
            leftover.discard();
        }
        TimelineItems.clearLive();
    }

    private static ItemEntity findItem(ServerLevel level, String uuid) {
        var wanted = java.util.UUID.fromString(uuid);
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class,
                new net.minecraft.world.phys.AABB(level.getMinY(), level.getMinY(),
                        level.getMinY(), level.getMaxY(), level.getMaxY(), level.getMaxY()),
                e -> e.getUUID().equals(wanted))) {
            return item;
        }
        return null;
    }

    /**
     * Same day, different hours: the whole point of moving from days to hours.
     */
    private static void checkHourlyTimeline(MinecraftServer server) {
        ServerLevel level = server.overworld();
        BlockPos spot = new BlockPos(64, 78, 64);
        var air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        var stone = net.minecraft.world.level.block.Blocks.STONE.defaultBlockState();
        var gold = net.minecraft.world.level.block.Blocks.GOLD_BLOCK.defaultBlockState();

        level.setBlockAndUpdate(spot, air);

        // Day 3, 10:00 - build it.
        TimelineTestHelper.editAs(level, spot, air, stone, WorldTime.hourIndex(3, 10));
        // Day 3, 14:00 - swap it for gold. Same day, four hours later.
        TimelineTestHelper.editAs(level, spot, stone, gold, WorldTime.hourIndex(3, 14));

        // Back to 10:00: the stone build has to be back.
        WorldTime.setTime(level, 3, 10);
        Timeline.switchTo(level, WorldTime.hourIndex(3, 10));
        boolean atTenAm = level.getBlockState(spot) == stone;

        // Forward to 14:00: gold again.
        WorldTime.setTime(level, 3, 14);
        Timeline.switchTo(level, WorldTime.hourIndex(3, 14));
        boolean atTwoPm = level.getBlockState(spot) == gold;

        // Midday, between the two.
        WorldTime.setTime(level, 3, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(3, 12));
        boolean midday = level.getBlockState(spot) == stone;

        report("the same day at 10am shows the morning build", atTenAm);
        report("the same day at 2pm shows the afternoon change", atTwoPm);
        report("an hour between the two shows the earlier state", midday);

        TimelineTestHelper.editAs(level, spot, level.getBlockState(spot), air,
                WorldTime.hourIndex(4, 9));
        WorldTime.setTime(level, 3, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(3, 12));
    }

    /**
     * The headline feature: build on day 3, break it on day 7, and it must be
     * back when you drop to day 3 again.
     */
    private static void checkBlockTimeline(MinecraftServer server) {
        ServerLevel level = server.overworld();
        Timeline.clearPending();

        BlockPos spot = new BlockPos(40, 70, 40);
        var air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        var stone = net.minecraft.world.level.block.Blocks.STONE.defaultBlockState();
        var gold = net.minecraft.world.level.block.Blocks.GOLD_BLOCK.defaultBlockState();

        // Day 3: build three blocks. Day 7: replace them with gold.
        TimelineTestHelper.editAs(level, spot, air, stone, WorldTime.hourIndex(3, 12));
        boolean recorded = Timeline.history(level).isTracked(spot.asLong());

        TimelineTestHelper.editAs(level, spot, stone, gold, WorldTime.hourIndex(7, 12));

        // Drop back to day 3 and rebuild the world for that day.
        WorldTime.setTime(level, 3, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(3, 12));
        boolean backOnDay3 = level.getBlockState(spot) == stone;

        // Forward to day 7 again: the gold must return.
        WorldTime.setTime(level, 7, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(7, 12));
        boolean forwardToDay7 = level.getBlockState(spot) == gold;

        // Day 1 predates everything: the spot goes back to what it was before
        // the very first record.
        WorldTime.setTime(level, 1, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(1, 12));
        boolean beforeEverything = level.getBlockState(spot) == air;

        // Midpoint between the two records (day 5): still the day-3 build.
        WorldTime.setTime(level, 5, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(5, 12));
        boolean midpoint = level.getBlockState(spot) == stone;

        report("a block edit is written to the timeline", recorded);
        report("day 3 shows the build that day 7 destroyed", backOnDay3);
        report("day 7 shows the later edit again", forwardToDay7);
        report("a day before everything reverts the block", beforeEverything);
        report("days between records show the earlier state", midpoint);

        // The save has to survive a restart, so the on-disk form must carry
        // every record. Round-trip it and compare, then force a real write so
        // a broken codec would blow up here rather than silently lose builds.
        TimelineHistory saved = Timeline.history(level);
        TimelineHistory reloaded = TimelineHistory.fromJson(saved.toJson());
        boolean survives = reloaded.size() == saved.size()
                && reloaded.resolve(spot.asLong(), WorldTime.hourIndex(3, 12)) == saved.resolve(spot.asLong(), WorldTime.hourIndex(3, 12))
                && reloaded.resolve(spot.asLong(), WorldTime.hourIndex(7, 12)) == saved.resolve(spot.asLong(), WorldTime.hourIndex(7, 12))
                && reloaded.resolve(spot.asLong(), WorldTime.hourIndex(1, 12)) == saved.resolve(spot.asLong(), WorldTime.hourIndex(1, 12));
        boolean writes = true;
        try {
            saved.setDirty();
            level.getDataStorage().saveAndJoin();
        } catch (RuntimeException e) {
            LOGGER.info("  timeline write failed: {}", e.toString());
            writes = false;
        }

        report("the timeline survives a save and reload", survives);
        report("the timeline can be written to disk", writes);

        // Leave the world as we found it.
        TimelineTestHelper.editAs(level, spot, level.getBlockState(spot), air, 9);
        WorldTime.setTime(level, 3, 12);
        Timeline.switchTo(level, WorldTime.hourIndex(3, 12));
        Timeline.clearPending();
    }

    /**
     * A throwaway ServerPlayer.
     *
     * <p>Deliberately never added to the world: it is only used for its
     * persistent data and as a coordinate holder, and a player entity left in
     * a level would get ticked by the server loop.</p>
     */
    private static ServerPlayer mockPlayer(MinecraftServer server) {
        try {
            ServerLevel level = server.overworld();
            return new ServerPlayer(server, level,
                    new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "TVASelfTest"),
                    ClientInformation.createDefault());
        } catch (RuntimeException e) {
            LOGGER.info("  [SKIP] could not build a test player: {}", e.toString());
            return null;
        }
    }

    /**
     * Scans down from the top of the world for the first solid block.
     *
     * <p>The heightmap helpers can answer before a chunk is generated, so the
     * test world would report an unusable spot; reading the blocks forces the
     * column to exist and gives a position where entities can actually spawn.</p>
     */
    private static BlockPos openSky(ServerLevel level, int x, int z) {
        for (int y = level.getMaxY() - 1; y >= level.getMinY(); y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.getBlockState(pos).isAir()) {
                return pos.above();
            }
        }
        return new BlockPos(x, level.getMaxY() - 2, z);
    }

    // ------------------------------------------------------------------

    private static void report(String name, boolean ok) {
        LOGGER.info("  [{}] {}", ok ? "PASS" : "FAIL", name);
    }
}
