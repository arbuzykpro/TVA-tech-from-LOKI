package com.tvatech.system;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.tvatech.ModContent;
import com.tvatech.network.TvaNetwork;
import com.tvatech.util.TvaData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Miss Minutes: the TVA's orientation hologram.
 *
 * <p>The first time somebody crafts one of the Authority's gadgets - a
 * TemPad, a Mobius Mobile or a Variant Scanner - Miss Minutes flickers into
 * being in front of them, a projection of orange sparks, and walks them
 * through what they just built. Her voice rides the game's own narrator
 * (text to speech); the hologram itself is the show.</p>
 *
 * <p>One orientation per gadget per agent, ever. The marker lives in
 * persistent player data, so it survives respawns and relogs.</p>
 */
public final class MissMinutes {

    private MissMinutes() {}

    public static final int KIND_TEMPAD = 0;
    public static final int KIND_MOBILE = 1;
    public static final int KIND_SCANNER = 2;

    /** Saved-data markers: one orientation per gadget, ever. */
    private static final String KEY_TEMPAD = "tva_minutes_tempad";
    private static final String KEY_MOBILE = "tva_minutes_mobile";
    private static final String KEY_SCANNER = "tva_minutes_scanner";

    /** Ticks between one line and the next. */
    private static final int LINE_PACE = 78;

    private record Presentation(int kind, int step) {}

    private static final Map<UUID, Presentation> ACTIVE = new HashMap<>();

    private static final String[] TEMPAD_LINES = {
            "Well howdy! Miss Minutes here, coming to you live from the TVA!",
            "You just finished a TemPad - the Temporal Access Device. Give it a squeeze to open the menu.",
            "Everywhere you drop a marker, the TemPad remembers. Pick one, dial in a day and an hour, press TRAVEL,",
            "A doorway opens right in front of you. Stand still and it waits; walk through and the clock is wherever you sent it.",
            "MANUAL lets you pin any spot in any dimension, coordinates typed straight in.",
            "Now, about the red ones. Turn CELLS ON and the next door runs crimson: whoever walks in falls out of the sky, over and over, unhurt, while the world runs twenty times faster.",
            "The only way out of a cell door is a TemPad. Keep yours handy, sugar.",
            "Welcome to the TVA, agent. Don't make me come find you at lunch!",
    };

    private static final String[] MOBILE_LINES = {
            "Hello there! Miss Minutes, with your orientation for the Mobius Mobile!",
            "That's a communicator wired straight into the TVA mainframe. Right-click to open it.",
            "The MAIN screen calls TVA stations: place a TVA Terminal or a console and it will ring them up.",
            "Link an Arc Reactor and the phone charges itself. And the FREEZE screen stops a variant you're looking at dead in their tracks.",
            "Keep it powered, agent. The past is only a phone call away!",
    };

    private static final String[] SCANNER_LINES = {
            "Miss Minutes here with a quick word about your Variant Scanner!",
            "Right-click any creature - mob, beast or a fellow agent - and the scanner prints a variant number into your log.",
            "Same number always means the same being, so you can tell your variants apart next visit.",
            "Your mark travels with you and it gets rang up in the scanner's log. Scan your timeline, partner. It never lies!",
    };

    // ------------------------------------------------------------------
    // Triggering
    // ------------------------------------------------------------------

    /** One of the gadgets was just crafted - orient if this is a first. */
    public static void onCraft(ServerPlayer player, int kind) {
        String key = flagKey(kind);
        if (TvaData.flag(player, key)) {
            return;
        }
        TvaData.setFlag(player, key);
        if (!ACTIVE.containsKey(player.getUUID())) {
            ACTIVE.put(player.getUUID(), new Presentation(kind, -1));
        }
    }

    public static void onCraft(ServerPlayer player, ItemStack stack) {
        if (stack.is(ModContent.TEMPAD.get())) {
            onCraft(player, KIND_TEMPAD);
        } else if (stack.is(ModContent.MOBIUS_MOBILE.get())) {
            onCraft(player, KIND_MOBILE);
        } else if (stack.is(ModContent.VARIANT_SCANNER.get())) {
            onCraft(player, KIND_SCANNER);
        }
    }

    /** Fabric trigger: the items just turned up in a player's pockets. */
    public static void onInventorySeen(ServerPlayer player) {
        for (ItemStack stack : player.getInventory().items) {
            if (stack.isEmpty()) {
                continue;
            }
            onCraft(player, stack);
        }
    }

    /** Drops a player's presentation - they'll log back in later. */
    public static void clear(UUID who) {
        ACTIVE.remove(who);
    }

    private static String flagKey(int kind) {
        return switch (kind) {
            case KIND_MOBILE -> KEY_MOBILE;
            case KIND_SCANNER -> KEY_SCANNER;
            default -> KEY_TEMPAD;
        };
    }

    // ------------------------------------------------------------------
    // Running the show
    // ------------------------------------------------------------------

    /** Called once per server tick: speaks, glitters and ends. */
    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) {
            return;
        }
        for (Map.Entry<UUID, Presentation> line : new ArrayList<>(ACTIVE.entrySet())) {
            ServerPlayer player = server.getPlayerList().getPlayer(line.getKey());
            if (player == null) {
                // Offline mid-orientation: it does not resume, it does not
                // matter - the marker is already signed, so this was their
                // one show and they walked out on it.
                ACTIVE.remove(line.getKey());
                continue;
            }
            int step = line.getValue().step() + 1;
            int kind = line.getValue().kind();
            String[] lines = lines(kind);
            if (step >= lines.length) {
                ACTIVE.remove(line.getKey());
                continue;
            }
            ACTIVE.put(line.getKey(), new Presentation(kind, step));
            speak(player, kind, lines[step]);
        }
    }

    private static String[] lines(int kind) {
        return switch (kind) {
            case KIND_MOBILE -> MOBILE_LINES;
            case KIND_SCANNER -> SCANNER_LINES;
            default -> TEMPAD_LINES;
        };
    }

    /**
     * Delivers one line: the narrator speaks it on the crafter's client (the
     * network payload carries the words) and the hologram pulses at the
     * crafter.
     */
    private static void speak(ServerPlayer player, int kind, String line) {
        TvaNetwork.sendToPlayer(player, new TvaNetwork.MinutesPayload(line));

        // The projection: a swirl of sparks two paces in front of the face.
        Vec3 look = player.getLookAngle();
        double ax = player.getX() + look.x * 1.8;
        double az = player.getZ() + look.z * 1.8;
        double ay = player.getEyeY() + 0.2;

        if (player.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.PORTAL, ax, ay, az, 22, 0.2, 0.5, 0.2, 0.1);
            level.sendParticles(ParticleTypes.END_ROD, ax, ay - 0.2, az, 5, 0.15, 0.4, 0.15, 0.04);
            level.playSound(null, player.blockPosition(), SoundEvents.PORTAL_AMBIENT,
                    SoundSource.PLAYERS, 0.35F, 1.7F);
        }
    }
}
