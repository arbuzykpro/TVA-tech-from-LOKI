package com.tvatech.item;

import com.tvatech.TvaConfig;
import com.tvatech.system.TimeTravel;
import com.tvatech.util.TvaData;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.function.Consumer;

/** Tooltip text for every gadget. Kept in one file so the wording stays consistent. */
public final class TvaTooltips {

    private TvaTooltips() {}

    public static final TvaGadgetItem.TooltipBuilder TEMPAD = (item, stack, lines) -> {
        chargeLine(stack, lines);
        if (TimeTravel.hasPin(stack)) {
            int[] pin = TvaData.getIntArray(stack, TimeTravel.KEY_PIN_POS);
            lines.accept(TvaGadgetItem.aqua("tvatech.tooltip.pin",
                    TimeTravel.pinDimension(stack),
                    "x=" + pin[0] + " y=" + pin[1] + " z=" + pin[2]));
        } else {
            lines.accept(TvaGadgetItem.grey("tvatech.tooltip.no_pin"));
        }
        lines.accept(Component.empty());
        lines.accept(TvaGadgetItem.grey("tvatech.tip.tempad.1"));
        lines.accept(TvaGadgetItem.grey("tvatech.tip.tempad.2"));
    };

    public static final TvaGadgetItem.TooltipBuilder MOBILE = (item, stack, lines) -> {
        chargeLine(stack, lines);
        lines.accept(Component.empty());
        lines.accept(TvaGadgetItem.grey("tvatech.tip.mobile.1"));
        lines.accept(TvaGadgetItem.grey("tvatech.tip.mobile.2"));
    };

    public static final TvaGadgetItem.TooltipBuilder SCANNER = (item, stack, lines) -> {
        lines.accept(Component.empty());
        lines.accept(TvaGadgetItem.grey("tvatech.tooltip.scanner"));
    };

    public static final TvaGadgetItem.TooltipBuilder BATTERY = (item, stack, lines) -> {
        lines.accept(Component.empty());
        lines.accept(TvaGadgetItem.grey("tvatech.tooltip.battery"));
    };

    private static void chargeLine(ItemStack stack, Consumer<Component> lines) {
        lines.accept(TvaGadgetItem.aqua("tvatech.tooltip.charge",
                TimeTravel.charge(stack), TvaConfig.tempadMaxCharge));
    }
}