package com.tvatech.system;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Base64;

/**
 * Turns inventories into short strings so they can live in the timeline's
 * JSON save file.
 *
 * <p>Item stacks carry arbitrary data - names, enchants, custom components -
 * so they are saved through vanilla's own NBT format and then Base64 encoded
 * into a JSON-safe blob. That keeps this lossless instead of trying to
 * describe an item by hand.</p>
 */
final class Nbt {

    private Nbt() {}

    /** A whole inventory (chest, barrel, shulker, ...) as one string. */
    static String saveItems(HolderLookup.Provider registries, NonNullList<ItemStack> items) {
        CompoundTag tag = new CompoundTag();
        ContainerHelper.saveAllItems(tag, items, registries);
        return encode(tag);
    }

    /** Reads an inventory back, clearing anything not in the snapshot. */
    static void loadItems(HolderLookup.Provider registries, String blob,
                          NonNullList<ItemStack> target) {
        target.clear();
        CompoundTag tag = decode(blob);
        if (tag == null) {
            return;
        }
        ContainerHelper.loadAllItems(tag, target, registries);
    }

    /** A single stack as one string. */
    static String saveStack(HolderLookup.Provider registries, ItemStack stack) {
        CompoundTag tag = new CompoundTag();
        tag.put("s", stack.save(registries));
        return encode(tag);
    }

    static ItemStack loadStack(HolderLookup.Provider registries, String blob) {
        CompoundTag tag = decode(blob);
        if (tag == null) {
            return ItemStack.EMPTY;
        }
        return ItemStack.parseOptional(registries, tag.getCompound("s"));
    }

    private static String encode(CompoundTag tag) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                NbtIo.write(tag, out);
            }
            return Base64.getEncoder().encodeToString(bytes.toByteArray());
        } catch (Exception e) {
            return "";
        }
    }

    private static CompoundTag decode(String blob) {
        if (blob == null || blob.isEmpty()) {
            return null;
        }
        try {
            byte[] raw = Base64.getDecoder().decode(blob);
            return NbtIo.read(new DataInputStream(new ByteArrayInputStream(raw)));
        } catch (Exception e) {
            return null;
        }
    }
}
