package com.tvatech.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** The glowing core that powers TVA gadgets. Light level is set in the properties. */
public class ArcReactorBlock extends Block {

    public ArcReactorBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}