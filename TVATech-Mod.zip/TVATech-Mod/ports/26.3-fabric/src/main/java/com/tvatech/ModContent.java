package com.tvatech;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import com.tvatech.block.ArcReactorBlock;
import com.tvatech.block.ChronoviumBlock;
import com.tvatech.block.TimeDoorBlock;
import com.tvatech.item.TvaGadgetItem;
import com.tvatech.item.TvaTooltips;
import com.tvatech.util.Reg;

/**
 * Registry holders for every block and item in the mod.
 *
 * <p>Fabric registers eagerly, so this is one static block: blocks first (block
 * items need the finished block), then items, then the creative tab. The
 * {@link Reg} wrapper keeps the {@code .get()} call shape used everywhere else
 * in the mod.</p>
 */
public final class ModContent {

    private ModContent() {}

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------
    private static Identifier id(String name) {
        return Identifier.fromNamespaceAndPath(TVATech.MODID, name);
    }

    private static ResourceKey<Block> blockKey(String name) {
        return ResourceKey.create(Registries.BLOCK, id(name));
    }

    private static ResourceKey<Item> itemKey(String name) {
        return ResourceKey.create(Registries.ITEM, id(name));
    }

    private static Reg<Block> block(String name, Block value) {
        Registry.register(BuiltInRegistries.BLOCK, id(name), value);
        return new Reg<>(value);
    }

    private static Reg<Item> item(String name, Item value) {
        Registry.register(BuiltInRegistries.ITEM, id(name), value);
        return new Reg<>(value);
    }

    // ---------------------------------------------------------------------
    // Blocks
    // ---------------------------------------------------------------------

    /** The glowing portal frame from the show. Traversal requires a TemPad. */
    public static final Reg<Block> TIME_DOOR = block("time_door",
            new TimeDoorBlock(BlockBehaviour.Properties.of()
                    .setId(blockKey("time_door"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(3.0F, 6.0F)
                    .sound(SoundType.COPPER)
                    .lightLevel(state -> state.getValue(TimeDoorBlock.OPEN) ? 15 : 4)
                    .noOcclusion()));

    /** Power source: lights the area and feeds the Mobius Mobile's abilities. */
    public static final Reg<Block> ARC_REACTOR = block("arc_reactor",
            new ArcReactorBlock(BlockBehaviour.Properties.of()
                    .setId(blockKey("arc_reactor"))
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(4.0F, 8.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> 14)));

    /** Decorative chronovium alloy used to build TVA tech. */
    public static final Reg<Block> CHRONOVIUM_BLOCK = block("chronovium_block",
            new ChronoviumBlock(BlockBehaviour.Properties.of()
                    .setId(blockKey("chronovium_block"))
                    .mapColor(MapColor.METAL)
                    .strength(5.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    // --- TVA office furniture ---------------------------------------------

    /** A wall-mounted terminal: the amber scrolling screens of the Vault. */
    public static final Reg<Block> COMPUTER = block("computer",
            new net.minecraft.world.level.block.RotatedPillarBlock(
                    BlockBehaviour.Properties.of()
                            .setId(blockKey("computer"))
                            .mapColor(MapColor.COLOR_ORANGE)
                            .strength(3.0F, 6.0F)
                            .sound(SoundType.WOOD)
                            .lightLevel(state -> 7)
                            .noOcclusion()));

    /** A full-height terminal bank, floor to ceiling. */
    public static final Reg<Block> TERMINAL = block("terminal",
            new net.minecraft.world.level.block.RotatedPillarBlock(
                    BlockBehaviour.Properties.of()
                            .setId(blockKey("terminal"))
                            .mapColor(MapColor.COLOR_ORANGE)
                            .strength(3.5F, 6.0F)
                            .sound(SoundType.WOOD)
                            .lightLevel(state -> 11)
                            .noOcclusion()));

    /** A half-height console desk. */
    public static final Reg<Block> CONSOLE = block("console",
            new net.minecraft.world.level.block.SlabBlock(BlockBehaviour.Properties.of()
                    .setId(blockKey("console"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(2.5F, 5.0F)
                    .sound(SoundType.WOOD)
                    .lightLevel(state -> 5)));

    /**
     * The glowing surface of an open time door.
     *
     * <p>Deliberately has no item: a doorway is something the TemPad builds, not
     * something you carry around and place.</p>
     */
    public static final Reg<Block> TIMEDOOR_FIELD = block("timedoor_field",
            new com.tvatech.block.TimedoorFieldBlock(BlockBehaviour.Properties.of()
                    .setId(blockKey("timedoor_field"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .noCollision()
                    .noOcclusion()
                    .lightLevel(state -> 11)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.GLASS)));

    /**
     * Chronovium in the stone.
     *
     * <p>Mining one drops the ingot directly, the way nether ore drops a
     * nugget rather than making you smelt it first.</p>
     */
    public static final Reg<Block> CHRONOVIUM_ORE = block("chronovium_ore",
            new Block(BlockBehaviour.Properties.of()
                    .setId(blockKey("chronovium_ore"))
                    .mapColor(MapColor.STONE)
                    .strength(3.0F, 3.0F)
                    .sound(SoundType.STONE)
                    .requiresCorrectToolForDrops()));

    /** The same ore, underground, where deepslate is the rock. */
    public static final Reg<Block> DEEPSLATE_CHRONOVIUM_ORE = block("deepslate_chronovium_ore",
            new Block(BlockBehaviour.Properties.of()
                    .setId(blockKey("deepslate_chronovium_ore"))
                    .mapColor(MapColor.DEEPSLATE)
                    .strength(4.5F, 3.0F)
                    .sound(SoundType.DEEPSLATE)
                    .requiresCorrectToolForDrops()));

    /**
     * Framed pictures on the Authority's walls.
     *
     * <p>No item: these are part of the building.</p>
     */
    public static final Reg<Block> TVA_PICTURE = block("tva_picture",
            new com.tvatech.block.TvaPictureBlock(BlockBehaviour.Properties.of()
                    .setId(blockKey("tva_picture"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(2.0F, 5.0F)
                    .sound(SoundType.WOOD)
                    .lightLevel(state -> 7)));

    // ---------------------------------------------------------------------
    // Items
    // ---------------------------------------------------------------------

    /** The Temporal Access Device. Opens doors through time. */
    public static final Reg<Item> TEMPAD = item("tempad",
            new TvaGadgetItem(new Item.Properties()
                    .setId(itemKey("tempad"))
                    .stacksTo(1)
                    .rarity(Rarity.RARE), TvaTooltips.TEMPAD));

    /** Mobius' sliding mobile: variant scanner, timeline log, chrono abilities. */
    public static final Reg<Item> MOBIUS_MOBILE = item("mobius_mobile",
            new TvaGadgetItem(new Item.Properties()
                    .setId(itemKey("mobius_mobile"))
                    .stacksTo(1)
                    .rarity(Rarity.RARE), TvaTooltips.MOBILE));

    /** Handheld barcode reader that tags living things with a variant ID. */
    public static final Reg<Item> VARIANT_SCANNER = item("variant_scanner",
            new TvaGadgetItem(new Item.Properties()
                    .setId(itemKey("variant_scanner"))
                    .stacksTo(1), TvaTooltips.SCANNER));

    /** A collar other timelines mind: clamps on a mob or a fellow agent. */
    public static final Reg<Item> TIME_COLLAR = item("time_collar",
            new com.tvatech.item.TimeCollarItem(new Item.Properties()
                    .setId(itemKey("time_collar"))
                    .stacksTo(16)));

    /** Orders a collared creature's last five seconds rolled back. */
    public static final Reg<Item> TIME_COLLAR_REMOTE = item("time_collar_remote",
            new com.tvatech.item.TimeCollarRemoteItem(new Item.Properties()
                    .setId(itemKey("time_collar_remote"))
                    .stacksTo(1)
                    .rarity(Rarity.RARE)));

    /** Spendable charge cell used to power the TemPad. */
    public static final Reg<Item> CHRONO_BATTERY = item("chrono_battery",
            new TvaGadgetItem(new Item.Properties()
                    .setId(itemKey("chrono_battery")), TvaTooltips.BATTERY));

    /** Raw chronovium ore chunks, smelted into ingots. */
    public static final Reg<Item> RAW_CHRONOVIUM = item("raw_chronovium",
            new Item(new Item.Properties()
                    .setId(itemKey("raw_chronovium"))));

    /** The alloy everything TVA is built from. */
    public static final Reg<Item> CHRONOVIUM_INGOT = item("chronovium_ingot",
            new Item(new Item.Properties()
                    .setId(itemKey("chronovium_ingot"))));

    /**
     * The Authority's own field manual.
     *
     * <p>A plain item. The pages are applied the moment it is right-clicked, so
     * carrying it around does not mean carrying thirty pages of lore in the
     * item's data.</p>
     */
    public static final Reg<Item> TVA_MANUAL = item("tva_manual",
            new com.tvatech.item.TvaManualItem(new Item.Properties()
                    .setId(itemKey("tva_manual"))
                    .stacksTo(1)
                    .rarity(Rarity.UNCOMMON)));

    // ---------------------------------------------------------------------
    // Block items
    // ---------------------------------------------------------------------
    public static final Reg<Item> TIME_DOOR_ITEM = item("time_door",
            new BlockItem(TIME_DOOR.get(), new Item.Properties().setId(itemKey("time_door")).stacksTo(16)));

    public static final Reg<Item> ARC_REACTOR_ITEM = item("arc_reactor",
            new BlockItem(ARC_REACTOR.get(), new Item.Properties().setId(itemKey("arc_reactor")).stacksTo(16)));

    public static final Reg<Item> CHRONOVIUM_BLOCK_ITEM = item("chronovium_block",
            new BlockItem(CHRONOVIUM_BLOCK.get(), new Item.Properties().setId(itemKey("chronovium_block")).stacksTo(64)));

    public static final Reg<Item> COMPUTER_ITEM = item("computer",
            new BlockItem(COMPUTER.get(), new Item.Properties().setId(itemKey("computer")).stacksTo(64)));

    public static final Reg<Item> TERMINAL_ITEM = item("terminal",
            new BlockItem(TERMINAL.get(), new Item.Properties().setId(itemKey("terminal")).stacksTo(64)));

    public static final Reg<Item> CHRONOVIUM_ORE_ITEM = item("chronovium_ore",
            new BlockItem(CHRONOVIUM_ORE.get(), new Item.Properties().setId(itemKey("chronovium_ore"))));

    public static final Reg<Item> DEEPSLATE_CHRONOVIUM_ORE_ITEM = item("deepslate_chronovium_ore",
            new BlockItem(DEEPSLATE_CHRONOVIUM_ORE.get(),
                    new Item.Properties().setId(itemKey("deepslate_chronovium_ore"))));

    public static final Reg<Item> CONSOLE_ITEM = item("console",
            new BlockItem(CONSOLE.get(), new Item.Properties().setId(itemKey("console")).stacksTo(64)));

    // ---------------------------------------------------------------------
    // Creative tab
    // ---------------------------------------------------------------------
    public static final Reg<CreativeModeTab> TAB = new Reg<>(Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB, id("tva_tech"),
            net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab.builder()
                    .title(net.minecraft.network.chat.Component.translatable("itemGroup.tvatech.tva_tech"))
                    .icon(() -> TEMPAD.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(TEMPAD.get());
                        output.accept(MOBIUS_MOBILE.get());
                        output.accept(VARIANT_SCANNER.get());
                        output.accept(TIME_COLLAR.get());
                        output.accept(TIME_COLLAR_REMOTE.get());
                        output.accept(CHRONO_BATTERY.get());
                        output.accept(RAW_CHRONOVIUM.get());
                        output.accept(CHRONOVIUM_INGOT.get());
                        output.accept(ARC_REACTOR_ITEM.get());
                        output.accept(CHRONOVIUM_BLOCK_ITEM.get());
                        output.accept(CHRONOVIUM_ORE_ITEM.get());
                        output.accept(DEEPSLATE_CHRONOVIUM_ORE_ITEM.get());
                        output.accept(TIME_DOOR_ITEM.get());
                        output.accept(COMPUTER_ITEM.get());
                        output.accept(TERMINAL_ITEM.get());
                        output.accept(CONSOLE_ITEM.get());
                        output.accept(TVA_MANUAL.get());
                    })
                    .build()));

    /**
     * Forces class initialisation (and therefore every registration above).
     *
     * <p>Called from the mod entrypoint; also makes the ordering explicit for
     * anyone reading the port.</p>
     */
    public static void init() {
        // Static initialisers do the work.
    }
}
