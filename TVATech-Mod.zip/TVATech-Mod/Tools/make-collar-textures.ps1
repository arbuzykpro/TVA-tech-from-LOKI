# Generates 16x16 textures for the Time Collar and Time Collar Remote.
# Palette-built pixel art (steel + TVA orange) written as raw BGRA PNGs.
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

# ---------------------------------------------------------------- palette
$P = @{
    K = [byte[]](37, 41, 48, 255)      # outline dark
    D = [byte[]](86, 94, 105, 255)     # dark steel
    M = [byte[]](140, 150, 162, 255)   # mid steel
    L = [byte[]](196, 205, 214, 255)   # light steel
    W = [byte[]](233, 239, 245, 255)   # glint
    O = [byte[]](255, 138, 0, 255)     # TVA orange
    H = [byte[]](255, 184, 77, 255)    # orange light
    A = [byte[]](212, 104, 0, 255)     # orange dark
    B = [byte[]](255, 199, 102, 255)   # amber screen
    S = [byte[]](222, 148, 34, 255)    # amber screen shade
    R = [byte[]](214, 58, 58, 255)     # red button
    j = [byte[]](240, 110, 100, 255)   # red highlight
    "." = [byte[]](0, 0, 0, 0)         # transparent
}

function ConvertTo-Png {
    param([string[]]$Grid, [string]$Path)
    $bmp = New-Object System.Drawing.Bitmap(16, 16)
    for ($y = 0; $y -lt 16; $y++) {
        for ($x = 0; $x -lt 16; $x++) {
            $c = $P[[string]$Grid[$y][$x]]
            $bmp.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($c[3], $c[0], $c[1], $c[2]))
        }
    }
    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    $bmp.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
}

# ================================================================ collar
# A steel ring seen face on with a TVA-orange clasp buckle at the bottom.
$collar = New-Object "string[]" 16
for ($y = 0; $y -lt 16; $y++) { $collar[$y] = ("." * 16) }

$cx, $cy = 7.5, 7.2
for ($y = 0; $y -lt 16; $y++) {
    for ($x = 0; $x -lt 16; $x++) {
        $e = [math]::Sqrt([math]::Pow($x - $cx, 2) + [math]::Pow($y - $cy, 2))
        if ($e -ge 3.5 -and $e -le 6.2) {
            if ($e -ge 5.7 -or $e -le 4.0) { $shade = "D" }             # dark rims
            elseif (($x - $cx) + ($y - $cy) -lt -2.0) { $shade = "L" }   # top-left light
            elseif (($x - $cx) + ($y - $cy) -gt 4.0) { $shade = "D" }    # bottom-right shade
            else { $shade = "M" }
            if ($x -eq 4 -and $y -eq 3) { $shade = "W" }                # glint
            if ($x -eq 5 -and $y -eq 3) { $shade = "W" }
            $collar[$y] = $collar[$y].Substring(0, $x) + $shade + $collar[$y].Substring($x + 1)
        }
    }
}

# Clasp buckle: a small outlined box over the bottom of the ring.
for ($y = 11; $y -le 14; $y++) {
    for ($x = 6; $x -le 9; $x++) {
        if ($y -eq 11 -or $y -eq 14 -or $x -eq 6 -or $x -eq 9) { $shade = "K" }
        elseif ($y -eq 12 -and $x -eq 7) { $shade = "H" }
        else { $shade = "O" }
        $collar[$y] = $collar[$y].Substring(0, $x) + $shade + $collar[$y].Substring($x + 1)
    }
}

# ================================================================ remote
# Handheld steel remote: amber screen up top, red rewind button below.
$remote = New-Object "string[]" 16
for ($y = 0; $y -lt 16; $y++) { $remote[$y] = ("." * 16) }

# Body: rounded 10x11 slab, outline dark, light top edge.
for ($y = 3; $y -le 13; $y++) {
    for ($x = 3; $x -le 12; $x++) {
        $corner = (($x -eq 3 -or $x -eq 12) -and ($y -le 3 -or $y -ge 13))
        if ($corner) { continue }
        if ($x -eq 3 -or $x -eq 12 -or $y -eq 3 -or $y -eq 13) { $shade = "K" }
        elseif ($y -eq 4) { $shade = "L" }
        elseif ($x -ge 11) { $shade = "D" }
        else { $shade = "M" }
        $remote[$y] = $remote[$y].Substring(0, $x) + $shade + $remote[$y].Substring($x + 1)
    }
}

# TVA-orange indicator LED (top right).
$remote[4] = $remote[4].Substring(0, 11) + "O" + $remote[4].Substring(12)

# Screen: dark frame from x4..11 y5..8, amber glass inside.
for ($y = 5; $y -le 8; $y++) {
    for ($x = 4; $x -le 11; $x++) {
        if ($x -eq 4 -or $x -eq 11) { $shade = "K" }
        elseif ($y -eq 5 -or $y -eq 8) { $shade = "K" }
        else { $shade = "B" }
        $remote[$y] = $remote[$y].Substring(0, $x) + $shade + $remote[$y].Substring($x + 1)
    }
}
# Amber "digits" glitch bars.
for ($x = 5; $x -le 10; $x++) {
    $c = if ($x % 2 -eq 1) { "S" } else { "B" }
    $remote[6] = $remote[6].Substring(0, $x) + $c + $remote[6].Substring($x + 1)
    $c = if ($x % 2 -eq 1) { "B" } else { "S" }
    $remote[7] = $remote[7].Substring(0, $x) + $c + $remote[7].Substring($x + 1)
}

# Red rewind button with highlight.
for ($y = 10; $y -le 12; $y++) {
    for ($x = 5; $x -le 8; $x++) {
        if ($x -eq 5 -or $x -eq 8 -or $y -eq 10 -or $y -eq 12) { $shade = "K" }
        elseif ($y -eq 11 -and $x -eq 6) { $shade = "j" }
        else { $shade = "R" }
        $remote[$y] = $remote[$y].Substring(0, $x) + $shade + $remote[$y].Substring($x + 1)
    }
}

# ---------------------------------------------------------------- write
$proj = "C:\Projects\TVATech-Mod"
$targets = @(
    "$proj\src\main\resources\assets\tvatech\textures\item",
    "$proj\ports\26.3-fabric\src\main\resources\assets\tvatech\textures\item",
    "$proj\ports\1.21-fabric\src\main\resources\assets\tvatech\textures\item",
    "$proj\ports\1.21.1-fabric\src\main\resources\assets\tvatech\textures\item"
)
foreach ($dir in $targets) {
    ConvertTo-Png -Grid $collar -Path "$dir\time_collar.png"
    ConvertTo-Png -Grid $remote -Path "$dir\time_collar_remote.png"
}
"Textures written to $($targets.Count) trees."
