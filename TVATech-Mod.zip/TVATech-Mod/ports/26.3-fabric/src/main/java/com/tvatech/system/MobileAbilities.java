package com.tvatech.system;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import com.tvatech.ModContent;
import com.tvatech.TvaConfig;
import com.tvatech.TvaMessages;
import com.tvatech.network.TvaNetwork;
import com.tvatech.util.TvaData;
import com.tvatech.util.TvaEntityName;
import com.tvatech.util.TvaFeedback;
import com.tvatech.util.TvaEntityName;

import java.util.List;

/**
 * Server side logic behind the Mobius Mobile's buttons.
 */
public final class MobileAbilities {

    private MobileAbilities() {}

    private static final String KEY_FREEZE_CD = "tva_freeze_cd";

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** The phone the player is holding, or {@code null} when they are not holding one. */
    public static ItemStack mobileStack(ServerPlayer player) {
        ItemStack main = player.getMainHandItem();
        if (main.is(ModContent.MOBIUS_MOBILE.get())) {
            return main;
        }
        ItemStack off = player.getOffhandItem();
        return off.is(ModContent.MOBIUS_MOBILE.get()) ? off : null;
    }

    public static int freezeCooldown(ServerPlayer player) {
        ItemStack mobile = mobileStack(player);
        return mobile == null ? 0 : TvaData.getInt(mobile, KEY_FREEZE_CD, 0);
    }

    public static void setFreezeCooldown(ServerPlayer player, int ticks) {
        ItemStack mobile = mobileStack(player);
        if (mobile != null) {
            TvaData.setInt(mobile, KEY_FREEZE_CD, Math.max(0, ticks));
        }
    }

    /** Ticks the freeze cooldown down once per second. */
    public static void tickCooldown(ServerPlayer player) {
        ItemStack mobile = mobileStack(player);
        if (mobile == null) {
            return;
        }
        int cd = TvaData.getInt(mobile, KEY_FREEZE_CD, 0);
        if (cd > 0) {
            TvaData.setInt(mobile, KEY_FREEZE_CD, cd - 1);
        }
    }

    /** True when an Arc Reactor is close enough to power the phone. */
    public static boolean hasReactorNearby(ServerPlayer player) {
        ServerLevel level = player.level();
        int range = Math.min(16, TvaConfig.reactorRange);
        int step = 2;
        BlockPos origin = player.blockPosition();
        for (int dx = -range; dx <= range; dx += step) {
            for (int dy = -6; dy <= 6; dy += step) {
                for (int dz = -range; dz <= range; dz += step) {
                    BlockPos pos = origin.offset(dx, dy, dz);
                    if (level.hasChunkAt(pos) && level.getBlockState(pos).is(ModContent.ARC_REACTOR.get())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    public static void handleAction(ServerPlayer player, int action) {
        switch (action) {
            case TvaNetwork.ACTION_FREEZE -> {
                ChronoFreeze.performFreeze(player);
                pushState(player);
            }
            case TvaNetwork.ACTION_SCAN -> {
                scanNearest(player);
                pushState(player);
            }
            case TvaNetwork.ACTION_TIMELINE -> printTimeline(player);
            case TvaNetwork.ACTION_ANCHOR -> {
                toggleAnchor(player);
                pushState(player);
            }
            default -> {
                // CLOSE and anything unknown are client side only.
            }
        }
    }

    /** Finds the entity the player is looking at and reports its variant number. */
    public static void scanNearest(ServerPlayer player) {
        Entity target = lookTarget(player, 12.0);
        if (target == null) {
            TvaFeedback.actionBar(player, TvaMessages.noTarget());
            return;
        }
        int variant = TimeTravel.variant(target);
        TvaFeedback.actionBar(player, TvaMessages.scanned(TvaEntityName.of(target), variant));
    }

    /** Ray trace used by the scanner and the mobile. */
    public static Entity lookTarget(ServerPlayer player, double range) {
        var hit = player.pick(range, 0.0F, false);
        if (hit instanceof net.minecraft.world.phys.EntityHitResult entityHit) {
            return entityHit.getEntity();
        }

        // Fall back to the closest entity within the cone in front of the player.
        var eyes = player.getEyePosition();
        var look = player.getLookAngle();
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        var area = player.getBoundingBox().inflate(range);
        for (Entity entity : player.level().getEntities(player, area, e -> e.isPickable() && !(e instanceof ServerPlayer))) {
            var toEntity = entity.getBoundingBox().getCenter().subtract(eyes);
            double distance = toEntity.length();
            if (distance > range) {
                continue;
            }
            double dot = toEntity.normalize().dot(look);
            if (dot < 0.94) {
                continue;
            }
            if (distance < bestScore) {
                bestScore = distance;
                best = entity;
            }
        }
        return best;
    }

    /** Prints the personal timeline log into chat. */
    public static void printTimeline(ServerPlayer player) {
        List<String> log = TimeTravel.log(player);
        player.sendSystemMessage(TvaMessages.timelineHeader().withStyle(ChatFormatting.AQUA));
        if (log.isEmpty()) {
            player.sendSystemMessage(Component.translatable("tvatech.message.timeline_empty")
                    .withStyle(ChatFormatting.GRAY));
            return;
        }
        int i = 0;
        for (String line : log) {
            player.sendSystemMessage(Component.literal("  " + (++i) + ". ").withStyle(ChatFormatting.DARK_AQUA)
                    .append(Component.literal(line).withStyle(ChatFormatting.GRAY)));
        }
    }

    /** The "time of death" anchor: respawn there instead of your bed. */
    public static void toggleAnchor(ServerPlayer player) {
        ServerLevel level = player.level();
        if (TvaData.anchor(player) != null) {
            TvaData.clearAnchor(player);
            TvaFeedback.actionBar(player, TvaMessages.anchorCleared());
            TimeTravel.log(player, "Temporal anchor released");
            return;
        }
        BlockPos pos = player.blockPosition();
        TvaData.setAnchor(player, level.dimension().identifier().toString(), pos.getX(), pos.getY(), pos.getZ());
        TvaFeedback.actionBar(player, TvaMessages.anchorSet(TimeTravel.describe(level, pos)));
        TimeTravel.log(player, "Temporal anchor set at " + TimeTravel.describe(level, pos));
    }

    /** Sends the current phone state to the owning client. */
    public static void pushState(ServerPlayer player) {
        ItemStack mobile = mobileStack(player);
        TvaNetwork.sendToPlayer(player, new TvaNetwork.OpenMobilePayload(
                TimeTravel.variant(player),
                mobile == null ? 0 : TimeTravel.charge(mobile),
                TvaConfig.tempadMaxCharge,
                freezeCooldown(player),
                hasReactorNearby(player),
                TimeTravel.log(player)));
    }
}