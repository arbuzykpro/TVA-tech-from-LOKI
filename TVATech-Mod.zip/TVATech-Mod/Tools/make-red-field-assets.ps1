# Generates the red "time cell" variants of the timedoor field textures,
# plus the model JSONs. Blocks tinted with a red-dominant multiplier.
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$proj = "C:\Projects\TVATech-Mod"
$targets = @(
    "$proj\src\main\resources",
    "$proj\ports\26.3-fabric\src\main\resources",
    "$proj\ports\1.21.1-fabric\src\main\resources",
    "$proj\ports\1.21-fabric\src\main\resources"
)

foreach ($res in $targets) {
    $texDir = "$res\assets\tvatech\textures\block"
    for ($i = 0; $i -lt 8; $i++) {
        $src = "$texDir\timedoor_field_$i.png"
        if (-not (Test-Path $src)) { throw "missing texture: $src" }
        $bmp = New-Object System.Drawing.Bitmap($src)
        for ($y = 0; $y -lt $bmp.Height; $y++) {
            for ($x = 0; $x -lt $bmp.Width; $x++) {
                $c = $bmp.GetPixel($x, $y)
                if ($c.A -eq 0) { continue }
                # red-dominant tint of the same swirl
                $r = [Math]::Min(255, [int]($c.R * 1.15 + $c.G * 0.35))
                $g = [int]($c.G * 0.16)
                $b = [int]($c.B * 0.12)
                $bmp.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($c.A, $r, $g, $b))
            }
        }
        $out = "$texDir\timedoor_field_red_$i.png"
        $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
    }

    # models
    $modelDir = "$res\assets\tvatech\models\block"
    for ($i = 0; $i -lt 8; $i++) {
        $json = "{
    `"parent`":  `"minecraft:block/cube_all`",
    `"textures`":  {
        `"all`":  `"tvatech:block/timedoor_field_red_$i`"
    }
}"
        [System.IO.File]::WriteAllText("$modelDir\timedoor_field_red_$i.json", $json)
    }

    # blockstate: keep the amber variants for cell=false, add red per frame
    $bsPath = "$res\assets\tvatech\blockstates\timedoor_field.json"
    $lines = @("{")
    $lines += "  `"variants`": {"
    foreach ($v in (0..7)) {
        $lines += "    `"frame=$v`": { `"model`": `"tvatech:block/timedoor_field_$v`" },"
    }
    foreach ($v in (0..7)) {
        $comma = if ($v -eq 7) { "" } else { "," }
        $lines += "    `"frame=$v|cell=true`": { `"model`": `"tvatech:block/timedoor_field_red_$v`" }$comma"
    }
    $lines += "  }"
    $lines += "}"
    [System.IO.File]::WriteAllText($bsPath, ($lines -join "`n") + "`n")
}
"DONE red assets for all resource roots"
