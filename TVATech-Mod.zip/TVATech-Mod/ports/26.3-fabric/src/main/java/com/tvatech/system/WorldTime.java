package com.tvatech.system;

import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.clock.ServerClockManager;
import net.minecraft.world.clock.WorldClock;
import net.minecraft.world.clock.WorldClocks;

/**
 * Reads and writes the world clock.
 *
 * <p>Minecraft 26.x replaced {@code Level#setDayTime} with a world-clock
 * system: each clock keeps an absolute tick count, and {@code /time set day N}
 * style flags no longer exist. {@link Level#getOverworldClockTime()} reads the
 * overworld clock, and the matching write is
 * {@link ServerClockManager#setTotalTicks}.</p>
 *
 * <p>Minecraft's day starts at tick 0 = 06:00, tick 6000 = noon, 12000 = 18:00.</p>
 */
public final class WorldTime {

    private WorldTime() {}

    public static final int TICKS_PER_DAY = 24000;

    /** The overworld's clock, the one the player sees. */
    private static Holder<WorldClock> overworldClock(ServerLevel level) {
        return level.registryAccess().get(WorldClocks.OVERWORLD)
                .orElseThrow(() -> new IllegalStateException("no overworld clock registered"));
    }

    /** Current clock as {@code [day, hour24, minute]}. */
    public static long[] now(ServerLevel level) {
        long ticks = level.getOverworldClockTime();
        long day = Math.floorDiv(ticks, TICKS_PER_DAY);
        long timeOfDay = Math.floorMod(ticks, TICKS_PER_DAY);
        return new long[]{day, tickToHour(timeOfDay), minuteOf(timeOfDay)};
    }

    /** Tick 0 is 06:00, so shift by six hours. */
    public static long tickToHour(long timeOfDay) {
        return Math.floorMod(Math.floorDiv(timeOfDay, 1000) + 6, 24);
    }

    public static long minuteOf(long timeOfDay) {
        return Math.floorMod(timeOfDay, 1000) * 60 / 1000;
    }

    /** Converts a 24h clock reading into Minecraft's tick-of-day. */
    public static long hourToTick(int hour24) {
        return Math.floorMod(hour24 - 6, 24) * 1000L;
    }

    /**
     * Sets the local clock to a specific day and hour.
     *
     * <p>Arrival times are always on the hour: the TemPad's dial only moves in
     * whole hours, so the clock lands at {@code :00} rather than wherever the
     * world happened to be.</p>
     *
     * @param day   world day, 0-based (the "day 1 of the world" counter minus one)
     * @param hour  0-23
     */
    public static void setTime(ServerLevel level, long day, int hour) {
        long safeDay = Math.max(0, day);
        int safeHour = Math.floorMod(hour, 24);

        long ticks = safeDay * TICKS_PER_DAY + hourToTick(safeHour);
        level.clockManager().setTotalTicks(overworldClock(level), ticks);
    }

    /** Shifts the clock by whole days, keeping the time of day. */
    public static void shiftDays(ServerLevel level, long days) {
        shiftHours(level, (int) (days * 24));
    }

    /**
     * Pulls the clock forward by {@code extra} ticks in one go.
     *
     * <p>A time cell makes the world run twenty times faster while it holds
     * somebody; each natural tick, the cell adds the remaining nineteen.</p>
     */
    public static void fastForward(ServerLevel level, long extraTicks) {
        if (extraTicks <= 0) {
            return;
        }
        long ticks = level.getOverworldClockTime();
        level.clockManager().setTotalTicks(overworldClock(level), ticks + extraTicks);
    }

    /** Shifts the clock by a number of hours. */
    public static void shiftHours(ServerLevel level, int hours) {
        if (hours == 0) {
            return;
        }
        level.clockManager().addTicks(overworldClock(level), hours * 1000);
    }

    /**
 * The timeline's key for "right now": a running count of world hours.
 *
 * <p>Using hours rather than days means the world remembers the afternoon as
 * separate from the morning, so a build you knocked down at 2 pm can still be
 * found at 10 am the same day. Day 1 at midnight is 24.</p>
     */
    public static long hourIndex(ServerLevel level) {
        long[] now = now(level);
        return now[0] * 24L + now[1];
    }

    /** The hour index for a day and hour, without touching the clock. */
    public static long hourIndex(long day, int hour) {
        return Math.max(0, day) * 24L + Math.floorMod(hour, 24);
    }

    public static String format(long day, int hour) {
        int h = Math.floorMod(hour, 24);
        String suffix = h < 12 ? "AM" : "PM";
        int display = h % 12;
        if (display == 0) {
            display = 12;
        }
        return String.format("day %d · %d %s", day, display, suffix);
    }
}