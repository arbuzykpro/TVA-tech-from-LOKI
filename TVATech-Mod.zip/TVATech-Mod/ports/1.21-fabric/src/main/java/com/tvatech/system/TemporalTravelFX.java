package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import com.tvatech.TvaConfig;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * The TemPad's time-jump animation.
 *
 * <p>Plays out as a <b>timedoor</b>: a glowing rectangular frame that snaps into
 * existence in front of the player, fills with light, and then draws them
 * through it. Three beats, each with its own sound:</p>
 * <ol>
 *   <li><b>Opening</b> - the frame traces itself out of the corners and the
 *       edges sweep inward, while the TemPad arms itself.</li>
 *   <li><b>Passage</b> - the doorway floods with light, the traveller is pulled
 *       into the middle of it and dropped out of the timeline.</li>
 *   <li><b>Arrival</b> - the same doorway rebuilds on the other side and fades.</li>
 * </ol>
 *
 * <p>Travel is tracked per player and cancelled automatically on logout, death
 * or a dimension change, so a player can never be stranded mid-jump.</p>
 */
public final class TemporalTravelFX {

    private TemporalTravelFX() {}

    private enum Stage { OPENING, ARRIVING }

    private static final class Pending {
        final ServerPlayer player;
        final UUID playerId;
        final BlockPos origin;
        final BlockPos destination;
        final Direction facing;
        final float yaw;
        final float pitch;
        final int openTicks;
        final int arriveTicks;
        int elapsed;
        Stage stage = Stage.OPENING;

        Pending(ServerPlayer player, BlockPos destination, int openTicks, int arriveTicks) {
            this.player = player;
            this.playerId = player.getUUID();
            this.origin = player.blockPosition();
            this.destination = destination;
            this.facing = Direction.fromYRot(player.getYRot());
            this.yaw = player.getYRot();
            this.pitch = player.getXRot();
            this.openTicks = Math.max(1, openTicks);
            this.arriveTicks = Math.max(1, arriveTicks);
        }
    }

    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    public static boolean isTravelling(ServerPlayer player) {
        return PENDING.containsKey(player.getUUID());
    }

    /** Starts the animation. Returns false if a jump is already running. */
    public static boolean begin(ServerPlayer player, BlockPos destination, int totalTicks) {
        if (isTravelling(player)) {
            return false;
        }
        int open = Math.max(1, (int) Math.round(totalTicks * 0.55));
        int arrive = Math.max(1, totalTicks - open);
        PENDING.put(player.getUUID(), new Pending(player, destination, open, arrive));
        return true;
    }

    public static void cancel(ServerPlayer player) {
        PENDING.remove(player.getUUID());
    }

    public static void cancel(UUID playerId) {
        PENDING.remove(playerId);
    }

    /** Advances every running animation. Called once per server tick. */
    public static void tick(MinecraftServer server) {
        if (PENDING.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<UUID, Pending>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Pending pending = it.next().getValue();
            ServerPlayer player = pending.player;

            // Nobody home (logged out, dead): drop it. The logout and
            // dimension-change listeners cancel explicitly; this is the net.
            if (player == null || !player.isAlive() || player.isRemoved() || player.serverLevel() == null) {
                it.remove();
                continue;
            }

            ServerLevel level = player.serverLevel();
            pending.elapsed++;

            if (pending.stage == Stage.OPENING) {
                runOpening(level, pending);
                if (pending.elapsed >= pending.openTicks) {
                    it.remove();
                    completeJump(player, pending);
                }
            } else {
                runArrival(level, pending);
                if (pending.elapsed >= pending.arriveTicks) {
                    it.remove();
                    endArrival(level, pending);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Stage 1: the door assembles
    // ------------------------------------------------------------------

    private static void runOpening(ServerLevel level, Pending pending) {
        float progress = clamp(pending.elapsed / (float) pending.openTicks);

        if (pending.elapsed == 1) {
            // The TemPad arms itself.
            level.playSound(null, pending.origin, SoundEvents.RESPAWN_ANCHOR_CHARGE,
                    SoundSource.PLAYERS, 0.7F, 1.5F);
        }
        if (pending.elapsed == Math.max(2, pending.openTicks / 3)) {
            // The doorway tears open.
            level.playSound(null, pending.origin, SoundEvents.PORTAL_TRIGGER,
                    SoundSource.PLAYERS, 0.95F, 1.1F);
        }
        if (pending.elapsed == pending.openTicks - 2) {
            level.playSound(null, pending.origin, SoundEvents.BEACON_POWER_SELECT,
                    SoundSource.PLAYERS, 0.6F, 1.8F);
        }

        drawTimedoor(level, doorPos(pending.origin, pending.facing), pending.facing, progress);
        drawGroundRing(level, pending.origin, progress);
    }

    // ------------------------------------------------------------------
    // Stage 2: the move
    // ------------------------------------------------------------------

    private static void completeJump(ServerPlayer player, Pending pending) {
        ServerLevel from = player.serverLevel();

        // The doorway floods, then swallows the traveller.
        burst(from, pending.origin, ParticleTypes.PORTAL, 140, 1.1, 1.8, 0.9);
        burst(from, pending.origin, ParticleTypes.ELECTRIC_SPARK, 60, 0.8, 1.4, 0.8);

        // The deep whoosh as the player drops out of the timeline.
        from.playSound(null, pending.origin, SoundEvents.PORTAL_TRAVEL,
                SoundSource.PLAYERS, 1.1F, 0.55F);

        // Full player teleport (camera reset + chunk tracking). A player without
        // a connection (headless self-test) just gets moved.
        if (player.connection != null) {
            player.teleportTo(from,
                    pending.destination.getX() + 0.5, pending.destination.getY(), pending.destination.getZ() + 0.5,
                    java.util.Set.of(), pending.yaw, pending.pitch);
        } else {
            player.setPos(pending.destination.getX() + 0.5, pending.destination.getY(),
                    pending.destination.getZ() + 0.5);
        }

        ServerLevel arrived = player.serverLevel();
        burst(arrived, pending.destination, ParticleTypes.PORTAL, 80, 0.8, 1.2, 0.8);
        arrived.playSound(null, pending.destination, SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.PLAYERS, 0.9F, 0.8F);

        TimeTravel.onArrived(player, pending.destination);

        // Stage 3.
        PENDING.put(player.getUUID(), pending);
        pending.elapsed = 0;
        pending.stage = Stage.ARRIVING;
    }

    // ------------------------------------------------------------------
    // Stage 3: the door rebuilds and fades
    // ------------------------------------------------------------------

    private static void runArrival(ServerLevel level, Pending pending) {
        float progress = clamp(pending.elapsed / (float) pending.arriveTicks);

        // Fade out: the door thins as the effect winds down.
        if (progress > 0.55) {
            return;
        }
        drawTimedoor(level, doorPos(pending.destination, pending.facing), pending.facing,
                1.0F - progress);
    }

    private static void endArrival(ServerLevel level, Pending pending) {
        level.playSound(null, pending.destination, SoundEvents.BEACON_DEACTIVATE,
                SoundSource.PLAYERS, 0.7F, 1.3F);
    }

    // ------------------------------------------------------------------
    // Particle helpers
    // ------------------------------------------------------------------

    /** Where the time door is drawn: a little in front of the player. */
    private static BlockPos doorPos(BlockPos origin, Direction facing) {
        return origin.relative(facing, 2);
    }

    /** The doorway is two blocks wide and three tall. */
    private static final double HALF_WIDTH = 1.05;
    private static final double BASE_HEIGHT = 0.15;
    private static final double DOOR_HEIGHT = 2.9;

    /**
     * Draws the timedoor itself: a rectangular frame standing upright, facing
     * the player's direction of travel.
     *
     * <p>The frame grows outward from the middle of each edge as {@code progress}
     * rises, and once it is more than half open the inside fills with light so
     * the doorway reads as a surface you could walk through rather than a
     * floating outline.</p>
     */
    private static void drawTimedoor(ServerLevel level, BlockPos base, Direction facing,
                                     float progress) {
        if (progress <= 0.01F) {
            return;
        }
        Direction right = facing.getClockWise();
        double centreX = base.getX() + 0.5;
        double centreY = base.getY() + BASE_HEIGHT;
        double centreZ = base.getZ() + 0.5;
        double rx = right.getStepX();
        double rz = right.getStepZ();

        float frame = clamp(progress * 1.15);
        double reach = HALF_WIDTH * frame;

        // Vertical edges.
        for (int side = -1; side <= 1; side += 2) {
            int steps = Math.max(1, (int) Math.round(10 * frame));
            for (int i = 0; i <= steps; i++) {
                double t = (double) i / steps;
                double y = centreY + t * DOOR_HEIGHT * frame;
                level.sendParticles(ParticleTypes.PORTAL,
                        centreX + rx * reach * side, y, centreZ + rz * reach * side,
                        2, 0.1, 0.1, 0.1, 0.0);
                if (progress > 0.45) {
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                            centreX + rx * reach * side, y, centreZ + rz * reach * side,
                            1, 0.06, 0.06, 0.06, 0.0);
                }
            }
        }

        // Top and bottom edges, sweeping in from the corners.
        double sweep = Math.max(0.0, (frame - 0.25) / 0.75);
        if (sweep > 0.01) {
            int steps = Math.max(1, (int) Math.round(9 * sweep));
            for (int i = 0; i <= steps; i++) {
                double t = (double) i / steps;
                double offset = (t - 0.5) * 2 * reach;
                for (int end = 0; end < 2; end++) {
                    double y = centreY + (end == 0 ? 0 : DOOR_HEIGHT * frame);
                    level.sendParticles(ParticleTypes.PORTAL,
                            centreX + rx * offset, y, centreZ + rz * offset,
                            2, 0.1, 0.1, 0.1, 0.0);
                }
            }
        }

        // The surface itself, once there is a doorway to fill.
        if (progress > 0.5) {
            float fill = (float) ((progress - 0.5) / 0.5);
            int rows = Math.max(1, (int) Math.round(7 * fill));
            int columns = Math.max(1, (int) Math.round(5 * fill));
            for (int row = 0; row < rows; row++) {
                for (int column = 0; column < columns; column++) {
                    double ox = ((double) column / Math.max(1, columns - 1) - 0.5) * 2 * reach * 0.85;
                    double oy = (double) row / rows * DOOR_HEIGHT * 0.95;
                    level.sendParticles(ParticleTypes.PORTAL,
                            centreX + rx * ox, centreY + oy, centreZ + rz * ox,
                            1, 0.16, 0.16, 0.16, 0.0);
                }
            }
        }
    }

    /** A ring of particles on the ground under the traveller. */
    private static void drawGroundRing(ServerLevel level, BlockPos centre, float progress) {
        double radius = 0.6 + progress * 1.2;
        int points = Math.max(8, (int) Math.round(24 * progress));
        for (int i = 0; i < points; i++) {
            double angle = (Math.PI * 2 * i) / points;
            level.sendParticles(ParticleTypes.PORTAL,
                    centre.getX() + 0.5 + Math.cos(angle) * radius,
                    centre.getY() + 0.1,
                    centre.getZ() + 0.5 + Math.sin(angle) * radius,
                    1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    private static void burst(ServerLevel level, BlockPos pos, ParticleOptions particle,
                              int count, double spread, double height, double radius) {
        level.sendParticles(particle,
                pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5,
                count, radius, height, radius, 0.03);
    }

    private static float clamp(double value) {
        return (float) Math.max(0.0, Math.min(1.0, value));
    }

    /** Total ticks a jump takes with the current config (0 = instant). */
    public static int durationTicks() {
        return Math.max(0, TvaConfig.travelAnimationTicks);
    }
}