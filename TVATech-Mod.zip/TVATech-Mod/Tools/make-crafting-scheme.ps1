# Generates "TVA Tech Crafting Scheme.png" for the Downloads folder.
# Text-based recipe list rendered with System.Drawing - no images, names never covered.
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$proj = "C:\Projects\TVATech-Mod"
$outPath = "C:\Users\arbuz\Downloads\TVA Tech Crafting Scheme.png"

$fontTitle = New-Object System.Drawing.Font("Segoe UI", 26, [System.Drawing.FontStyle]::Bold)
$fontHead  = New-Object System.Drawing.Font("Consolas", 15, [System.Drawing.FontStyle]::Bold)
$fontGrid  = New-Object System.Drawing.Font("Consolas", 14)
$fontText  = New-Object System.Drawing.Font("Segoe UI", 14)
$fontSmall = New-Object System.Drawing.Font("Segoe UI", 12)

$bg    = [System.Drawing.Color]::FromArgb(24, 18, 12)
$amber = [System.Drawing.Color]::FromArgb(255, 176, 74)
$textC = [System.Drawing.Color]::FromArgb(255, 206, 147)
$dimC  = [System.Drawing.Color]::FromArgb(176, 132, 82)

$bgBrush   = New-Object System.Drawing.SolidBrush($bg)
$amberBrush= New-Object System.Drawing.SolidBrush($amber)
$textBrush = New-Object System.Drawing.SolidBrush($textC)
$dimBrush  = New-Object System.Drawing.SolidBrush($dimC)

function Short([string]$id) {
    return ($id -replace "^.*?:(.*)$", '$1').Replace('_', ' ')
}

function Plural([string]$name, [int]$n) {
    if ($n -le 1) { return "$n $name" }
    if ($name -eq "glass") { return "$n glass" }
    return "$n $name"
}

# one clean recipe list, hand-ordered for progression reading
$order = @(
    "chronovium_ingot_from_smelting_raw_chronovium",
    "chronovium_ingot_from_blasting_raw_chronovium",
    "chronovium_block",
    "chronovium_ingot_from_block",
    "tempad",
    "tva_manual",
    "computer",
    "console",
    "terminal",
    "variant_scanner",
    "chronovium_block"
)
$order = $order | Select-Object -Unique
$recipeFiles = Get-ChildItem "$proj\src\main\resources\data\tvatech\recipe" -Filter *.json
$recipes = @()
foreach ($n in $order) {
    $f = $recipeFiles | Where-Object { $_.BaseName -eq $n }
    if ($f) {
        $j = Get-Content $f.FullName -Raw | ConvertFrom-Json
        $recipes += [pscustomobject]@{ Name = $n; Json = $j }
    }
}
foreach ($f in $recipeFiles) {
    if ($order -notcontains $f.BaseName) {
        $j = Get-Content $f.FullName -Raw | ConvertFrom-Json
        $recipes += [pscustomobject]@{ Name = $f.BaseName; Json = $j }
    }
}

$W = 1500
$H = 150 + $recipes.Count * 140 + 360
$bmp = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
$g.FillRectangle($bgBrush, 0, 0, $W, $H)

$y = 26
$g.DrawString("TVA TECH - CRAFTING SCHEMES (v2.1.7)", $fontTitle, $amberBrush, 40, $y)
$y += [int]($fontTitle.GetHeight($g) + 4)
$g.DrawString("how every gadget is made, in order  -  MC 26.3 Forge / Fabric and 1.21 / 1.21.1 Fabric", $fontSmall, $dimBrush, 42, $y)
$y += [int]($fontSmall.GetHeight($g) + 10)

foreach ($r in $recipes) {
    $j = $r.Json
    $type = $j.type -replace "^minecraft:", ""
    $resultId = $j.result.id
    $resultCount = 1
    if ($j.result.count -ne $null) { $resultCount = [int]$j.result.count }

    $g.DrawString(("{0}   x{1}" -f (Short $resultId).ToUpper(), $resultCount), $fontHead, $amberBrush, 40, $y)
    $y += [int]($fontHead.GetHeight($g) + 2)

    if ($type -eq "crafting_shaped") {
        $need = @{}
        foreach ($p in $j.pattern) {
            foreach ($ch in $p.ToCharArray()) {
                if ($ch -ne " ") {
                    $id = $j.key."$ch"
                    if ($need.ContainsKey($id)) { $need[$id]++ } else { $need[$id] = 1 }
                }
            }
        }
        $list = ($need.GetEnumerator() | Sort-Object Name | ForEach-Object { Plural (Short $_.Key) $_.Value }) -join ", "
        $g.DrawString("needs: $list", $fontText, $textBrush, 58, $y)
        $y += [int]($fontText.GetHeight($g) + 2)
        $grid = ($j.pattern | ForEach-Object { "|$_|" }) -join " "
        $g.DrawString("shape: $grid", $fontGrid, $textBrush, 58, $y)
        $y += [int]($fontGrid.GetHeight($g) + 2)
        $legend = ($j.key.PSObject.Properties | ForEach-Object { "$($_.Name) = $(Short $_.Value)" }) -join "   "
        $g.DrawString("letters: $legend", $fontSmall, $dimBrush, 58, $y)
        $y += [int]($fontSmall.GetHeight($g) + 2)
    } elseif ($type -eq "crafting_shapeless") {
        $need = @{}
        foreach ($ing in $j.ingredients) {
            if ($need.ContainsKey($ing)) { $need[$ing]++ } else { $need[$ing] = 1 }
        }
        $list = ($need.GetEnumerator() | Sort-Object Name | ForEach-Object { Plural (Short $_.Key) $_.Value }) -join ", "
        $g.DrawString("needs: $list", $fontText, $textBrush, 58, $y)
        $y += [int]($fontText.GetHeight($g) + 2)
        $g.DrawString("shape: any (shapeless)", $fontSmall, $dimBrush, 58, $y)
        $y += [int]($fontSmall.GetHeight($g) + 2)
    } elseif ($type -eq "smelting" -or $type -eq "blasting") {
        $cooked = "furnace"
        if ($type -eq "blasting") { $cooked = "blast furnace" }
        $g.DrawString(("needs: {0} {1}, cooked in the {2} ({3}s)" -f $resultCount, (Short $j.ingredient), $cooked, [int]$j.cookingtime), $fontText, $textBrush, 58, $y)
        $y += [int]($fontText.GetHeight($g) + 2)
        $g.DrawString("shape: none", $fontSmall, $dimBrush, 58, $y)
        $y += [int]($fontSmall.GetHeight($g) + 2)
    }
    $y += 12
}

$sep = New-Object System.Drawing.Pen($dimBrush, 1)
$g.DrawLine($sep, 40, $y, $W - 40, $y)
$y += 14
$g.DrawString("2.1.7 changelog", $fontHead, $amberBrush, 40, $y)
$y += [int]($fontHead.GetHeight($g) + 4)
$y += 0
foreach ($line in @(
    "* TEXTURES FIXED: the Time Collar and Time Collar Remote finally show",
    "  their item icons (they were invisible checkerboards before).",
    "* COLLAR REMOVAL MADE EASY: sneak-right-click the creature wearing",
    "  YOUR collar - empty hand or holding anything - and it pops off and",
    "  drops back as an item. Only the agent who clamped it on can.",
    "* COLLAR SURVIVES DEATH: kill a wearer and the collar pops off and",
    "  drops as an item where they fell."
)) {
    $g.DrawString($line, $fontText, $textBrush, 58, $y)
    $y += [int]($fontText.GetHeight($g) + 2)
}

$g.Dispose()
$bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
"DONE: $outPath ($W x $H)"
