package com.tvatech.event;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityLevelChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import com.tvatech.ModContent;
import com.tvatech.TvaConfig;
import com.tvatech.TvaMessages;
import com.tvatech.block.TimeDoorBlock;
import com.tvatech.system.ChronoFreeze;
import com.tvatech.system.MobileAbilities;
import com.tvatech.system.Pruning;
import com.tvatech.system.TemPadMenu;
import com.tvatech.system.Timeline;
import com.tvatech.system.TimelineItems;
import com.tvatech.system.TimeTravel;
import com.tvatech.system.TvaMarks;
import com.tvatech.system.TvaSelfTest;
import com.tvatech.util.TvaData;
import com.tvatech.util.TvaEntityName;
import com.tvatech.util.TvaFeedback;

/**
 * All gameplay wiring in one place.
 *
 * <p>Fabric has no mod event bus: these are the loader's own callback
 * interfaces, registered once from the entrypoint.</p>
 */
public final class TvaEvents {

    private TvaEvents() {}

    public static void register() {
        // Right clicking with the gadgets.
        UseItemCallback.EVENT.register(TvaEvents::onRightClickItem);
        UseBlockCallback.EVENT.register(TvaEvents::onRightClickBlock);
        UseEntityCallback.EVENT.register(TvaEvents::onEntityInteract);

        // Death must not swallow a worn collar: it pops off and drops.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) ->
                com.tvatech.system.TimeCollar.dropOnDeath(entity));

        // Server tick: portal animation, time doors, timeline catch-up.
        ServerTickEvents.END_SERVER_TICK.register(TvaEvents::onServerTick);
        ServerTickEvents.END_SERVER_TICK.register(TvaEvents::onTimelineSweep);

        // A jump in flight must never outlive the player who started it.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer player = handler.getPlayer();
            ChronoFreeze.releaseAllLockedBy(player);
            com.tvatech.system.TemporalTravelFX.cancel(player.getUUID());
            com.tvatech.system.TimedoorPortal.close(player.getUUID());
            com.tvatech.system.MissMinutes.clear(player.getUUID());
        });
        ServerEntityLevelChangeEvents.AFTER_PLAYER_CHANGE_LEVEL.register((player, origin, destination) ->
                com.tvatech.system.TemporalTravelFX.cancel(player.getUUID()));

        // /tva admin + testing commands.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                com.tvatech.command.TvaCommands.register(dispatcher));

        // The world remembers what it looked like on every day.
        //
        // Breaking is the only block event Fabric exposes; placements and
        // neighbour updates are picked up by the periodic sweep instead, which
        // is the same code path that catches fire, decay and pistons.
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            // A time door is held together by the TemPad. It is not something
            // you can mine apart while it is open.
            if (state.is(ModContent.TIMEDOOR_FIELD.get())) {
                world.playSound(null, pos, SoundEvents.BEACON_POWER_SELECT,
                        SoundSource.BLOCKS, 0.4F, 2.0F);
                return false;
            }
            if (world instanceof ServerLevel serverLevel) {
                Timeline.stashBreak(pos, state);
            }
            return true;
        });

        ServerChunkEvents.CHUNK_LOAD.register((world, chunk, newChunk) ->
                Timeline.onChunkLoaded(world, chunk.getPos()));

        // Dropped items and storage blocks follow the timeline as well.
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> TimelineItems.onJoin(world, entity));
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> TimelineItems.onLeave(world, entity));

        // Optional startup self-check (launch with -Dtva.selftest=true).
        ServerLifecycleEvents.SERVER_STARTED.register(TvaSelfTest::onServerStarted);

        // "Time of death" respawn.
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> onRespawn(newPlayer));
    }

    // ==================================================================
    // Ticks
    // ==================================================================

    private static void onServerTick(net.minecraft.server.MinecraftServer server) {
        com.tvatech.system.TemporalTravelFX.tick(server);
        // Time doors you can walk through: ripple, notice the player, shut.
        com.tvatech.system.TimedoorPortal.tick(server);
        // Time cells: prisoners drop and drop, and the clock burns hot.
        com.tvatech.system.TimeCells.tick(server);
        // Collared creatures file where they stand, for the rewind.
        com.tvatech.system.TimeCollar.tick(server);
        // Miss Minutes runs her orientations.
        com.tvatech.system.MissMinutes.tick(server);
        // Chunks that finished loading since the last tick get the version of
        // themselves that belongs to the current day.
        Timeline.drainPendingChunks(server.overworld());

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.tickCount % 20 == 0) {
                MobileAbilities.tickCooldown(player);
                // Fabric has no crafted event, so a first one of the gadgets
                // surfacing in the inventory is the next best orientation bell.
                com.tvatech.system.MissMinutes.onInventorySeen(player);
            }
            ChronoFreeze.tickFor(player);
        }
    }

    private static void onTimelineSweep(net.minecraft.server.MinecraftServer server) {
        if (!TvaConfig.timelineBlocks || TvaConfig.timelineSweepTicks <= 0) {
            return;
        }
        if (server.getTickCount() == 40) {
            for (ServerLevel level : server.getAllLevels()) {
                long hour = com.tvatech.system.WorldTime.hourIndex(level);
                Timeline.switchTo(level, hour);
                TimelineItems.switchTo(level, hour);
            }
            return;
        }
        if (server.getTickCount() % TvaConfig.timelineSweepTicks == 0) {
            Timeline.sweep(server.overworld());
            TimelineItems.sweep(server.overworld());
        }
    }

    // ==================================================================
    // Interaction
    // ==================================================================

    private static InteractionResult onRightClickItem(Player player, Level level, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Charging in mid-air needs sneaking so it never steals a travel tap.
        if (player.isShiftKeyDown() && tryChargeFromHand(player, hand, player.blockPosition())) {
            return InteractionResult.SUCCESS;
        }

        if (stack.is(ModContent.TEMPAD.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                TemPadMenu.open(serverPlayer);
            }
            return InteractionResult.SUCCESS;
        }
        if (stack.is(ModContent.MOBIUS_MOBILE.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                MobileAbilities.pushState(serverPlayer);
            }
            return InteractionResult.SUCCESS;
        }
        if (stack.is(ModContent.VARIANT_SCANNER.get())) {
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    private static InteractionResult onRightClickBlock(Player player, Level level, InteractionHand hand,
                                                       BlockHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);
        BlockPos pos = hit.getBlockPos();
        BlockState state = level.getBlockState(pos);

        // Using a storage block starts tracking it, whatever else this click
        // ends up doing.
        if (player instanceof ServerPlayer serverPlayer) {
            TimelineItems.onContainerTouched(serverPlayer.level(), pos);
        }

        // A Chrono Battery in either hand tops up the gadget in the other one.
        //
        // Sneaking is required: without it, simply having a battery in your
        // offhand silently ate every block right-click.
        if (player.isShiftKeyDown() && tryChargeFromHand(player, hand, pos)) {
            return InteractionResult.SUCCESS;
        }

        // Arc Reactors are a free charging station.
        if (state.is(ModContent.ARC_REACTOR.get()) && player.isShiftKeyDown()) {
            ItemStack gadget = gadgetInEitherHand(player);
            if (gadget != null) {
                if (player instanceof ServerPlayer serverPlayer) {
                    chargeGadget(serverPlayer, gadget, pos, false);
                }
                return InteractionResult.SUCCESS;
            }
        }

        // Time doors.
        if (state.is(ModContent.TIME_DOOR.get())) {
            ItemStack gadget = gadgetInEitherHand(player);
            if (gadget != null && gadget.is(ModContent.TEMPAD.get())) {
                if (player instanceof ServerPlayer serverPlayer) {
                    TemPadMenu.open(serverPlayer);
                }
                return InteractionResult.SUCCESS;
            }

            // Bare handed: toggle the door.
            TimeDoorBlock.setOpen(level, pos, !state.getValue(TimeDoorBlock.OPEN));
            level.playSound(null, pos,
                    state.getValue(TimeDoorBlock.OPEN) ? SoundEvents.BEACON_DEACTIVATE : SoundEvents.BEACON_ACTIVATE,
                    SoundSource.BLOCKS, 0.7F, 1.2F);
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.PORTAL,
                        pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5, 24, 0.4, 0.6, 0.4, 0.05);
            }
            return InteractionResult.SUCCESS;
        }

        // Right-clicking anything with the TemPad opens the destination menu.
        // Sneaking drops a mark where you stand without opening it.
        if (stack.is(ModContent.TEMPAD.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                if (player.isShiftKeyDown()) {
                    markHere(serverPlayer);
                } else {
                    TemPadMenu.open(serverPlayer);
                }
            }
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    /**
     * Drops a mark where the player is standing - the quick version of the
     * menu's "make mark" button.
     */
    private static void markHere(ServerPlayer player) {
        ServerLevel level = player.level();
        BlockPos standing = player.blockPosition();
        BlockPos safe = TimeTravel.nearestSafe(level, standing);

        TvaMarks.add(player, level, safe.getX(), safe.getY(), safe.getZ());
        TvaFeedback.actionBar(player, TvaMessages.markMade(String.valueOf(TvaMarks.of(player).size())));

        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                safe.getX() + 0.5, safe.getY() + 1.0, safe.getZ() + 0.5, 16, 0.4, 0.6, 0.4, 0.02);
        level.playSound(null, safe, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8F, 1.6F);
    }

    private static InteractionResult onEntityInteract(Player player, Level level, InteractionHand hand,
                                                      Entity target, EntityHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);

        // Bare hands work too: sneaking on a collared creature with an
        // empty hand pops your collar straight back off, before any
        // vanilla or held-item interaction gets a look in. Only runs on
        // the server, where the collar ledger lives.
        if (stack.isEmpty() && player.isShiftKeyDown()
                && player instanceof ServerPlayer agent
                && com.tvatech.system.TimeCollar.remove(target, agent.getUUID())) {
            return InteractionResult.SUCCESS;
        }

        if (stack.is(ModContent.VARIANT_SCANNER.get())) {
            if (player instanceof ServerPlayer serverPlayer && target.isAlive()) {
                if (TimeTravel.variant(target) == 0) {
                    int variant = 100 + Math.abs(target.getUUID().hashCode() % 900);
                    TimeTravel.setVariant(target, variant);
                    TvaFeedback.actionBar(serverPlayer, TvaMessages.scannerTagged(TvaEntityName.of(target), variant));
                    serverPlayer.level().playSound(null, target.blockPosition(),
                            SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.9F, 1.6F);
                } else {
                    TvaFeedback.actionBar(serverPlayer, TvaMessages.alreadyScanned(TvaEntityName.of(target),
                            TimeTravel.variant(target)));
                }
            }
            return InteractionResult.SUCCESS;
        }

        if (stack.is(ModContent.TEMPAD.get())) {
            if (player instanceof ServerPlayer serverPlayer) {
                if (!TvaConfig.allowPruning) {
                    TvaFeedback.actionBar(serverPlayer, TvaMessages.pruningDisabled());
                } else if (target instanceof net.minecraft.world.entity.LivingEntity) {
                    Pruning.prune(target, serverPlayer);
                } else {
                    Pruning.pruneNonLiving(target);
                }
            }
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    /** Sells the collar back at the death spot instead of losing it. */
    private static void onLivingDeath(net.minecraft.world.entity.LivingEntity entity) {
        com.tvatech.system.TimeCollar.dropOnDeath(entity);
    }

    // ==================================================================
    // Respawn
    // ==================================================================
    private static void onRespawn(ServerPlayer player) {
        var anchor = TvaData.anchor(player);
        if (anchor == null) {
            return;
        }
        TvaData.clearAnchor(player);

        var dimString = anchor.getString("dim").orElse("");
        ServerLevel level = null;
        for (var candidate : player.level().getServer().getAllLevels()) {
            if (candidate.dimension().identifier().toString().equals(dimString)) {
                level = candidate;
                break;
            }
        }
        if (level == null) {
            return;
        }
        var wanted = new BlockPos(
                anchor.getInt("x").orElse(0),
                anchor.getInt("y").orElse(0),
                anchor.getInt("z").orElse(0));
        var safe = TimeTravel.nearestSafe(level, wanted);

        // The callback fires straight after vanilla placed the player, so this wins.
        player.teleportTo(level, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5,
                java.util.Set.of(), player.getYRot(), player.getXRot(), true);

        TimeTravel.log(player, "Returned from the void at " + TimeTravel.describe(level, safe));
        TvaFeedback.actionBar(player, TvaMessages.prunedRespawn());
        level.sendParticles(ParticleTypes.PORTAL,
                safe.getX() + 0.5, safe.getY() + 1.0, safe.getZ() + 0.5, 60, 0.6, 1.0, 0.6, 0.1);
        level.playSound(null, safe, SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.8F, 0.9F);
    }

    // ==================================================================
    // Small helpers
    // ==================================================================

    /** The TemPad or Mobius Mobile in either hand, or null. */
    private static ItemStack gadgetInEitherHand(Player player) {
        ItemStack main = player.getMainHandItem();
        if (isGadget(main)) {
            return main;
        }
        ItemStack off = player.getOffhandItem();
        return isGadget(off) ? off : null;
    }

    private static boolean isGadget(ItemStack stack) {
        return stack.is(ModContent.TEMPAD.get()) || stack.is(ModContent.MOBIUS_MOBILE.get());
    }

    /** The Chrono Battery in either hand, or null. */
    private static ItemStack batteryInEitherHand(Player player) {
        ItemStack main = player.getMainHandItem();
        if (main.is(ModContent.CHRONO_BATTERY.get())) {
            return main;
        }
        ItemStack off = player.getOffhandItem();
        return off.is(ModContent.CHRONO_BATTERY.get()) ? off : null;
    }

    /**
     * Charges the gadget with a Chrono Battery held in the other hand.
     *
     * @return true when a charge was consumed (the caller should cancel)
     */
    private static boolean tryChargeFromHand(Player player, InteractionHand hand, BlockPos pos) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return false;
        }
        ItemStack battery = batteryInEitherHand(player);
        ItemStack gadget = gadgetInEitherHand(player);
        if (battery == null || gadget == null) {
            return false;
        }
        // Only spend the battery if it actually went into the gadget.
        if (chargeGadget(serverPlayer, gadget, pos, true) && !serverPlayer.getAbilities().instabuild) {
            battery.shrink(1);
        }
        return true;
    }

    /**
     * Adds charge to a gadget and plays the feedback.
     *
     * @param fromBattery {@code true} when a Chrono Battery is spent for it,
     *                    {@code false} when an Arc Reactor powered it
     * @return {@code true} if the gadget gained charge
     */
    private static boolean chargeGadget(ServerPlayer player, ItemStack gadget, BlockPos pos, boolean fromBattery) {
        int before = TimeTravel.charge(gadget);
        TimeTravel.addCharge(gadget, TvaConfig.batteryCharge);

        ServerLevel level = player.level();
        boolean gained = TimeTravel.charge(gadget) > before;
        if (gained) {
            TvaFeedback.actionBar(player, TvaMessages.charged(TvaConfig.batteryCharge));
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8F, 1.4F);
        } else {
            TvaFeedback.actionBar(player, TvaMessages.alreadyCharged());
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                fromBattery ? 12 : 24, 0.4, 0.5, 0.4, 0.03);
        if (!fromBattery) {
            level.playSound(null, pos, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 0.7F, 1.5F);
        }
        return gained;
    }
}
