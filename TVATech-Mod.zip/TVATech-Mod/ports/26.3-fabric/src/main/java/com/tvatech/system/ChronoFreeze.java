package com.tvatech.system;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import com.tvatech.TvaConfig;
import com.tvatech.TvaMessages;
import com.tvatech.util.TvaData;
import com.tvatech.util.TvaFeedback;

import java.util.List;
import java.util.UUID;

/**
 * "Time freezing" - the Mobius Mobile's signature trick.
 *
 * <p>Everything living inside the radius stops moving and stops thinking until
 * the chrono-lock expires. The lock is stamped on each entity (game time of
 * expiry + who set it) so it survives chunk unloading, and it is always
 * released - either when the timer runs out or when the operator disconnects.</p>
 */
public final class ChronoFreeze {

    private ChronoFreeze() {}

    /** Applies the freeze and returns how many entities were locked. */
    public static int freeze(ServerPlayer player, int radius, int durationTicks) {
        ServerLevel level = player.level();
        long now = level.getGameTime();
        UUID owner = player.getUUID();

        AABB area = player.getBoundingBox().inflate(radius);
        List<Entity> targets = level.getEntities(player, area, ChronoFreeze::isLockable);

        int locked = 0;
        for (Entity entity : targets) {
            long until = Math.max(now + durationTicks, TvaData.frozenUntil(entity));
            TvaData.setFrozenUntil(entity, (int) Math.min(until, Integer.MAX_VALUE));
            TvaData.setFrozenBy(entity, owner.getMostSignificantBits() ^ owner.getLeastSignificantBits());
            lock(entity);
            locked++;
        }

        // Ring of sparks at the edge of the field, plus a shockwave of particles.
        double r = Math.max(1.0, radius);
        for (int i = 0; i < 64; i++) {
            double angle = (Math.PI * 2 * i) / 64.0;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    player.getX() + Math.cos(angle) * r,
                    player.getY() + 0.4,
                    player.getZ() + Math.sin(angle) * r,
                    3, 0.1, 0.4, 0.1, 0.0);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.6F, 1.4F);

        return locked;
    }

    private static boolean isLockable(Entity entity) {
        return entity instanceof Mob && !(entity instanceof Player) && entity.isAlive();
    }

    /** Puts a single entity into the stopped state. */
    public static void lock(Entity entity) {
        if (entity instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setTarget(null);
        }
        entity.setDeltaMovement(Vec3.ZERO);
    }

    /**
     * Called periodically for each player: releases anything whose timer expired
     * and keeps frozen entities pinned in place.
     */
    public static void tickFor(Player player) {
        if (!(player.level() instanceof ServerLevel level) || level.getGameTime() % 5L != 0L) {
            return;
        }
        long now = level.getGameTime();
        AABB area = player.getBoundingBox().inflate(48);
        for (Entity entity : level.getEntities(player, area, e -> TvaData.frozenUntil(e) > 0)) {
            int until = TvaData.frozenUntil(entity);
            if (until <= now) {
                release(entity);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        entity.getX(), entity.getY() + entity.getBbHeight() / 2.0, entity.getZ(),
                        8, 0.2, 0.3, 0.2, 0.02);
            } else {
                lock(entity);
                if (now % 20L == 0L) {
                    level.sendParticles(ParticleTypes.SOUL,
                            entity.getX(), entity.getY() + entity.getBbHeight() / 2.0, entity.getZ(),
                            2, 0.3, 0.4, 0.3, 0.01);
                }
            }
        }
    }

    public static void release(Entity entity) {
        TvaData.setFrozenUntil(entity, 0);
        TvaData.setFrozenBy(entity, 0L);
        if (entity instanceof Mob mob) {
            mob.setNoAi(false);
        }
        entity.setDeltaMovement(Vec3.ZERO);
    }

    /** Never leave a chunk full of statues behind: free everything this player locked. */
    public static void releaseAllLockedBy(Player player) {
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        long key = player.getUUID().getMostSignificantBits() ^ player.getUUID().getLeastSignificantBits();
        AABB area = player.getBoundingBox().inflate(96);
        for (Entity entity : level.getEntities(player, area, e -> TvaData.frozenBy(e) == key && TvaData.frozenUntil(e) > 0)) {
            release(entity);
        }
    }

    /** Checks the abilities of the mobile and runs the requested one. */
    public static boolean performFreeze(ServerPlayer player) {
        int cooldown = MobileAbilities.freezeCooldown(player);
        if (cooldown > 0) {
            TvaFeedback.actionBar(player, TvaMessages.freezeCooling(cooldown));
            return false;
        }
        if (TvaConfig.freezeRequiresReactor && !MobileAbilities.hasReactorNearby(player)) {
            TvaFeedback.actionBar(player, TvaMessages.needsReactor());
            return false;
        }
        ItemStack mobile = MobileAbilities.mobileStack(player);
        if (mobile == null) {
            TvaFeedback.actionBar(player, TvaMessages.noMobile());
            return false;
        }
        if (TimeTravel.charge(mobile) < TvaConfig.freezeCost) {
            TvaFeedback.actionBar(player, TvaMessages.outOfCharge());
            return false;
        }

        int locked = freeze(player, TvaConfig.freezeRadius, TvaConfig.freezeDurationTicks);
        TimeTravel.addCharge(mobile, -TvaConfig.freezeCost);
        MobileAbilities.setFreezeCooldown(player, TvaConfig.freezeCooldownTicks);
        TvaFeedback.actionBar(player, TvaMessages.frozen(locked, TvaConfig.freezeDurationTicks / 20));
        TimeTravel.log(player, "Chrono-lock on " + locked + " variants for " + (TvaConfig.freezeDurationTicks / 20.0) + "s");
        return true;
    }
}