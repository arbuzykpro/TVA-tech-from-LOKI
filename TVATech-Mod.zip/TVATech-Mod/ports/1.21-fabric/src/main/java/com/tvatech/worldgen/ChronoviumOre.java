package com.tvatech.worldgen;

import com.tvatech.TVATech;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.levelgen.GenerationStep;

/**
 * Puts the chronovium vein into every overworld biome.
 *
 * <p>On Forge this is the {@code forge/biome_modifier/add_chronovium.json}
 * datapack file. Fabric has no data-driven biome modifiers, so the same thing
 * is done through the Biome Modification API: point every overworld biome at
 * the placed feature that already exists in the datapack.</p>
 */
public final class ChronoviumOre {

    private ChronoviumOre() {}

    public static void register() {
        ResourceKey<net.minecraft.world.level.levelgen.placement.PlacedFeature> key =
                ResourceKey.create(Registries.PLACED_FEATURE,
                        ResourceLocation.fromNamespaceAndPath(TVATech.MODID, "chronovium_ore_placed"));

        BiomeModifications.addFeature(
                BiomeSelectors.tag(BiomeTags.IS_OVERWORLD),
                GenerationStep.Decoration.UNDERGROUND_ORES,
                key);

        registered = true;
    }

    private static boolean registered;

    /** True once the overworld hook has been installed. */
    public static boolean isRegistered() {
        return registered;
    }
}
