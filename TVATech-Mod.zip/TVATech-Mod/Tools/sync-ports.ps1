<#
    sync-ports.ps1 - carry updates from a source tree to the port that mirrors it.

    Why this file exists:
    Some targets are not independent code bases. They are the same mod with a
    different loader or a different Minecraft patch level, so their sources are
    supposed to be identical except for a couple of metadata files. Editing one
    and forgetting the other is the easy way to ship two jars that behave
    differently. This script copies the files that must match and leaves the
    loader layer alone.

    The relationships it knows about:

      26.3 Forge (src/main) -> 26.3 Fabric (ports/26.3-fabric)
          Same Minecraft and same datapack schema, so assets/ and data/ are
          copied verbatim. Java is copied too, except for the handful of files
          listed in $loaderFiles below: those are the ones the Fabric port had
          to rewrite (registries, networking, config, client init, self-test).
          A change to one of those needs a manual merge; the script prints them
          so they are not forgotten.

      1.21.1 Fabric (ports/1.21.1-fabric) -> 1.21 Fabric (ports/1.21-fabric)
          The two ports are byte-identical except fabric.mod.json, which pins
          the Minecraft version range.

    What it does NOT do:
      1.20.1 and the 1.21.x Forge targets are genuine ports with older APIs and
      different data formats. Nothing here can copy them, and pretending
      otherwise is how you get a jar that compiles but cannot load its data.

    Usage:
        powershell -ExecutionPolicy Bypass -File Tools\sync-ports.ps1
        powershell -ExecutionPolicy Bypass -File Tools\sync-ports.ps1 -DryRun

    Only files whose content actually differs are written, so running it twice
    is a no-op. Rebuild and re-run the self-test after syncing.
#>
[CmdletBinding()]
param(
    [switch] $DryRun
)

$ErrorActionPreference = 'Stop'

$root = Split-Path $PSScriptRoot -Parent

# Java files the 26.3 Fabric port rewrites for the loader. Everything else in
# com/tvatech is platform-neutral and must stay in step with src/main/java.
$loaderFiles = @(
    'com\tvatech\TVATech.java'
    'com\tvatech\ModContent.java'
    'com\tvatech\TvaConfig.java'
    'com\tvatech\command\TvaCommands.java'
    'com\tvatech\event\TvaEvents.java'
    'com\tvatech\network\TvaNetwork.java'
    'com\tvatech\system\TemPadMenu.java'
    'com\tvatech\system\TvaMarks.java'
    'com\tvatech\system\TvaSelfTest.java'
    'com\tvatech\util\TvaData.java'
)

function Sync-Tree {
    param(
        [string] $From,
        [string] $To,
        [string[]] $Skip = @()
    )

    $updated = 0
    $added = 0
    foreach ($file in Get-ChildItem $From -Recurse -File) {
        $rel = $file.FullName.Substring($From.Length).TrimStart('\')
        if ($Skip -contains $rel) { continue }

        $dest = Join-Path $To $rel
        if (Test-Path $dest) {
            if ((Get-FileHash $file.FullName).Hash -eq (Get-FileHash $dest).Hash) { continue }
            $updated++
        } else {
            $added++
        }

        if (-not $DryRun) {
            New-Item -ItemType Directory -Force -Path (Split-Path $dest -Parent) | Out-Null
            Copy-Item $file.FullName $dest -Force
        }
    }

    $verb = if ($DryRun) { 'would change' } else { 'updated' }
    Write-Host ("  {0} {1}, {2} added" -f ($updated + $added), $verb, $added)
}

function Path-Under([string] $Base, [string[]] $Parts) {
    $path = $Base
    foreach ($p in $Parts) { $path = Join-Path $path $p }
    return $path
}

Write-Host '26.3 Forge -> 26.3 Fabric' -ForegroundColor Cyan
Sync-Tree (Path-Under $root @('src', 'main', 'resources', 'assets')) `
          (Path-Under $root @('ports', '26.3-fabric', 'src', 'main', 'resources', 'assets'))
Sync-Tree (Path-Under $root @('src', 'main', 'resources', 'data')) `
          (Path-Under $root @('ports', '26.3-fabric', 'src', 'main', 'resources', 'data'))
Sync-Tree (Path-Under $root @('src', 'main', 'java')) `
          (Path-Under $root @('ports', '26.3-fabric', 'src', 'main', 'java')) `
          $loaderFiles

$javaRoot = Path-Under $root @('src', 'main', 'java')
$present = $loaderFiles | Where-Object { Test-Path (Join-Path $javaRoot $_) }
if ($present) {
    Write-Host '  loader-specific, merge by hand when changed:' -ForegroundColor Yellow
    $present | ForEach-Object { Write-Host "    $_" }
}

Write-Host '1.21.1 Fabric -> 1.21 Fabric' -ForegroundColor Cyan
Sync-Tree (Path-Under $root @('ports', '1.21.1-fabric', 'src')) `
          (Path-Under $root @('ports', '1.21-fabric', 'src')) `
          @('main\resources\fabric.mod.json')

Write-Host 'Done. Rebuild the affected targets and re-run the self-test.' -ForegroundColor Green
