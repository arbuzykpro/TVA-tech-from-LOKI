# Generates the mod's 16x16 pixel-art textures procedurally.
# Run:  pwsh -File Tools/generate_textures.ps1
# Output: src/main/resources/assets/tvatech/textures/{item,block}/*.png

Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$texRoot = Join-Path $root 'src/main/resources/assets/tvatech/textures'
$itemDir = Join-Path $texRoot 'item'
$blockDir = Join-Path $texRoot 'block'
New-Item -ItemType Directory -Force -Path $itemDir, $blockDir | Out-Null

# ---- palette (TVA / Loki prop colours) -------------------------------------
$C = @{
    Stone        = [System.Drawing.Color]::FromArgb(255, 128, 128, 128)
    StoneDark    = [System.Drawing.Color]::FromArgb(255, 108, 108, 108)
    Deepslate    = [System.Drawing.Color]::FromArgb(255,  80,  80,  84)
    DeepslateDark= [System.Drawing.Color]::FromArgb(255,  68,  68,  72)
    CaseDark  = [System.Drawing.Color]::FromArgb(255, 58, 42, 28)    # dark bronze leather case
    CaseMid   = [System.Drawing.Color]::FromArgb(255, 96, 68, 40)    # mid brown
    CaseLight = [System.Drawing.Color]::FromArgb(255, 138, 100, 58)   # highlight
    Metal     = [System.Drawing.Color]::FromArgb(255, 198, 168, 96)   # brass trim
    MetalDark = [System.Drawing.Color]::FromArgb(255, 120, 96, 52)
    Screen    = [System.Drawing.Color]::FromArgb(255, 24, 58, 54)     # dark teal screen glass
    ScreenLit = [System.Drawing.Color]::FromArgb(255, 86, 226, 196)   # glowing teal data
    Amber     = [System.Drawing.Color]::FromArgb(255, 255, 176, 74)   # TVA orange glow
    AmberHot  = [System.Drawing.Color]::FromArgb(255, 255, 240, 196)
    AmberDeep = [System.Drawing.Color]::FromArgb(255, 176, 78, 20)
    Void      = [System.Drawing.Color]::FromArgb(255, 20, 14, 18)
    Ink       = [System.Drawing.Color]::FromArgb(255, 26, 22, 20)
    Steel     = [System.Drawing.Color]::FromArgb(255, 176, 178, 186)
    SteelDark = [System.Drawing.Color]::FromArgb(255, 104, 108, 118)
    SteelLite = [System.Drawing.Color]::FromArgb(255, 232, 234, 240)
    Paper     = [System.Drawing.Color]::FromArgb(255, 226, 218, 204)
    PaperDark = [System.Drawing.Color]::FromArgb(255, 176, 166, 150)
    Green     = [System.Drawing.Color]::FromArgb(255, 74, 210, 118)
    GreenDark = [System.Drawing.Color]::FromArgb(255, 24, 120, 66)
}

function New-Canvas([int]$w = 16, [int]$h = 16) {
    $bmp = New-Object System.Drawing.Bitmap($w, $h, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.Color]::Transparent)
    # no smoothing - we want crisp pixels
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::None
    return @($bmp, $g)
}

function Save-Canvas($bmp, [string]$path) {
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "  wrote $path"
}

# helper: fill a rect of pixels
function Fill-Rect($bmp, [int]$x, [int]$y, [int]$w, [int]$h, $color) {
    for ($i = $x; $i -lt ($x + $w); $i++) {
        for ($j = $y; $j -lt ($y + $h); $j++) {
            if ($i -ge 0 -and $j -ge 0 -and $i -lt $bmp.Width -and $j -lt $bmp.Height) {
                $bmp.SetPixel($i, $j, $color)
            }
        }
    }
}

function Set-Px($bmp, [int]$x, [int]$y, $color) {
    if ($x -ge 0 -and $y -ge 0 -and $x -lt $bmp.Width -and $y -lt $bmp.Height) {
        $bmp.SetPixel($x, $y, $color)
    }
}

# =============================================================================
# TEMPAD  - chunky bronze device, teal screen, amber aperture lens
# =============================================================================
function New-Tempad {
    $canvas = New-Canvas; $bmp = $canvas[0]
    # case body
    Fill-Rect $bmp 1 4 14 11 $C.CaseDark
    Fill-Rect $bmp 2 5 12 9 $C.CaseMid
    # top bezel + edge highlight
    Fill-Rect $bmp 1 4 14 1 $C.CaseLight
    Fill-Rect $bmp 1 4 1 11 $C.CaseLight
    Fill-Rect $bmp 14 4 1 11 $C.MetalDark
    Fill-Rect $bmp 1 14 14 1 $C.MetalDark
    # brass trim
    Fill-Rect $bmp 0 6 1 7 $C.Metal
    Fill-Rect $bmp 15 6 1 7 $C.Metal
    # screen
    Fill-Rect $bmp 3 6 10 6 $C.Screen
    Fill-Rect $bmp 3 6 10 1 $C.CaseLight
    # screen scan lines (teal data)
    Fill-Rect $bmp 4 7 6 1 $C.ScreenLit
    Fill-Rect $bmp 5 8 7 1 $C.ScreenLit
    Fill-Rect $bmp 4 10 4 1 $C.GreenDark
    # amber aperture lens at bottom centre
    Fill-Rect $bmp 6 12 4 2 $C.AmberDeep
    Set-Px $bmp 7 13 $C.Amber
    Set-Px $bmp 8 13 $C.Amber
    Set-Px $bmp 7 12 $C.AmberHot
    # side grips
    Set-Px $bmp 2 7 $C.MetalDark; Set-Px $bmp 13 7 $C.MetalDark
    Save-Canvas $bmp (Join-Path $itemDir 'tempad.png')
}

# =============================================================================
# MOBIUS MOBILE - dark slab phone with glowing cyan UI
# =============================================================================
function New-MobiusMobile {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 3 1 10 14 $C.Ink
    Fill-Rect $bmp 4 2 8 12 $C.SteelDark
    Fill-Rect $bmp 4 2 8 1 $C.SteelLite
    Fill-Rect $bmp 4 2 1 12 $C.SteelLite
    Fill-Rect $bmp 11 2 1 12 $C.SteelDark
    # display
    Fill-Rect $bmp 5 3 6 9 $C.Screen
    # UI bars
    Fill-Rect $bmp 6 4 4 1 $C.ScreenLit
    Fill-Rect $bmp 6 6 4 1 $C.ScreenLit
    Fill-Rect $bmp 6 8 2 1 $C.Amber
    Fill-Rect $bmp 6 10 4 1 $C.Green
    # earpiece slit
    Fill-Rect $bmp 6 1 4 1 $C.SteelLite
    Save-Canvas $bmp (Join-Path $itemDir 'mobius_mobile.png')
}

# =============================================================================
# CHRONO BATTERY - glowing green power cell
# =============================================================================
function New-ChronoBattery {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 5 2 6 2 $C.SteelLite
    Fill-Rect $bmp 4 4 8 10 $C.SteelDark
    Fill-Rect $bmp 4 4 1 10 $C.SteelLite
    Fill-Rect $bmp 11 4 1 10 $C.SteelDark
    Fill-Rect $bmp 5 5 6 8 $C.GreenDark
    Fill-Rect $bmp 6 6 4 6 $C.Green
    Fill-Rect $bmp 7 5 2 8 $C.ScreenLit
    Fill-Rect $bmp 3 6 1 6 $C.Metal
    Fill-Rect $bmp 12 6 1 6 $C.MetalDark
    Fill-Rect $bmp 4 14 8 1 $C.MetalDark
    Save-Canvas $bmp (Join-Path $itemDir 'chrono_battery.png')
}

# =============================================================================
# VARIANT SCANNER - handheld barcode reader
# =============================================================================
function New-VariantScanner {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 2 5 12 8 $C.SteelDark
    Fill-Rect $bmp 2 5 12 1 $C.SteelLite
    Fill-Rect $bmp 2 5 1 8 $C.SteelLite
    Fill-Rect $bmp 13 5 1 8 $C.Ink
    # handle
    Fill-Rect $bmp 4 12 5 3 $C.Ink
    Fill-Rect $bmp 4 12 5 1 $C.SteelDark
    # screen
    Fill-Rect $bmp 4 7 8 4 $C.Screen
    # barcode bars
    Fill-Rect $bmp 5 8 1 2 $C.AmberHot
    Fill-Rect $bmp 7 8 2 2 $C.AmberHot
    Fill-Rect $bmp 10 8 1 2 $C.AmberHot
    Fill-Rect $bmp 5 11 6 1 $C.AmberDeep
    Save-Canvas $bmp (Join-Path $itemDir 'variant_scanner.png')
}

# =============================================================================
# TIME DOOR - TVA portal frame front face (amber energy field)
# =============================================================================
function New-TimeDoor {
    $canvas = New-Canvas; $bmp = $canvas[0]
    # dark void centre
    Fill-Rect $bmp 0 0 16 16 $C.Void
    # swirling amber field
    Fill-Rect $bmp 2 2 12 12 $C.AmberDeep
    Fill-Rect $bmp 3 3 10 10 $C.Amber
    Fill-Rect $bmp 4 4 8 8 $C.AmberHot
    Fill-Rect $bmp 5 5 6 6 $C.Amber
    # vertical data streaks
    Fill-Rect $bmp 5 3 1 4 $C.AmberHot
    Fill-Rect $bmp 9 9 1 4 $C.AmberHot
    Fill-Rect $bmp 7 4 1 2 $C.Paper
    # brass frame border
    Fill-Rect $bmp 0 0 16 1 $C.Metal
    Fill-Rect $bmp 0 15 16 1 $C.MetalDark
    Fill-Rect $bmp 0 0 1 16 $C.Metal
    Fill-Rect $bmp 15 0 1 16 $C.MetalDark
    Fill-Rect $bmp 1 1 1 1 $C.Void
    Fill-Rect $bmp 14 1 1 1 $C.Void
    Fill-Rect $bmp 1 14 1 1 $C.Void
    Fill-Rect $bmp 14 14 1 1 $C.Void
    Save-Canvas $bmp (Join-Path $blockDir 'time_door.png')
}

# =============================================================================
# ARC REACTOR - cobalt reactor core in a brass housing (front)
# =============================================================================
function New-ArcReactor {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 0 0 16 16 $C.SteelDark
    Fill-Rect $bmp 0 0 16 1 $C.SteelLite
    Fill-Rect $bmp 0 0 1 16 $C.SteelLite
    Fill-Rect $bmp 15 0 1 16 $C.Ink
    Fill-Rect $bmp 0 15 16 1 $C.Ink
    # housing ring
    Fill-Rect $bmp 3 3 10 10 $C.MetalDark
    Fill-Rect $bmp 4 4 8 8 $C.Metal
    # glowing core
    Fill-Rect $bmp 5 5 6 6 $C.Screen
    Fill-Rect $bmp 6 6 4 4 $C.ScreenLit
    Set-Px $bmp 7 7 $C.AmberHot
    Set-Px $bmp 8 8 $C.AmberHot
    Set-Px $bmp 6 9 $C.Amber
    # rivets
    Set-Px $bmp 3 3 $C.Metal; Set-Px $bmp 12 3 $C.Metal
    Set-Px $bmp 3 12 $C.Metal; Set-Px $bmp 12 12 $C.Metal
    Save-Canvas $bmp (Join-Path $blockDir 'arc_reactor.png')
}

# =============================================================================
# CHRONOVIUM BLOCK - engraved blue-steel alloy block (all faces)
# =============================================================================
function New-ChronoviumBlock {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 0 0 16 16 $C.SteelDark
    Fill-Rect $bmp 1 1 14 14 $C.Steel
    Fill-Rect $bmp 1 1 14 1 $C.SteelLite
    Fill-Rect $bmp 1 1 1 14 $C.SteelLite
    Fill-Rect $bmp 14 1 1 14 $C.Ink
    Fill-Rect $bmp 1 14 14 1 $C.Ink
    # engraved circuit groove
    Fill-Rect $bmp 3 3 10 1 $C.SteelDark
    Fill-Rect $bmp 3 12 10 1 $C.SteelDark
    Fill-Rect $bmp 3 4 1 8 $C.SteelDark
    Fill-Rect $bmp 12 4 1 8 $C.SteelDark
    Fill-Rect $bmp 7 6 2 4 $C.ScreenLit
    Set-Px $bmp 6 5 $C.Screen
    Set-Px $bmp 9 10 $C.Screen
    Save-Canvas $bmp (Join-Path $blockDir 'chronovium.png')
}

# =============================================================================
# TIME DOOR (open) - fully energised, hot amber field
# =============================================================================
function New-TimeDoorOpen {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 0 0 16 16 $C.AmberDeep
    Fill-Rect $bmp 1 1 14 14 $C.Amber
    Fill-Rect $bmp 2 2 12 12 $C.AmberHot
    Fill-Rect $bmp 3 3 10 10 $C.Amber
    Fill-Rect $bmp 4 4 8 8 $C.AmberHot
    # white-hot core
    Fill-Rect $bmp 6 5 4 6 $C.Amber
    Fill-Rect $bmp 7 6 2 4 $C.AmberHot
    # energy streaks
    Fill-Rect $bmp 4 2 1 5 $C.AmberHot
    Fill-Rect $bmp 11 9 1 5 $C.AmberHot
    Fill-Rect $bmp 8 3 1 3 $C.Paper
    Fill-Rect $bmp 2 8 3 1 $C.Paper
    # brass frame
    Fill-Rect $bmp 0 0 16 1 $C.AmberHot
    Fill-Rect $bmp 0 15 16 1 $C.MetalDark
    Fill-Rect $bmp 0 0 1 16 $C.Metal
    Fill-Rect $bmp 15 0 1 16 $C.MetalDark
    Save-Canvas $bmp (Join-Path $blockDir 'time_door_open.png')
}

# =============================================================================
# CHRONOVIUM INGOT - small steel bar with an amethyst sheen
# =============================================================================
function New-ChronoviumIngot {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 3 4 10 8 $C.SteelDark
    Fill-Rect $bmp 3 4 10 1 $C.SteelLite
    Fill-Rect $bmp 3 4 1 8 $C.SteelLite
    Fill-Rect $bmp 12 4 1 8 $C.Ink
    Fill-Rect $bmp 3 11 10 1 $C.Ink
    Fill-Rect $bmp 4 5 8 6 $C.Steel
    Fill-Rect $bmp 5 6 6 4 $C.Screen
    Fill-Rect $bmp 6 7 4 2 $C.ScreenLit
    Set-Px $bmp 5 6 $C.SteelLite
    Set-Px $bmp 10 9 $C.SteelLite
    Save-Canvas $bmp (Join-Path $itemDir 'chronovium_ingot.png')
}

# =============================================================================
# COMPUTER - a wall terminal: amber data screen in a dark steel bezel
# =============================================================================
function New-Computer {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 0 0 16 16 $C.SteelDark
    Fill-Rect $bmp 0 0 16 1 $C.Steel
    Fill-Rect $bmp 0 15 16 1 $C.Ink
    Fill-Rect $bmp 0 0 1 16 $C.Steel
    Fill-Rect $bmp 15 0 1 16 $C.Ink
    # recessed screen
    Fill-Rect $bmp 2 2 12 12 $C.Ink
    Fill-Rect $bmp 3 3 10 10 $C.AmberDeep
    Fill-Rect $bmp 4 4 8 8 $C.Amber
    # scrolling data rows
    Fill-Rect $bmp 4 5 6 1 $C.AmberHot
    Fill-Rect $bmp 5 7 7 1 $C.AmberHot
    Fill-Rect $bmp 4 9 4 1 $C.AmberHot
    Fill-Rect $bmp 6 11 6 1 $C.AmberHot
    # bezel screws
    Set-Px $bmp 1 1 $C.SteelLite
    Set-Px $bmp 14 1 $C.SteelLite
    Set-Px $bmp 1 14 $C.SteelLite
    Set-Px $bmp 14 14 $C.SteelLite
    Save-Canvas $bmp (Join-Path $blockDir 'computer.png')
}

# =============================================================================
# TERMINAL - a floor-to-ceiling bank of amber screens
# =============================================================================
function New-Terminal {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 0 0 16 16 $C.Ink
    Fill-Rect $bmp 0 0 16 1 $C.SteelDark
    Fill-Rect $bmp 0 15 16 1 $C.SteelDark
    # three stacked screens
    foreach ($top in 1, 6, 11) {
        Fill-Rect $bmp 1 $top 14 4 $C.SteelDark
        Fill-Rect $bmp 2 ($top + 1) 12 2 $C.AmberDeep
        Fill-Rect $bmp 3 ($top + 1) 7 1 $C.Amber
        Fill-Rect $bmp 3 ($top + 2) 9 1 $C.AmberHot
    }
    Fill-Rect $bmp 7 5 2 6 $C.Void
    Fill-Rect $bmp 7 5 1 6 $C.AmberDeep
    Save-Canvas $bmp (Join-Path $blockDir 'terminal.png')
}

# =============================================================================
# CONSOLE - a desk with a keyboard shelf and a small readout
# =============================================================================
function New-Console {
    $canvas = New-Canvas; $bmp = $canvas[0]
    Fill-Rect $bmp 0 0 16 16 $C.CaseDark
    Fill-Rect $bmp 0 0 16 2 $C.CaseMid
    Fill-Rect $bmp 0 0 16 1 $C.CaseLight
    # desktop
    Fill-Rect $bmp 1 3 14 13 $C.CaseMid
    Fill-Rect $bmp 2 4 12 3 $C.Void
    Fill-Rect $bmp 3 5 10 1 $C.Amber
    Fill-Rect $bmp 4 6 8 1 $C.AmberHot
    # keyboard shelf
    Fill-Rect $bmp 2 9 12 5 $C.CaseDark
    for ($k = 0; $k -lt 5; $k++) {
        Fill-Rect $bmp (3 + $k * 2) 10 1 1 $C.AmberDeep
        Fill-Rect $bmp (3 + $k * 2) 12 1 1 $C.AmberDeep
    }
    Save-Canvas $bmp (Join-Path $blockDir 'console.png')
}

# =============================================================================
# TIME DOOR FIELD - eight frames of a swirling amber energy field
# =============================================================================
function New-TimedoorField {
    # Each frame is the same field rotated a little further and pulled a little
    # towards the middle, so the doorway ripples rather than merely flickering.
    for ($frame = 0; $frame -lt 8; $frame++) {
        $canvas = New-Canvas; $bmp = $canvas[0]
        $t = $frame / 8.0 * 2 * [Math]::PI

        for ($y = 0; $y -lt 16; $y++) {
            for ($x = 0; $x -lt 16; $x++) {
                $dx = $x - 7.5
                $dy = $y - 7.5
                $r = [Math]::Sqrt($dx * $dx + $dy * $dy)
                $a = [Math]::Atan2($dy, $dx)

                # Three-armed swirl, turning with the frame.
                $v = [Math]::Sin($a * 3.0 + $r * 1.35 + $t)
                $v = ($v + 1.0) / 2.0
                # A second, slower ripple so the arms have some depth.
                $w = [Math]::Sin($a * 2.0 - $r * 0.9 - $t * 1.7)
                $v = [Math]::Min(1.0, [Math]::Max(0.0, $v * 0.72 + ($w + 1.0) / 2.0 * 0.28))

                # The middle of the door is the brightest part.
                $core = [Math]::Max(0.0, 1.0 - $r / 8.5)
                $v = [Math]::Min(1.0, $v * 0.75 + $core * 0.45)

                if ($v -lt 0.30) {
                    $color = $C.AmberDeep
                } elseif ($v -lt 0.58) {
                    $color = $C.Amber
                } elseif ($v -lt 0.82) {
                    $color = $C.AmberHot
                } else {
                    $color = $C.Paper
                }
                # Darker towards the frame, so the edge of the door reads as depth.
                if ($r -gt 6.4) {
                    $shade = [Math]::Min(0.55, ($r - 6.4) / 9.0)
                    $color = [System.Drawing.Color]::FromArgb(
                        $color.A,
                        [int]($color.R * (1.0 - $shade)),
                        [int]($color.G * (1.0 - $shade)),
                        [int]($color.B * (1.0 - $shade)))
                }
                Set-Px $bmp $x $y $color
            }
        }
        Save-Canvas $bmp (Join-Path $blockDir "timedoor_field_$frame.png")
    }
}

# =============================================================================
# CHRONOVIUM ORE - amber crystal veins in stone, and in deepslate
# =============================================================================
function New-ChronoviumOre {
    # Two passes: the stone body, then the veins on top.
    $passes = @(
        @{ Name = 'chronovium_ore';      Stone = $C.Stone;      StoneDark = $C.StoneDark }
        @{ Name = 'deepslate_chronovium_ore'; Stone = $C.Deepslate; StoneDark = $C.DeepslateDark }
    )

    foreach ($p in $passes) {
        $canvas = New-Canvas; $bmp = $canvas[0]
        Fill-Rect $bmp 0 0 16 16 $p.Stone

        # Speckle the stone so it is not a flat colour.
        for ($i = 0; $i -lt 26; $i++) {
            $x = ($i * 7) % 16
            $y = ($i * 11) % 16
            Set-Px $bmp $x $y $p.StoneDark
        }

        # Four veins of amber crystal, each with a dark core and a hot centre.
        $veins = @(
            @(@(3, 3), @(4, 4), @(5, 4), @(4, 5)),
            @(@(9, 2), @(10, 3), @(11, 3), @(10, 4)),
            @(@(6, 9), @(7, 10), @(8, 10), @(7, 11)),
            @(@(12, 8), @(13, 9), @(12, 10))
        )
        foreach ($v in $veins) {
            foreach ($pt in $v) {
                Set-Px $bmp $pt[0] $pt[1] $C.AmberDeep
            }
            # The bright middle of the vein.
            Set-Px $bmp $v[1][0] $v[1][1] $C.Amber
            Set-Px $bmp $v[2][0] $v[2][1] $C.AmberHot
        }

        Save-Canvas $bmp (Join-Path $blockDir "$($p.Name).png")
    }
}

# =============================================================================
# TVA PICTURES - six framed diagrams for the Authority's walls
# =============================================================================
function New-TvaPictures {
    $paper = [System.Drawing.Color]::FromArgb(255, 214, 198, 172)
    $paperDark = [System.Drawing.Color]::FromArgb(255, 186, 168, 140)
    $ink = [System.Drawing.Color]::FromArgb(255, 58, 40, 24)
    $red = [System.Drawing.Color]::FromArgb(255, 176, 48, 32)
    $frame = [System.Drawing.Color]::FromArgb(255, 74, 48, 22)
    $frameLit = [System.Drawing.Color]::FromArgb(255, 132, 92, 44)

    # 1: the Authority's mark, a V cut out of the page
    $b = New-Canvas; $m = $b[0]
    Fill-Rect $m 0 0 16 16 $paper
    Fill-Rect $m 0 0 16 1 $frame
    Fill-Rect $m 0 15 16 1 $frame
    Fill-Rect $m 0 0 1 16 $frame
    Fill-Rect $m 15 0 1 16 $frame
    for ($y = 3; $y -le 12; $y++) {
        $spread = [int](($y - 3) / 2.2)
        for ($dx = -$spread; $dx -le $spread; $dx++) {
            Fill-Rect $m (7 + $dx) $y 10 1 $red
        }
    }
    Fill-Rect $m 3 2 10 1 $ink
    Save-Canvas $m (Join-Path $blockDir 'tva_picture_0.png')

    # 2: a floor plan of the Vault, atrium in the middle
    $b = New-Canvas; $m = $b[0]
    Fill-Rect $m 0 0 16 16 $paper
    Fill-Rect $m 0 0 16 1 $frame
    Fill-Rect $m 0 15 16 1 $frame
    Fill-Rect $m 2 2 12 12 $ink
    Fill-Rect $m 3 3 10 10 $paper
    Fill-Rect $m 6 6 4 4 $red
    for ($i = 3; $i -le 5; $i++) { Set-Px $m $i 3 $red; Set-Px $m 3 $i $red }
    for ($i = 10; $i -le 12; $i++) { Set-Px $m $i 12 $red; Set-Px $m 12 $i $red }
    Fill-Rect $m 6 14 4 1 $red
    Save-Canvas $m (Join-Path $blockDir 'tva_picture_1.png')

    # 3: the TemPad, seen from above
    $b = New-Canvas; $m = $b[0]
    Fill-Rect $m 0 0 16 16 $paper
    Fill-Rect $m 0 0 16 1 $frame
    Fill-Rect $m 0 15 16 1 $frame
    Fill-Rect $m 3 3 10 10 $frameLit
    Fill-Rect $m 4 4 8 8 $paperDark
    Fill-Rect $m 6 6 4 4 $red
    Fill-Rect $m 7 5 2 1 $ink
    Fill-Rect $m 5 10 1 1 $ink
    Fill-Rect $m 10 10 1 1 $ink
    Fill-Rect $m 7 10 2 1 $ink
    Save-Canvas $m (Join-Path $blockDir 'tva_picture_2.png')

    # 4: the reset lever, in section
    $b = New-Canvas; $m = $b[0]
    Fill-Rect $m 0 0 16 16 $paper
    Fill-Rect $m 0 0 16 1 $frame
    Fill-Rect $m 0 15 16 1 $frame
    Fill-Rect $m 3 3 10 1 $ink
    for ($y = 4; $y -le 11; $y++) { Set-Px $m 7 $y $ink; Set-Px $m 8 $y $ink }
    Fill-Rect $m 6 12 4 2 $frameLit
    Fill-Rect $m 4 5 1 1 $red; Fill-Rect $m 11 5 1 1 $red
    Fill-Rect $m 4 10 1 1 $red; Fill-Rect $m 11 10 1 1 $red
    Fill-Rect $m 7 1 2 1 $red
    Save-Canvas $m (Join-Path $blockDir 'tva_picture_3.png')

    # 5: a timeline, with the Sacred Hour marked
    $b = New-Canvas; $m = $b[0]
    Fill-Rect $m 0 0 16 16 $paper
    Fill-Rect $m 0 0 16 1 $frame
    Fill-Rect $m 0 15 16 1 $frame
    Fill-Rect $m 1 8 14 1 $ink
    for ($i = 1; $i -le 14; $i += 2) { Fill-Rect $m $i 7 1 3 $ink }
    Fill-Rect $m 7 5 2 7 $red
    Fill-Rect $m 6 4 4 1 $red
    Fill-Rect $m 2 3 3 1 $ink
    Fill-Rect $m 11 11 3 1 $ink
    Save-Canvas $m (Join-Path $blockDir 'tva_picture_4.png')

    # 6: the motto, set out like a notice
    $b = New-Canvas; $m = $b[0]
    Fill-Rect $m 0 0 16 16 $paper
    Fill-Rect $m 0 0 16 1 $frame
    Fill-Rect $m 0 15 16 1 $frame
    Fill-Rect $m 0 0 1 16 $frame
    Fill-Rect $m 15 0 1 16 $frame
    Fill-Rect $m 2 4 12 1 $red
    Fill-Rect $m 2 7 9 1 $ink
    Fill-Rect $m 2 9 11 1 $ink
    Fill-Rect $m 2 11 7 1 $ink
    Fill-Rect $m 3 13 10 1 $ink
    Save-Canvas $m (Join-Path $blockDir 'tva_picture_5.png')
}

# =============================================================================
# TVA FIELD MANUAL - a bound handbook, Authority orange
# =============================================================================
function New-TvaManual {
    $canvas = New-Canvas; $bmp = $canvas[0]
    $cover = [System.Drawing.Color]::FromArgb(255, 196, 104, 24)
    $coverLit = [System.Drawing.Color]::FromArgb(255, 228, 140, 40)
    $coverDark = [System.Drawing.Color]::FromArgb(255, 140, 64, 16)

    # The cover itself, orange all the way over.
    Fill-Rect $bmp 0 0 16 16 $cover
    Fill-Rect $bmp 0 0 16 1 $coverLit
    Fill-Rect $bmp 0 0 1 16 $coverLit
    Fill-Rect $bmp 0 15 16 1 $coverDark
    Fill-Rect $bmp 15 0 1 16 $coverDark

    # Page block, seen edge-on down the right side.
    Fill-Rect $bmp 13 1 3 14 $C.Paper
    Fill-Rect $bmp 13 1 1 14 $C.PaperDark
    Fill-Rect $bmp 15 1 1 14 $C.PaperDark

    # Brass corners.
    Fill-Rect $bmp 1 1 5 1 $C.Metal
    Fill-Rect $bmp 1 1 1 5 $C.Metal
    Fill-Rect $bmp 1 14 5 1 $C.MetalDark
    Fill-Rect $bmp 1 10 1 5 $C.MetalDark

    # The Authority's V, stamped into the middle.
    for ($y = 4; $y -le 11; $y++) {
        $spread = [int](($y - 4) / 2.0)
        for ($dx = -$spread; $dx -le $spread; $dx++) {
            Fill-Rect $bmp (7 + $dx) $y 11 1 $coverDark
        }
    }
    # A rule above and below, like a printed title.
    Fill-Rect $bmp 3 3 7 1 $coverLit
    Fill-Rect $bmp 3 12 7 1 $coverLit

    Save-Canvas $bmp (Join-Path $itemDir 'tva_manual.png')
}

Write-Host 'Generating TVA Tech textures...'
New-Tempad
New-MobiusMobile
New-ChronoBattery
New-VariantScanner
New-TimeDoor
New-TimeDoorOpen
New-ArcReactor
New-ChronoviumBlock
New-ChronoviumOre
New-ChronoviumIngot
New-Computer
New-Terminal
New-Console
New-TimedoorField
New-TvaPictures
New-TvaManual
Write-Host 'Done.'
