package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import com.tvatech.TvaConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Watches the things the block timeline cannot see: dropped items and the
 * contents of storage blocks.
 *
 * <p>Items are followed by UUID, so an item that was picked up on day 7 can be
 * put back exactly where it lay on day 3. Containers are followed by position.</p>
 */
public final class TimelineItems {

    private TimelineItems() {}

    /** Live dropped items, by UUID, so they can be found without a world scan. */
    private static final Map<UUID, ItemEntity> LIVE = new HashMap<>();

    private static boolean armed;

    // ------------------------------------------------------------------
    // Watching
    // ------------------------------------------------------------------

    /** Called when an entity enters a level. */
    public static void onJoin(ServerLevel level, Entity entity) {
        if (!TvaConfig.timelineBlocks || armed || !(entity instanceof ItemEntity item)) {
            return;
        }
        UUID id = item.getUUID();
        LIVE.put(id, item);
        long hour = WorldTime.hourIndex(level);
        objects(level).recordItem(id.toString(), hour, true,
                Nbt.saveStack(level.registryAccess(), item.getItem()), positionOf(item));
    }

    /**
     * Called when an entity leaves a level.
     *
     * <p>A chunk unloading also fires this, and that must not count as the item
     * disappearing - only {@code isRemoved()} means it was really gone.</p>
     */
    public static void onLeave(ServerLevel level, Entity entity) {
        if (!TvaConfig.timelineBlocks || armed || !(entity instanceof ItemEntity item)) {
            return;
        }
        UUID id = item.getUUID();
        LIVE.remove(id);
        if (!entity.isRemoved()) {
            // Chunk unload: the item is still on its way back in.
            return;
        }
        objects(level).recordItem(id.toString(), WorldTime.hourIndex(level), false, "", "0");
    }

    /** Called when the player opens a storage block: start following it. */
    public static void onContainerTouched(ServerLevel level, BlockPos pos) {
        if (!TvaConfig.timelineBlocks || armed) {
            return;
        }
        if (level.getBlockEntity(pos) instanceof net.minecraft.world.Container) {
            objects(level).recordContainer(level, pos, WorldTime.hourIndex(level));
        }
    }

    /**
     * Called when a player closes any container screen.
     *
     * <p>The close event does not name the block, so every container the player
     * is looking near is re-filed. There are only ever a handful of those.</p>
     */
    public static void onAnyContainerChanged(ServerPlayer player) {
        if (!TvaConfig.timelineBlocks || armed) {
            return;
        }
        ServerLevel level = player.serverLevel();
        TimelineObjects objects = objects(level);
        long hour = WorldTime.hourIndex(level);
        armed = true;
        try {
            for (BlockPos pos : candidatesNear(player)) {
                if (level.getBlockEntity(pos) instanceof net.minecraft.world.Container) {
                    objects.recordContainer(level, pos, hour);
                }
            }
        } finally {
            armed = false;
        }
    }

    /** The blocks around the player that could be the container they just used. */
    private static List<BlockPos> candidatesNear(ServerPlayer player) {
        List<BlockPos> found = new ArrayList<>();
        BlockPos centre = player.blockPosition();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    found.add(centre.offset(dx, dy, dz));
                }
            }
        }
        return found;
    }

    /**
     * The catch-up pass: notices contents that changed while nobody was
     * recording, and items that vanished without an event.
     */
    public static void sweep(ServerLevel level) {
        if (!TvaConfig.timelineBlocks || armed) {
            return;
        }
        TimelineObjects objects = objects(level);
        long hour = WorldTime.hourIndex(level);
        armed = true;
        try {
            for (String uuid : objects.itemUuids()) {
                ItemEntity live = liveItem(level, uuid);
                if (live == null) {
                    continue;
                }
                // Keep the position and stack fresh so a later trip back can
                // put the item exactly where it was.
                objects.recordItem(uuid, hour, true,
                        Nbt.saveStack(level.registryAccess(), live.getItem()), positionOf(live));
            }
            objects.sweepContainers(level, hour);
        } finally {
            armed = false;
        }
    }

    private static ItemEntity liveItem(ServerLevel level, String uuid) {
        try {
            ItemEntity cached = LIVE.get(UUID.fromString(uuid));
            if (cached != null && !cached.isRemoved()) {
                return cached;
            }
        } catch (IllegalArgumentException ignored) {
            // Bad id in an old save; nothing to follow.
        }
        return null;
    }

    private static String positionOf(ItemEntity item) {
        return (long) item.getX() + "," + (long) item.getY() + "," + (long) item.getZ();
    }

    // ------------------------------------------------------------------
    // Day switches
    // ------------------------------------------------------------------

    /**
     * Rebuilds dropped items and storage for a day.
     *
     * @return a short summary for the jump log
     */
    public static String switchTo(ServerLevel level, long hour) {
        TimelineObjects objects = objects(level);
        armed = true;
        try {
            int chests = objects.applyContainers(level, hour);
            int items = applyItems(level, objects, hour);
            return chests + " containers and " + items + " dropped items";
        } finally {
            armed = false;
        }
    }

    private static int applyItems(ServerLevel level, TimelineObjects objects, long hour) {
        int restored = 0;
        for (String uuid : objects.itemUuids()) {
            ItemEntity live = liveItem(level, uuid);
            boolean shouldExist = objects.itemAlive(uuid, hour);
            if (shouldExist) {
                if (live != null) {
                    continue;
                }
                String[] state = objects.itemState(uuid, hour);
                if (state == null) {
                    continue;
                }
                ItemStack stack = Nbt.loadStack(level.registryAccess(), state[1]);
                if (stack.isEmpty()) {
                    continue;
                }
                double[] where = parsePosition(state[0]);
                ItemEntity item = new ItemEntity(level, where[0], where[1], where[2], stack);
                item.setUUID(UUID.fromString(uuid));
                // It went back to the timeline with the same identity, so give
                // the player a moment before it can be picked up again.
                item.setPickUpDelay(20);
                if (level.addWithUUID(item)) {
                    LIVE.put(UUID.fromString(uuid), item);
                    restored++;
                }
            } else if (live != null) {
                // Not there yet on this day: take it away again.
                live.discard();
                restored++;
            }
        }
        return restored;
    }

    private static double[] parsePosition(String encoded) {
        try {
            String[] parts = encoded.split(",");
            return new double[]{
                    Double.parseDouble(parts[0]),
                    Double.parseDouble(parts[1]),
                    Double.parseDouble(parts[2])};
        } catch (RuntimeException e) {
            return new double[]{0, 64, 0};
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    public static TimelineObjects objects(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(TimelineObjects.TYPE, TimelineObjects.STORAGE_KEY);
    }

    public static void setArmed(boolean value) {
        armed = value;
    }

    public static void clearLive() {
        LIVE.clear();
    }
}