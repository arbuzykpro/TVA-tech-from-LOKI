package com.tvatech.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.level.Level;

/**
 * The Authority's field manual.
 *
 * <p>This is a genuine written book underneath - same item class, same open
 * screen, same page turning - so none of that has to be reimplemented. All it
 * adds is the pages themselves, which are written onto the stack the first time
 * the book is opened. That way a fresh manual costs nothing to carry, and the
 * moment you read it, it is a book.</p>
 */
public class TvaManualItem extends WrittenBookItem {

    public TvaManualItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        // A copy somebody has already written in keeps its own pages.
        if (!held.has(DataComponents.WRITTEN_BOOK_CONTENT)) {
            held.set(DataComponents.WRITTEN_BOOK_CONTENT, TvaManual.content());
        }
        // Vanilla opens the book screen from here.
        return super.use(level, player, hand);
    }
}
