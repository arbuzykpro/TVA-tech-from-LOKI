package com.tvatech;

import com.mojang.logging.LogUtils;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import com.tvatech.block.ArcReactorBlock;
import com.tvatech.block.ChronoviumBlock;
import com.tvatech.block.TimeDoorBlock;
import com.tvatech.item.TvaGadgetItem;
import com.tvatech.item.TvaTooltips;

import java.util.function.Supplier;

/**
 * Registry holders for every block and item in the mod.
 *
 * <p>Kept in one place so the creative tab, recipes and the event handlers all
 * talk about the exact same objects.</p>
 */
public final class ModContent {

    private ModContent() {}

    // ---------------------------------------------------------------------
    // Deferred registers
    // ---------------------------------------------------------------------
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, TVATech.MODID);

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, TVATech.MODID);

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(net.minecraft.core.registries.Registries.CREATIVE_MODE_TAB, TVATech.MODID);

    // ---------------------------------------------------------------------
    // Blocks
    // ---------------------------------------------------------------------

    /** The glowing portal frame from the show. Traversal requires a TemPad. */
    public static final RegistryObject<Block> TIME_DOOR = BLOCKS.register("time_door",
            () -> new TimeDoorBlock(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("time_door"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(3.0F, 6.0F)
                    .sound(SoundType.COPPER)
                    .lightLevel(state -> state.getValue(TimeDoorBlock.OPEN) ? 15 : 4)
                    .noOcclusion()));

    /** Power source: lights the area and feeds the Mobius Mobile's abilities. */
    public static final RegistryObject<Block> ARC_REACTOR = BLOCKS.register("arc_reactor",
            () -> new ArcReactorBlock(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("arc_reactor"))
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(4.0F, 8.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> 14)));

    /** Decorative chronovium alloy used to build TVA tech. */
    public static final RegistryObject<Block> CHRONOVIUM_BLOCK = BLOCKS.register("chronovium_block",
            () -> new ChronoviumBlock(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("chronovium_block"))
                    .mapColor(MapColor.METAL)
                    .strength(5.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    // --- TVA office furniture ---------------------------------------------

    /** A wall-mounted terminal: the amber scrolling screens of the Vault. */
    public static final RegistryObject<Block> COMPUTER = BLOCKS.register("computer",
            () -> new net.minecraft.world.level.block.RotatedPillarBlock(
                    BlockBehaviour.Properties.of()
                            .setId(BLOCKS.key("computer"))
                            .mapColor(MapColor.COLOR_ORANGE)
                            .strength(3.0F, 6.0F)
                            .sound(SoundType.WOOD)
                            .lightLevel(state -> 7)
                            .noOcclusion()));

    /** A full-height terminal bank, floor to ceiling. */
    public static final RegistryObject<Block> TERMINAL = BLOCKS.register("terminal",
            () -> new net.minecraft.world.level.block.RotatedPillarBlock(
                    BlockBehaviour.Properties.of()
                            .setId(BLOCKS.key("terminal"))
                            .mapColor(MapColor.COLOR_ORANGE)
                            .strength(3.5F, 6.0F)
                            .sound(SoundType.WOOD)
                            .lightLevel(state -> 11)
                            .noOcclusion()));

    /** A half-height console desk. */
    public static final RegistryObject<Block> CONSOLE = BLOCKS.register("console",
            () -> new net.minecraft.world.level.block.SlabBlock(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("console"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(2.5F, 5.0F)
                    .sound(SoundType.WOOD)
                    .lightLevel(state -> 5)));

    /**
     * The glowing surface of an open time door.
     *
     * <p>Deliberately has no item: a doorway is something the TemPad builds, not
     * something you carry around and place.</p>
     */
    public static final RegistryObject<Block> TIMEDOOR_FIELD = BLOCKS.register("timedoor_field",
            () -> new com.tvatech.block.TimedoorFieldBlock(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("timedoor_field"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .noCollision()
                    .noOcclusion()
                    .lightLevel(state -> 11)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.GLASS)));

    /**
     * Chronovium in the stone.
     *
     * <p>Mining one drops the ingot directly, the way nether ore drops a
     * nugget rather than making you smelt it first.</p>
     */
    public static final RegistryObject<Block> CHRONOVIUM_ORE = BLOCKS.register("chronovium_ore",
            () -> new Block(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("chronovium_ore"))
                    .mapColor(MapColor.STONE)
                    .strength(3.0F, 3.0F)
                    .sound(SoundType.STONE)
                    .requiresCorrectToolForDrops()));

    /** The same ore, underground, where deepslate is the rock. */
    public static final RegistryObject<Block> DEEPSLATE_CHRONOVIUM_ORE =
            BLOCKS.register("deepslate_chronovium_ore",
                    () -> new Block(BlockBehaviour.Properties.of()
                            .setId(BLOCKS.key("deepslate_chronovium_ore"))
                            .mapColor(MapColor.DEEPSLATE)
                            .strength(4.5F, 3.0F)
                            .sound(SoundType.DEEPSLATE)
                            .requiresCorrectToolForDrops()));

    /**
     * Framed pictures on the Authority's walls.
     *
     * <p>No item: these are part of the building.</p>
     */
    public static final RegistryObject<Block> TVA_PICTURE = BLOCKS.register("tva_picture",
            () -> new com.tvatech.block.TvaPictureBlock(BlockBehaviour.Properties.of()
                    .setId(BLOCKS.key("tva_picture"))
                    .mapColor(MapColor.COLOR_ORANGE)
                    .strength(2.0F, 5.0F)
                    .sound(SoundType.WOOD)
                    .lightLevel(state -> 7)));

    // ---------------------------------------------------------------------
    // Items
    // ---------------------------------------------------------------------

    /** The Temporal Access Device. Opens doors through time. */
    public static final RegistryObject<Item> TEMPAD = ITEMS.register("tempad",
            () -> new TvaGadgetItem(new Item.Properties()
                    .setId(ITEMS.key("tempad"))
                    .stacksTo(1)
                    .rarity(Rarity.RARE), TvaTooltips.TEMPAD));

    /** Mobius' sliding mobile: variant scanner, timeline log, chrono abilities. */
    public static final RegistryObject<Item> MOBIUS_MOBILE = ITEMS.register("mobius_mobile",
            () -> new TvaGadgetItem(new Item.Properties()
                    .setId(ITEMS.key("mobius_mobile"))
                    .stacksTo(1)
                    .rarity(Rarity.RARE), TvaTooltips.MOBILE));

    /** Handheld barcode reader that tags living things with a variant ID. */
    public static final RegistryObject<Item> VARIANT_SCANNER = ITEMS.register("variant_scanner",
            () -> new TvaGadgetItem(new Item.Properties()
                    .setId(ITEMS.key("variant_scanner"))
                    .stacksTo(1), TvaTooltips.SCANNER));

    /** A collar other timelines mind: clamps on a mob or a fellow agent. */
    public static final RegistryObject<Item> TIME_COLLAR = ITEMS.register("time_collar",
            () -> new com.tvatech.item.TimeCollarItem(new Item.Properties()
                    .setId(ITEMS.key("time_collar"))
                    .stacksTo(16)));

    /** Orders a collared creature's last five seconds rolled back. */
    public static final RegistryObject<Item> TIME_COLLAR_REMOTE =
            ITEMS.register("time_collar_remote",
                    () -> new com.tvatech.item.TimeCollarRemoteItem(new Item.Properties()
                            .setId(ITEMS.key("time_collar_remote"))
                            .stacksTo(1)
                            .rarity(Rarity.RARE)));

    /** Spendable charge cell used to power the TemPad. */
    public static final RegistryObject<Item> CHRONO_BATTERY = ITEMS.register("chrono_battery",
            () -> new TvaGadgetItem(new Item.Properties()
                    .setId(ITEMS.key("chrono_battery")), TvaTooltips.BATTERY));

    /** Raw chronovium ore chunks, smelted into ingots. */
    public static final RegistryObject<Item> RAW_CHRONOVIUM = ITEMS.register("raw_chronovium",
            () -> new Item(new Item.Properties()
                    .setId(ITEMS.key("raw_chronovium"))));

    /** The alloy everything TVA is built from. */
    public static final RegistryObject<Item> CHRONOVIUM_INGOT = ITEMS.register("chronovium_ingot",
            () -> new Item(new Item.Properties()
                    .setId(ITEMS.key("chronovium_ingot"))));

    /**
     * The Authority's own field manual.
     *
     * <p>A plain item. The pages are applied the moment it is right-clicked, so
     * carrying it around does not mean carrying thirty pages of lore in the
     * item's data.</p>
     */
    public static final RegistryObject<Item> TVA_MANUAL = ITEMS.register("tva_manual",
            () -> new com.tvatech.item.TvaManualItem(new Item.Properties()
                    .setId(ITEMS.key("tva_manual"))
                    .stacksTo(1)
                    .rarity(Rarity.UNCOMMON)));

    // ---------------------------------------------------------------------
    // Block items
    // ---------------------------------------------------------------------
    public static final RegistryObject<Item> TIME_DOOR_ITEM = ITEMS.register("time_door",
            () -> new BlockItem(TIME_DOOR.get(), new Item.Properties().setId(ITEMS.key("time_door")).stacksTo(16)));

    public static final RegistryObject<Item> ARC_REACTOR_ITEM = ITEMS.register("arc_reactor",
            () -> new BlockItem(ARC_REACTOR.get(), new Item.Properties().setId(ITEMS.key("arc_reactor")).stacksTo(16)));

    public static final RegistryObject<Item> CHRONOVIUM_BLOCK_ITEM = ITEMS.register("chronovium_block",
            () -> new BlockItem(CHRONOVIUM_BLOCK.get(), new Item.Properties().setId(ITEMS.key("chronovium_block")).stacksTo(64)));

    public static final RegistryObject<Item> COMPUTER_ITEM = ITEMS.register("computer",
            () -> new BlockItem(COMPUTER.get(), new Item.Properties().setId(ITEMS.key("computer")).stacksTo(64)));

    public static final RegistryObject<Item> TERMINAL_ITEM = ITEMS.register("terminal",
            () -> new BlockItem(TERMINAL.get(), new Item.Properties().setId(ITEMS.key("terminal")).stacksTo(64)));

    public static final RegistryObject<Item> CHRONOVIUM_ORE_ITEM = ITEMS.register("chronovium_ore",
            () -> new BlockItem(CHRONOVIUM_ORE.get(),
                    new Item.Properties().setId(ITEMS.key("chronovium_ore"))));

    public static final RegistryObject<Item> DEEPSLATE_CHRONOVIUM_ORE_ITEM =
            ITEMS.register("deepslate_chronovium_ore",
                    () -> new BlockItem(DEEPSLATE_CHRONOVIUM_ORE.get(),
                            new Item.Properties().setId(ITEMS.key("deepslate_chronovium_ore"))));
    public static final RegistryObject<Item> CONSOLE_ITEM = ITEMS.register("console",
            () -> new BlockItem(CONSOLE.get(), new Item.Properties().setId(ITEMS.key("console")).stacksTo(64)));

    // ---------------------------------------------------------------------
    // Creative tab
    // ---------------------------------------------------------------------
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("tva_tech",
            () -> CreativeModeTab.builder()
                    .title(net.minecraft.network.chat.Component.translatable("itemGroup.tvatech.tva_tech"))
                    .icon(() -> TEMPAD.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(TEMPAD.get());
                        output.accept(MOBIUS_MOBILE.get());
                        output.accept(VARIANT_SCANNER.get());
                        output.accept(TIME_COLLAR.get());
                        output.accept(TIME_COLLAR_REMOTE.get());
                        output.accept(CHRONO_BATTERY.get());
                        output.accept(RAW_CHRONOVIUM.get());
                        output.accept(CHRONOVIUM_INGOT.get());
                        output.accept(ARC_REACTOR_ITEM.get());
                        output.accept(CHRONOVIUM_BLOCK_ITEM.get());
                        output.accept(CHRONOVIUM_ORE_ITEM.get());
                        output.accept(DEEPSLATE_CHRONOVIUM_ORE_ITEM.get());
                        output.accept(TIME_DOOR_ITEM.get());
                        output.accept(COMPUTER_ITEM.get());
                        output.accept(TERMINAL_ITEM.get());
                        output.accept(CONSOLE_ITEM.get());
                        output.accept(TVA_MANUAL.get());
                    })
                    .build());
}