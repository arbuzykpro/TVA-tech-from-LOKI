package com.tvatech.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import com.tvatech.ModContent;
import com.tvatech.TvaConfig;
import com.tvatech.system.ChronoFreeze;
import com.tvatech.system.MobileAbilities;
import com.tvatech.system.Pruning;
import com.tvatech.system.TimeTravel;
import com.tvatech.util.TvaData;

import java.util.Collection;
import java.util.List;

/**
 * {@code /tva} - operator helpers and a way to exercise every gadget without
 * having to click through the game.
 */
public final class TvaCommands {

    private TvaCommands() {}

    private static final MutableComponent PREFIX = Component.literal("[TVA] ").withStyle(ChatFormatting.AQUA);

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("tva")
                .requires(source -> source.hasPermission(2));

        root.then(Commands.literal("give")
                .then(Commands.argument("item", StringArgumentType.word())
                        .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "item"), 1))
                        .then(Commands.argument("count", IntegerArgumentType.integer(1, 64))
                                .executes(ctx -> give(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "item"),
                                        IntegerArgumentType.getInteger(ctx, "count"))))));

        root.then(Commands.literal("pin")
                .executes(ctx -> pin(ctx.getSource(), null, null, null))
                .then(Commands.argument("x", IntegerArgumentType.integer())
                        .then(Commands.argument("y", IntegerArgumentType.integer())
                                .then(Commands.argument("z", IntegerArgumentType.integer())
                                        .executes(ctx -> pin(ctx.getSource(),
                                                IntegerArgumentType.getInteger(ctx, "x"),
                                                IntegerArgumentType.getInteger(ctx, "y"),
                                                IntegerArgumentType.getInteger(ctx, "z")))))));

        root.then(Commands.literal("hop").executes(ctx -> hop(ctx.getSource())));
        root.then(Commands.literal("info").executes(ctx -> info(ctx.getSource())));
        root.then(Commands.literal("prune").executes(ctx -> prune(ctx.getSource())));
        root.then(Commands.literal("scan").executes(ctx -> scan(ctx.getSource())));

        root.then(Commands.literal("freeze")
                .executes(ctx -> freeze(ctx.getSource(), TvaConfig.freezeRadius, TvaConfig.freezeDurationTicks))
                .then(Commands.argument("radius", IntegerArgumentType.integer(1, 64))
                        .executes(ctx -> freeze(ctx.getSource(),
                                IntegerArgumentType.getInteger(ctx, "radius"), TvaConfig.freezeDurationTicks))
                        .then(Commands.argument("ticks", IntegerArgumentType.integer(1, 12000))
                                .executes(ctx -> freeze(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "radius"),
                                        IntegerArgumentType.getInteger(ctx, "ticks"))))));

        root.then(Commands.literal("variant")
                .executes(ctx -> showVariant(ctx.getSource()))
                .then(Commands.argument("amount", IntegerArgumentType.integer(0, 100000))
                        .executes(ctx -> setVariant(ctx.getSource(),
                                IntegerArgumentType.getInteger(ctx, "amount")))));

        root.then(Commands.literal("anchor").executes(ctx -> {
            ServerPlayer player = ctx.getSource().getPlayer();
            if (player == null) {
                ctx.getSource().sendFailure(Component.literal("This command must be run by a player."));
                return 0;
            }
            MobileAbilities.toggleAnchor(player);
            return 1;
        }));

        root.then(Commands.literal("timeline").executes(ctx -> {
            ServerPlayer player = ctx.getSource().getPlayer();
            if (player == null) {
                ctx.getSource().sendFailure(Component.literal("This command must be run by a player."));
                return 0;
            }
            MobileAbilities.printTimeline(player);
            return 1;
        }));

        dispatcher.register(root);
    }

    // ------------------------------------------------------------------
    // Implementations
    // ------------------------------------------------------------------

    private static int give(CommandSourceStack source, String what, int count) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        Item item = switch (what.toLowerCase(java.util.Locale.ROOT)) {
            case "tempad" -> ModContent.TEMPAD.get();
            case "mobile", "mobius" -> ModContent.MOBIUS_MOBILE.get();
            case "scanner" -> ModContent.VARIANT_SCANNER.get();
            case "battery" -> ModContent.CHRONO_BATTERY.get();
            case "reactor" -> ModContent.ARC_REACTOR_ITEM.get();
            case "door" -> ModContent.TIME_DOOR_ITEM.get();
            case "ingot" -> ModContent.CHRONOVIUM_INGOT.get();
            case "block" -> ModContent.CHRONOVIUM_BLOCK_ITEM.get();
            default -> null;
        };
        if (item == null) {
            source.sendFailure(Component.literal("Unknown gadget: " + what));
            return 0;
        }
        ItemStack stack = new ItemStack(item, count);
        if (stack.is(ModContent.TEMPAD.get())) {
            TimeTravel.setCharge(stack, TvaConfig.tempadMaxCharge);
        }
        player.getInventory().add(stack);
        source.sendSuccess(() -> PREFIX.append(Component.literal("Gave " + count + "x " + item.getName(stack))),
                true);
        return count;
    }

    private static int pin(CommandSourceStack source, Integer x, Integer y, Integer z) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        ItemStack gadget = gadgetOf(player);
        if (gadget == null) {
            source.sendFailure(Component.literal("You need to be holding a TemPad."));
            return 0;
        }
        ServerLevel level = player.serverLevel();
        BlockPos pos = (x == null || y == null || z == null) ? player.blockPosition() : new BlockPos(x, y, z);
        TimeTravel.setPin(gadget, level, pos);
        source.sendSuccess(() -> PREFIX.append(Component.literal(
                "Pinned " + TimeTravel.describe(level, pos) + " (" + TimeTravel.pinDimension(gadget) + ")")),
                false);
        return 1;
    }

    private static int hop(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        ItemStack gadget = gadgetOf(player);
        if (gadget == null) {
            source.sendFailure(Component.literal("You need to be holding a TemPad."));
            return 0;
        }
        if (!TimeTravel.hasPin(gadget)) {
            source.sendFailure(Component.literal("No destination pinned. Use /tva pin first."));
            return 0;
        }
        TimeTravel.setCharge(gadget, TvaConfig.tempadMaxCharge);
        TvaData.setLong(gadget, TimeTravel.KEY_LAST_HOP, 0L);
        boolean ok = TimeTravel.hop(player, gadget);
        source.sendSuccess(() -> PREFIX.append(Component.literal(ok
                ? "Time jump complete, variant #" + TimeTravel.variant(player)
                : "Time jump refused")), false);
        return ok ? 1 : 0;
    }

    private static int info(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        ItemStack gadget = gadgetOf(player);
        int charge = gadget == null ? -1 : TimeTravel.charge(gadget);
        List<String> timeline = TimeTravel.log(player);
        source.sendSuccess(() -> PREFIX.append(Component.literal(
                "variant #" + TimeTravel.variant(player)
                        + ", charge " + charge + "/" + TvaConfig.tempadMaxCharge
                        + ", pinned " + (gadget != null && TimeTravel.hasPin(gadget))
                        + ", timeline entries " + timeline.size()
                        + ", reactor " + MobileAbilities.hasReactorNearby(player))), false);
        return 1;
    }

    private static int prune(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        Entity target = nearestMob(player, 16.0);
        if (target == null) {
            source.sendFailure(Component.literal("No living variant in range to prune."));
            return 0;
        }
        boolean ok = Pruning.prune(target, player);
        source.sendSuccess(() -> PREFIX.append(Component.literal(ok ? "Variant pruned." : "Pruning refused.")), false);
        return ok ? 1 : 0;
    }

    private static int scan(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        Entity target = MobileAbilities.lookTarget(player, 16.0);
        if (target == null) {
            source.sendFailure(Component.literal("No variant in line of sight."));
            return 0;
        }
        source.sendSuccess(() -> PREFIX.append(Component.literal(
                TvaEntityNames.of(target) + " -> variant #" + TimeTravel.variant(target))), false);
        return 1;
    }

    private static int freeze(CommandSourceStack source, int radius, int ticks) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        int locked = ChronoFreeze.freeze(player, radius, ticks);
        source.sendSuccess(() -> PREFIX.append(Component.literal(
                "Chrono-locked " + locked + " variants for " + (ticks / 20.0) + "s")), false);
        return locked;
    }

    private static int showVariant(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        source.sendSuccess(() -> PREFIX.append(Component.literal("Variant #" + TimeTravel.variant(player))), false);
        return 1;
    }

    private static int setVariant(CommandSourceStack source, int amount) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("This command must be run by a player."));
            return 0;
        }
        TimeTravel.setVariant(player, amount);
        source.sendSuccess(() -> PREFIX.append(Component.literal("Variant set to #" + amount)), true);
        return 1;
    }

    private static ItemStack gadgetOf(ServerPlayer player) {
        ItemStack main = player.getMainHandItem();
        if (main.is(ModContent.TEMPAD.get())) {
            return main;
        }
        ItemStack off = player.getOffhandItem();
        return off.is(ModContent.TEMPAD.get()) ? off : null;
    }

    private static Entity nearestMob(ServerPlayer player, double range) {
        Collection<Entity> entities = player.serverLevel().getEntities(player,
                player.getBoundingBox().inflate(range),
                entity -> entity instanceof Mob && entity.isAlive());
        Entity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity entity : entities) {
            double distance = entity.distanceTo(player);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = entity;
            }
        }
        return best;
    }

    /** Small indirection so the command module does not depend on the client helper. */
    private static final class TvaEntityNames {
        static String of(Entity entity) {
            return com.tvatech.util.TvaEntityName.of(entity);
        }
    }
}