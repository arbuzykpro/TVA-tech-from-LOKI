package com.tvatech.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** Blue TVA alloy. Purely decorative, used to build the gadgets. */
public class ChronoviumBlock extends Block {

    public ChronoviumBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}