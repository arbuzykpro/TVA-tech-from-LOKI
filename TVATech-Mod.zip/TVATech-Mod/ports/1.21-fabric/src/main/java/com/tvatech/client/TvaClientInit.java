package com.tvatech.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import com.tvatech.network.TvaNetwork;

/**
 * Client-only entrypoint.
 *
 * <p>Kept separate from the common entrypoint so the dedicated server never
 * loads client classes. Registers the server-to-client payload receivers and
 * the dev menu preview.</p>
 */
public final class TvaClientInit implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        TvaNetwork.initClient();
        ClientTickEvents.END_CLIENT_TICK.register(client -> TvaClient.debugOpenMenuIfRequested());
    }
}
