<#
    build.ps1 - build helper for the TVA Tech Forge mod.

    Why this script exists:
    The project lives in a folder whose path contains non-ASCII characters
    (C:\Users\<user>\OneDrive\<cyrillic>\...). ForgeGradle spawns a forked JVM
    (the "mavenizer" mapping/binary patcher) and hands it absolute project paths
    as command line arguments. Windows decodes those arguments with the system
    ANSI code page, which cannot represent the folder name, so the build dies
    with "Failed to ensure existence of directory: C:\...\?????????\...".

    Workaround: mirror the sources into an ASCII-only directory, run Gradle
    there, then copy the resulting jar back next to the project.

    Usage:
        pwsh -File build.ps1                 # same as: build
        pwsh -File build.ps1 build           # compile + jar
        pwsh -File build.ps1 runClient       # launch a dev client
        pwsh -File build.ps1 runData         # run data generators
        pwsh -File build.ps1 clean           # wipe build + staging dir
        pwsh -File build.ps1 build --info   # any extra args are forwarded
#>

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('build', 'jar', 'runClient', 'runServer', 'runData', 'gameTestServer', 'clean', 'test')]
    [string] $Task = 'build',

    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]] $ExtraArgs,

    # Which Minecraft/Forge pair to build. Defaults to 26.3-forge.
    [string] $Target
)

$ErrorActionPreference = 'Stop'

$projectDir = $PSScriptRoot

$TARGETS = @{
    '26.3-forge' = @{ Mc = '26.3'; Forge = '66.0.12'; Range = '[26.3,26.4)' }
}

if ($Target -and -not $TARGETS.ContainsKey($Target)) {
    throw "unknown target '$Target'. Known: $(($TARGETS.Keys | Sort-Object) -join ', ')"
}
if (-not $Target) { $Target = '26.3-forge' }
$sel = $TARGETS[$Target]

# Each target gets its own staging directory. They cannot share one: Gradle
# caches the deobfuscated Minecraft per version inside the project directory,
# and swapping the version under a live cache is how you get a jar that
# silently links against the wrong Minecraft.
$stageRoot  = Join-Path $env:LOCALAPPDATA 'Temp\opencode\mc-build'
$stageDir   = Join-Path $stageRoot "TVATech-Mod-$($sel.Mc)"

# Gradle itself runs on any supported launcher JVM; the Java 25 toolchain is
# auto-detected from ~/.gradle/jdks (see Tools\install-jdk25.ps1).
$launcherJava = 'C:\Program Files\Eclipse Adoptium\jdk-21.0.10.7-hotspot'
if (-not (Test-Path $launcherJava)) {
    $launcherJava = $env:JAVA_HOME
}

function Write-Step([string] $msg) {
    Write-Host "==> $msg" -ForegroundColor Cyan
}

if ($Task -eq 'clean') {
    Write-Step 'Cleaning'
    foreach ($dir in @((Join-Path $projectDir 'build'), (Join-Path $projectDir 'run'))) {
        if (Test-Path $dir) {
            Remove-Item -Recurse -Force $dir
            Write-Host "    removed $dir"
        }
    }
    if ($ExtraArgs -contains '--all') {
        # Also drops the staging directories, which forces ForgeGradle to rebuild
        # the Minecraft artifacts on the next run (slow: ~10 minutes each).
        foreach ($dir in @(Get-ChildItem $stageRoot -Directory -Filter 'TVATech-Mod*' -ErrorAction SilentlyContinue)) {
            Remove-Item -Recurse -Force $dir.FullName
            Write-Host "    removed $($dir.FullName)"
        }
    } else {
        Write-Host '    (kept the staging cache; pass --all to drop it too)'
    }
    return
}

# ---------------------------------------------------------------------------
# Mirror sources into the ASCII staging directory
# ---------------------------------------------------------------------------
Write-Step "Mirroring sources to $stageDir"
New-Item -ItemType Directory -Force -Path $stageDir | Out-Null
$include = @(
    'build.gradle', 'settings.gradle', 'gradle.properties', 'changelog.txt', 'gradlew', 'gradlew.bat'
)
foreach ($file in $include) {
    $src = Join-Path $projectDir $file
    if (Test-Path $src) { Copy-Item -Force $src (Join-Path $stageDir $file) }
}

foreach ($dir in @('gradle', 'src')) {
    $src = Join-Path $projectDir $dir
    if (-not (Test-Path $src)) { continue }
    $dst = Join-Path $stageDir $dir
    if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
    & robocopy $src $dst /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "robocopy failed for $dir (exit $LASTEXITCODE)" }
}
Write-Host '    sources mirrored'

# ---------------------------------------------------------------------------
# Run Gradle in the staging directory
# ---------------------------------------------------------------------------
$gradleTask = if ($Task -in @('build', 'jar', 'test')) { $Task } else { $Task }

Write-Step "Gradle: $gradleTask  (mc $($sel.Mc), forge $($sel.Forge))"
$env:JAVA_HOME = $launcherJava
Push-Location $stageDir
try {
    # The -P flags are what actually select the Minecraft version: build.gradle
    # reads them instead of the defaults in gradle.properties.
    $args = @(
        $gradleTask, '--console=plain',
        "-Pmc_version=$($sel.Mc)",
        "-Pforge_version=$($sel.Forge)",
        "-Pmc_version_range=$($sel.Range)"
    )
    if ($ExtraArgs) { $args += $ExtraArgs }
    & (Join-Path $stageDir 'gradlew.bat') @args
    $gradleExit = $LASTEXITCODE
}
finally {
    Pop-Location
}

if ($gradleExit -ne 0) {
    throw "Gradle task '$gradleTask' failed with exit code $gradleExit"
}

# ---------------------------------------------------------------------------
# Copy the produced jar back into the project
#
# Every jar lands in build/libs/<mc version> <loader>/ and is named
# TVA_tech_<mc version>_<mod version>.jar, so the eight supported targets sit
# side by side and it is obvious which is which at a glance.
# ---------------------------------------------------------------------------
$libs = Join-Path $stageDir 'build\libs'
if (Test-Path $libs) {
    $mcVersion = $sel.Mc
    $loader    = 'forge'
    $modVersion = '0.0.0'
    $props = Join-Path $projectDir 'gradle.properties'
    if (Test-Path $props) {
        $line = Select-String -Path $props -Pattern '^mod_version\s*=\s*(.+)$' | Select-Object -First 1
        if ($line) { $modVersion = $line.Matches[0].Groups[1].Value.Trim() }
    }

    $targetDir = Join-Path $projectDir "build\libs\$mcVersion $loader"
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null

    # Pick the jar for THIS build, not just any jar in the folder. The staging
    # directory keeps every jar Gradle has ever produced here, so "take them all"
    # ships a dozen stale versions under one name and which one lands last is
    # decided by alphabetical order - tvatech-1.5.1 would beat tvatech-1.5.0.
    # Matching the base name (archivesName-version) is exact; the fallback to
    # the newest file is only for the case where the name was customised.
    $expected = "tvatech-${modVersion}.jar"
    $jar = Get-ChildItem $libs -Filter $expected -ErrorAction SilentlyContinue |
           Select-Object -First 1
    if (-not $jar) {
        $jar = Get-ChildItem $libs -Filter 'tvatech-*.jar' -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -notmatch 'sources|dev' } |
               Sort-Object LastWriteTime -Descending |
               Select-Object -First 1
    }

    if ($jar) {
        $newName = "TVA_tech_${mcVersion}_${modVersion}.jar"
        Copy-Item -Force $jar.FullName (Join-Path $targetDir $newName)
        Write-Step "Built $newName  ->  build\libs\$mcVersion $loader\"
    } else {
        Write-Step "No jar found in build\libs for mod version ${modVersion}." -ForegroundColor Yellow
    }
}

Write-Step 'Done.' -ForegroundColor Green