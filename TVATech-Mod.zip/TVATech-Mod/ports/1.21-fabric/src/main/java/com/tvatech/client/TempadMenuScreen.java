package com.tvatech.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import com.tvatech.network.TvaNetwork;

import java.util.List;

/**
 * The TemPad's destination menu.
 *
 * <p>Pick a saved mark, drop a new one wherever you are standing, optionally
 * dial in a point in history (world day + time of day), then jump. Leaving the
 * time alone lands you in the present.</p>
 */
public class TempadMenuScreen extends Screen {

    private static final int PHONE_W = 212;
    private static final int PHONE_H = 228;
    private static final int PAD = 8;

    private static final int FRAME = 0xFF241A12;
    private static final int FRAME_LIGHT = 0xFF4A3826;
    private static final int SCREEN_BG = 0xFF2B1A0C;
    private static final int SCREEN_EDGE = 0xFFD8862F;
    private static final int TEXT = 0xFFFFCE93;
    private static final int TEXT_DIM = 0xFFB08452;
    private static final int AMBER = 0xFFFFB04A;
    private static final int BUTTON = 0xFF3A2412;
    private static final int BUTTON_HOVER = 0xFF54341A;
    private static final int BUTTON_OFF = 0xFF2A231C;
    private static final int ROW = 0xFF341F0E;
    private static final int ROW_SEL = 0xFF5A3312;

    private static final int ROW_H = 13;
    private static final int MAX_ROWS = 4;
    private static final int BUTTON_H = 14;
    private static final int STEP_W = 12;
    /** Height of one MANUAL-view input row. */
    private static final int BOX_H = 13;
    /** Vertical stride of a MANUAL-view input row. */
    private static final int BOX_STEP = 15;

    /** The first real day of the world. */
    private static final int FIRST_DAY = 0;
    /** One step before it, which is not a day at all. */
    private static final int END_OF_TIME = FIRST_DAY - 1;

    private final TvaNetwork.OpenTemPadMenuPayload data;

    // Local UI state
    private int selected;
    private long day;
    private int hour;
    private boolean useTime;

    /** First mark shown in the list; moves with the wheel. */
    private int scroll;

    /**
     * While true the door you open next runs red: a time cell. Whoever steps
     * into it is held there - falling from the sky, clock at 20x - until they
     * reach for the TemPad again.
     */
    private boolean cellMode;
    /** While true the list is hidden behind the rename box. */
    private boolean renaming;
    private EditBox nameBox;

    /**
     * While true the list is hidden behind the four MANUAL input boxes.
     *
     * <p>A mark typed here does not need to exist yet - coord submission always
     * adds a fresh mark, and the server fills in the automatic label.</p>
     */
    private boolean manual;
    private EditBox xBox;
    private EditBox yBox;
    private EditBox zBox;
    private EditBox dimBox;

    // Layout, recomputed every frame so drawing and clicks can never disagree.
    private int phoneX;
    private int phoneY;
    private int screenX;
    private int screenY;
    private int screenW;
    private int screenH;
    private int contentX;
    private int contentY;
    private int contentW;
    private int listY;
    private int infoY;
    private int infoH;
    private int arrivalY;
    private int dayRowY;
    private int timeRowY;
    private int buttonsY;

    public TempadMenuScreen(TvaNetwork.OpenTemPadMenuPayload data) {
        super(Component.translatable("tvatech.tempad.title"));
        this.data = data;
        this.day = data.day();
        this.hour = data.hour();
        this.useTime = false;
        this.selected = data.labels().isEmpty() ? -1 : 0;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void layout() {
        phoneX = (this.width - PHONE_W) / 2;
        phoneY = (this.height - PHONE_H) / 2;
        screenX = phoneX + PAD;
        screenY = phoneY + PAD;
        screenW = PHONE_W - PAD * 2;
        screenH = PHONE_H - PAD * 2;
        contentX = screenX + 8;
        contentY = screenY + 7;
        contentW = screenW - 16;

        listY = contentY + 14;
        infoH = 26;
        infoY = listY + MAX_ROWS * ROW_H + 3;
        arrivalY = infoY + infoH + 6;
        dayRowY = arrivalY + 16;
        timeRowY = dayRowY + 16;
        buttonsY = timeRowY + 18;

        if (nameBox != null) {
            nameBox.setX(contentX);
            nameBox.setY(infoY + 12);
            nameBox.setWidth(contentW - 4);
        }
        layoutManual();
    }

    /** MANUAL-view box positions: they live where the mark list lives. */
    private void layoutManual() {
        if (xBox != null) {
            int w = contentW - 26;
            xBox.setX(contentX + 26);
            xBox.setY(listY + BOX_STEP * 0);
            xBox.setWidth(w);
            yBox.setX(contentX + 26);
            yBox.setY(listY + BOX_STEP * 1);
            yBox.setWidth(w);
            zBox.setX(contentX + 26);
            zBox.setY(listY + BOX_STEP * 2);
            zBox.setWidth(w);
            dimBox.setX(contentX + 26);
            dimBox.setY(listY + BOX_STEP * 3);
            dimBox.setWidth(w);
        }
    }

    /** Scrolls the list just enough to keep the selection on screen. */
    private void clampScroll() {
        int total = data.labels().size();
        int max = Math.max(0, total - MAX_ROWS);
        if (selected >= 0) {
            if (selected < scroll) {
                scroll = selected;
            } else if (selected >= scroll + MAX_ROWS) {
                scroll = selected - MAX_ROWS + 1;
            }
        }
        scroll = Math.max(0, Math.min(max, scroll));
    }

    /** Opens the rename box on the selected mark. */
    private void beginRename() {
        if (selected < 0 || selected >= data.labels().size()) {
            return;
        }
        endManual(false);
        renaming = true;
        nameBox = new EditBox(this.font, 0, 0, contentW - 4, 12,
                Component.translatable("tvatech.tempad.rename"));
        nameBox.setMaxLength(com.tvatech.system.TvaMarks.MAX_LABEL);
        nameBox.setValue(data.labels().get(selected));
        nameBox.setResponder(text -> { });
        nameBox.setFocused(true);
        nameBox.setCanLoseFocus(false);
    }

    private void endRename(boolean save) {
        if (save && nameBox != null && selected >= 0) {
            send(TvaNetwork.MENU_RENAME_MARK, nameBox.getValue());
        }
        renaming = false;
        nameBox = null;
    }

    /** Enters the MANUAL view. */
    private void beginManual() {
        endRename(false);
        manual = true;
        boolean fresh = xBox == null;
        if (fresh) {
            xBox = new EditBox(this.font, 0, 0, contentW - 26, BOX_H, Component.literal("X"));
            yBox = new EditBox(this.font, 0, 0, contentW - 26, BOX_H, Component.literal("Y"));
            zBox = new EditBox(this.font, 0, 0, contentW - 26, BOX_H, Component.literal("Z"));
            dimBox = new EditBox(this.font, 0, 0, contentW - 26, BOX_H, Component.literal("dim"));
            xBox.setMaxLength(9);
            yBox.setMaxLength(9);
            zBox.setMaxLength(9);
            dimBox.setMaxLength(128);
            // Start at where you stand, so opening MANUAL and pressing
            // ADD MARK is simply "mark this spot" - the old button's job.
            var spot = net.minecraft.client.Minecraft.getInstance().player;
            if (spot != null) {
                var pos = spot.blockPosition();
                xBox.setValue(String.valueOf(pos.getX()));
                yBox.setValue(String.valueOf(pos.getY()));
                zBox.setValue(String.valueOf(pos.getZ()));
                dimBox.setValue(spot.level().dimension().location().toString());
            } else {
                xBox.setValue("0");
                yBox.setValue("0");
                zBox.setValue("0");
                dimBox.setValue("minecraft:overworld");
            }
        }
        if (xBox.getValue().isEmpty()) {
            xBox.setValue("0");
        }
        if (yBox.getValue().isEmpty()) {
            yBox.setValue("0");
        }
        if (zBox.getValue().isEmpty()) {
            zBox.setValue("0");
        }
        if (dimBox.getValue().isEmpty()) {
            dimBox.setValue("minecraft:overworld");
        }
        xBox.setFocused(true);
        yBox.setFocused(false);
        zBox.setFocused(false);
        dimBox.setFocused(false);
        layoutManual();
    }

    private void endManual(boolean add) {
        if (add && manual && xBox != null) {
            send(TvaNetwork.MENU_MANUAL_MARK);
        }
        manual = false;
        xBox = null;
        yBox = null;
        zBox = null;
        dimBox = null;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        layout();

        // shell
        graphics.fill(phoneX, phoneY, phoneX + PHONE_W, phoneY + PHONE_H, FRAME);
        graphics.fill(phoneX, phoneY, phoneX + PHONE_W, phoneY + 1, FRAME_LIGHT);
        graphics.fill(phoneX, phoneY, phoneX + 1, phoneY + PHONE_H, FRAME_LIGHT);
        graphics.fill(phoneX + PHONE_W - 1, phoneY, phoneX + PHONE_W, phoneY + PHONE_H, 0xFF101015);
        graphics.fill(phoneX, phoneY + PHONE_H - 1, phoneX + PHONE_W, phoneY + PHONE_H, 0xFF101015);

        graphics.fill(screenX, screenY, screenX + screenW, screenY + screenH, SCREEN_BG);
        graphics.renderOutline(screenX, screenY, screenW, screenH, SCREEN_EDGE);
        for (int y = screenY + 2; y < screenY + screenH - 1; y += 3) {
            graphics.fill(screenX + 1, y, screenX + screenW - 1, y + 1, 0x14000000);
        }

        int y = contentY;
        graphics.drawString(this.font, title.copy().withStyle(ChatFormatting.GOLD), contentX, y, TEXT, false);
        graphics.drawString(this.font, Component.literal("TEMPORAL ATLAS"),
                contentX + contentW - this.font.width("TEMPORAL ATLAS"), y, TEXT_DIM, false);

        if (renaming) {
            drawRename(graphics, mouseX, mouseY, partialTick);
        } else if (manual) {
            drawManual(graphics, mouseX, mouseY, partialTick);
        } else {
            drawMarkList(graphics, mouseX, mouseY);
            drawSelected(graphics);
            drawTime(graphics, mouseX, mouseY);
        }
        drawButtons(graphics, mouseX, mouseY);
    }

    private void drawMarkList(GuiGraphics graphics, int mouseX, int mouseY) {
        List<String> labels = data.labels();
        int shown = Math.min(MAX_ROWS, labels.size());

        for (int i = 0; i < shown; i++) {
            int index = scroll + i;
            if (index >= labels.size()) {
                break;
            }
            int ry = listY + i * ROW_H;
            boolean isSel = index == selected;
            boolean hover = mouseX >= contentX && mouseX < contentX + contentW
                    && mouseY >= ry && mouseY < ry + ROW_H;
            graphics.fill(contentX, ry, contentX + contentW, ry + ROW_H - 1, isSel ? ROW_SEL : ROW);
            if (hover && !isSel) {
                graphics.renderOutline(contentX, ry, contentW, ROW_H - 1, 0xFF7A4A1E);
            }
            String name = labels.get(index);
            // Long names give way to the coordinates rather than run off the
            // screen, and an arrow marks that there is more of the name.
            int room = contentW - 60;
            String shown2 = this.font.plainSubstrByWidth(name, room - 6);
            if (!shown2.equals(name)) {
                shown2 = this.font.plainSubstrByWidth(name, room - 12) + "...";
            }
            graphics.drawString(this.font, shown2, contentX + 4, ry + 3, isSel ? AMBER : TEXT, false);
            // The day/time sits at the right edge, its own width wide, so a
            // long name can never walk into it: the two simply meet, each
            // trimmed to its own half of the row.
            String timeText = formatMark(index);
            int timeRoom = contentW - 56;
            if (this.font.width(timeText) > timeRoom) {
                timeText = this.font.plainSubstrByWidth(timeText, timeRoom);
            }
            graphics.drawString(this.font,
                    Component.literal(timeText),
                    contentX + contentW - 4 - this.font.width(timeText), ry + 3, TEXT_DIM, false);
        }

        if (labels.isEmpty()) {
            graphics.drawString(this.font, Component.translatable("tvatech.tempad.no_marks"),
                    contentX + 4, listY + 3, TEXT_DIM, false);
        }

        drawScrollbar(graphics, mouseX, mouseY, labels.size());
    }

    /**
     * A scrollbar down the right edge of the list.
     *
     * <p>Only drawn when there is more than one screenful of marks; the thumb is
     * draggable as well as clickable at the ends.</p>
     */
    private void drawScrollbar(GuiGraphics graphics, int mouseX, int mouseY, int total) {
        if (total <= MAX_ROWS) {
            return;
        }
        int trackX = contentX + contentW - 2;
        int trackH = MAX_ROWS * ROW_H;
        graphics.fill(trackX, listY, trackX + 2, listY + trackH, 0xFF1A1006);

        int thumbH = Math.max(6, trackH * MAX_ROWS / total);
        int travel = trackH - thumbH;
        int thumbY = listY + (total <= MAX_ROWS ? 0 : travel * scroll / (total - MAX_ROWS));
        graphics.fill(trackX, thumbY, trackX + 2, thumbY + thumbH, AMBER);
    }

    private String formatMark(int index) {
        int hour = Math.floorMod(data.markedHours()[index], 24);
        int display = hour % 12;
        if (display == 0) {
            display = 12;
        }
        return String.format("d%d %d %s", data.markedDays()[index], display, hour < 12 ? "AM" : "PM");
    }

    private void drawSelected(GuiGraphics graphics) {
        graphics.fill(contentX - 3, infoY, contentX - 3 + contentW + 6, infoY + infoH, 0xFF241207);
        graphics.renderOutline(contentX - 3, infoY, contentW + 6, infoH, 0xFF7A4A1E);
        if (selected >= 0 && selected < data.labels().size()) {
            graphics.drawString(this.font,
                    Component.literal("x=" + data.xs()[selected] + "  y=" + data.ys()[selected]
                            + "  z=" + data.zs()[selected]),
                    contentX, infoY + 5, TEXT, false);
            graphics.drawString(this.font, Component.literal(shortDimension(selected)),
                    contentX, infoY + infoH - 11, TEXT_DIM, false);
        } else {
            graphics.drawString(this.font, Component.translatable("tvatech.tempad.select_hint"),
                    contentX, infoY + 5, TEXT_DIM, false);
        }
    }

    private String shortDimension(int index) {
        String dim = data.dimensions().get(index);
        int colon = dim.indexOf(':');
        return colon >= 0 ? dim.substring(colon + 1).replace('_', ' ') : dim;
    }

    private void drawTime(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(this.font, Component.translatable("tvatech.tempad.arrival"),
                contentX, arrivalY, TEXT, false);

        // toggle: set time / keep present
        int toggleW = 62;
        int toggleX = contentX + contentW - toggleW;
        drawButton(graphics, toggleX, arrivalY - 3, toggleW, BUTTON_H,
                Component.translatable(useTime ? "tvatech.tempad.time_on" : "tvatech.tempad.time_off"),
                hovered(mouseX, mouseY, toggleX, arrivalY - 3, toggleW, BUTTON_H), true);

        // Day stepper: "DAY" [-] 3 [+]. Locked while in PRESENT mode. Day 0 is the
        // first day of the world and the minus goes dead there, because one
        // step further is not a day at all - it is the End of Time.
        graphics.drawString(this.font, Component.literal("DAY"), contentX, dayRowY + 3, TEXT_DIM, false);
        boolean dayDown = day > END_OF_TIME;
        drawStep(graphics, mouseX, mouseY, dayRowY, 22, -1, useTime && dayDown);
        graphics.drawString(this.font, Component.literal(String.valueOf(day)),
                contentX + 38, dayRowY + 3, useTime ? AMBER : TEXT, false);
        drawStep(graphics, mouseX, mouseY, dayRowY, 74, 1, useTime);

        if (day < FIRST_DAY) {
            graphics.drawString(this.font, Component.translatable("tvatech.tempad.tva_hint"),
                    contentX + 92, dayRowY + 3, AMBER, false);
        }

        // Time stepper: "TIME" [-] 2:00 PM [+]
        graphics.drawString(this.font, Component.literal("TIME"), contentX, timeRowY + 3, TEXT_DIM, false);
        drawStep(graphics, mouseX, mouseY, timeRowY, 30, -1, useTime);
        graphics.drawString(this.font, Component.literal(clockText()),
                contentX + 46, timeRowY + 3, useTime ? AMBER : TEXT, false);
        drawStep(graphics, mouseX, mouseY, timeRowY, 120, 1, useTime);
    }

    /** One of the small [-] / [+] squares on a stepper row. */
    private void drawStep(GuiGraphics graphics, int mouseX, int mouseY, int rowY,
                          int offset, int sign, boolean enabled) {
        int x = contentX + offset;
        drawButton(graphics, x, rowY, STEP_W, BUTTON_H, Component.literal(sign < 0 ? "-" : "+"),
                hovered(mouseX, mouseY, x, rowY, STEP_W, BUTTON_H), enabled);
    }

    /**
     * The MANUAL view: type in a mark by hand.
     *
     * <p>The mark list gives way to four boxes - coordinates and a dimension -
     * the way it gives way while renaming. The keyboard goes straight into the
     * first box; TAB hops to the next one and clicking anywhere in a box
     * selects it.</p>
     */
    private void drawManual(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        drawBoxRow(graphics, "X", xBox, listY + BOX_STEP * 0, mouseX, mouseY, partialTick);
        drawBoxRow(graphics, "Y", yBox, listY + BOX_STEP * 1, mouseX, mouseY, partialTick);
        drawBoxRow(graphics, "Z", zBox, listY + BOX_STEP * 2, mouseX, mouseY, partialTick);
        drawBoxRow(graphics, "DIM", dimBox, listY + BOX_STEP * 3, mouseX, mouseY, partialTick);

        graphics.drawString(this.font, Component.literal("add a mark by hand - ADD MARK saves it"),
                contentX, infoY + 5, TEXT_DIM, false);
        graphics.drawString(this.font, Component.literal(dimSummary()),
                contentX, infoY + infoH - 11, TEXT_DIM, false);

        drawTime(graphics, mouseX, mouseY);
    }

    /** One label + edit box line of the MANUAL view. */
    private void drawBoxRow(GuiGraphics graphics, String label, EditBox box,
                            int y, int mouseX, int mouseY, float partialTick) {
        if (box == null) {
            return;
        }
        graphics.drawString(this.font, Component.literal(label), contentX, y + 3,
                box.isFocused() ? AMBER : TEXT_DIM, false);
        graphics.fill(contentX - 1, y - 1, contentX + 24, y + BOX_H, 0xFF100C06);
        box.render(graphics, mouseX, mouseY, partialTick);
    }

    /** The dimension box, folded to the short form the list uses. */
    private String dimSummary() {
        String dim = dimBox != null ? dimBox.getValue().strip() : "";
        if (dim.isEmpty()) {
            return "";
        }
        if (!dim.contains(":")) {
            dim = "minecraft:" + dim;
        }
        int colon = dim.indexOf(':');
        return colon >= 0 ? dim.substring(colon + 1).replace('_', ' ') : dim;
    }

    /** Arrival times are whole hours, so there is no minute to show. */
    private String clockText() {
        int h = Math.floorMod(hour, 24);
        String suffix = h < 12 ? "AM" : "PM";
        int display = h % 12;
        if (display == 0) {
            display = 12;
        }
        return display + ":00 " + suffix;
    }

    private void drawButtons(GuiGraphics graphics, int mouseX, int mouseY) {
        int half = (contentW - 4) / 2;
        boolean haveMark = !manual && !renaming && selected >= 0 && selected < data.labels().size();

        // Row 1: MANUAL toggle on the left (it is the mode's front door), and
        // rename on the right, which only belongs to the list view.
        drawButton(graphics, contentX, buttonsY, half, BUTTON_H,
                Component.literal(manual ? "MANUAL: ON" : "MANUAL"),
                hovered(mouseX, mouseY, contentX, buttonsY, half, BUTTON_H), true);
        drawButton(graphics, contentX + half + 4, buttonsY, half, BUTTON_H,
                Component.translatable("tvatech.tempad.rename"),
                hovered(mouseX, mouseY, contentX + half + 4, buttonsY, half, BUTTON_H),
                haveMark);

        int y2 = buttonsY + BUTTON_H + 4;
        // Row 2 left doubles as the manual view's submit button.
        drawButton(graphics, contentX, y2, half, BUTTON_H,
                manual ? Component.literal("ADD MARK")
                        : Component.translatable("tvatech.tempad.delete"),
                hovered(mouseX, mouseY, contentX, y2, half, BUTTON_H), true);
        // Row 2 right: the close in the manual view; everywhere else it is
        // the TIME CELLS switch, which runs the next doorway red.
        drawButton(graphics, contentX + half + 4, y2, half, BUTTON_H,
                manual ? Component.translatable("tvatech.tempad.close")
                        : Component.translatable(cellMode
                                ? "tvatech.tempad.cells_on" : "tvatech.tempad.cells_off"),
                hovered(mouseX, mouseY, contentX + half + 4, y2, half, BUTTON_H), true);

        // Row 3: the one button that matters, full width.
        int y3 = y2 + BUTTON_H + 4;
        boolean canTravel = haveMark || manual || day < FIRST_DAY || atEndOfTime();
        drawButton(graphics, contentX, y3, contentW, BUTTON_H,
                Component.translatable("tvatech.tempad.travel"),
                hovered(mouseX, mouseY, contentX, y3, contentW, BUTTON_H), canTravel);
    }

    /**
     * The rename box, drawn over the mark list.
     *
     * <p>The whole list is replaced rather than the box floating on top of it,
     * because a half-covered list you are editing names in is just noise.</p>
     */
    private void drawRename(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.drawString(this.font, Component.translatable("tvatech.tempad.rename_prompt"),
                contentX, listY + 3, TEXT, false);

        if (nameBox != null) {
            if (nameBox.getValue().isEmpty()) {
                String was = selected >= 0 && selected < data.labels().size()
                        ? data.labels().get(selected) : "";
                graphics.drawString(this.font,
                        this.font.plainSubstrByWidth(was, contentW - 8),
                        contentX + 4, infoY + 13, 0xFF6A5335, false);
            }
            nameBox.render(graphics, mouseX, mouseY, partialTick);
        }

        int half = (contentW - 4) / 2;
        int okY = infoY + infoH + 4;
        drawButton(graphics, contentX, okY, half, BUTTON_H,
                Component.translatable("tvatech.tempad.confirm"),
                hovered(mouseX, mouseY, contentX, okY, half, BUTTON_H), true);
        drawButton(graphics, contentX + half + 4, okY, half, BUTTON_H,
                Component.translatable("gui.cancel"),
                hovered(mouseX, mouseY, contentX + half + 4, okY, half, BUTTON_H), true);
    }

    /**
     * True when the player is standing past the first hour.
     *
     * <p>Out there the marks are all in another dimension and useless, so the
     * only thing TRAVEL can do is bring you home. The button still works, and
     * the server is what actually decides.</p>
     */
    private boolean atEndOfTime() {
        var level = net.minecraft.client.Minecraft.getInstance().level;
        return level != null && com.tvatech.system.TemPadMenu.TVA.equals(level.dimension());
    }

    private boolean hovered(int mouseX, int mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void drawButton(GuiGraphics graphics, int x, int y, int w, int h,
                            Component label, boolean hover, boolean enabled) {
        graphics.fill(x, y, x + w, y + h, enabled ? (hover ? BUTTON_HOVER : BUTTON) : BUTTON_OFF);
        graphics.renderOutline(x, y, w, h, enabled ? SCREEN_EDGE : 0xFF2A3A40);
        int color = enabled ? (hover ? 0xFFFFFFFF : TEXT) : 0xFF5A6A70;
        graphics.drawString(this.font, label, x + 4, y + 3, color, false);
    }

    // ------------------------------------------------------------------
    // Input
    // ------------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        layout();
        int mx = (int) mouseX;
        int my = (int) mouseY;

        // The rename box swallows everything while it is open.
        if (renaming) {
            int half = (contentW - 4) / 2;
            int okY = infoY + infoH + 4;
            if (hovered(mx, my, contentX, okY, half, BUTTON_H)) {
                endRename(true);
                return true;
            }
            if (hovered(mx, my, contentX + half + 4, okY, half, BUTTON_H)
                    || hovered(mx, my, contentX + half + 4, buttonsY, half, BUTTON_H)) {
                endRename(false);
                return true;
            }
            if (nameBox != null) {
                nameBox.mouseClicked(mx, my, button);
            }
            return true;
        }

        if (manual) {
            // Buttons first - they sit below the boxes, so no overlap checks
            // are needed until one of them matches.
            if (clickButtons(mx, my)) {
                return true;
            }
            // Then the boxes: the box wins over any row it covers, since the
            // list is not even drawn here.
            if (xBox != null && xBox.mouseClicked(mx, my, button)) {
                xBox.setFocused(true); yBox.setFocused(false); zBox.setFocused(false); dimBox.setFocused(false);
                return true;
            }
            if (yBox != null && yBox.mouseClicked(mx, my, button)) {
                xBox.setFocused(false); yBox.setFocused(true); zBox.setFocused(false); dimBox.setFocused(false);
                return true;
            }
            if (zBox != null && zBox.mouseClicked(mx, my, button)) {
                xBox.setFocused(false); yBox.setFocused(false); zBox.setFocused(true); dimBox.setFocused(false);
                return true;
            }
            if (dimBox != null && dimBox.mouseClicked(mx, my, button)) {
                xBox.setFocused(false); yBox.setFocused(false); zBox.setFocused(false); dimBox.setFocused(true);
                return true;
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        if (clickButtons(mx, my)) {
            return true;
        }

        // mark rows
        int shown = Math.min(MAX_ROWS, data.labels().size());
        for (int i = 0; i < shown; i++) {
            int ry = listY + i * ROW_H;
            if (hovered(mx, my, contentX, ry, contentW, ROW_H)) {
                selected = scroll + i;
                return true;
            }
        }

        // arrival-time toggle (present / set time)
        if (hovered(mx, my, contentX + contentW - 62, arrivalY - 3, 62, BUTTON_H)) {
            useTime = !useTime;
            return true;
        }

        // The day and time dials only work in SET TIME mode. Day 0 is not a
        // floor: one step below it is not a day at all, it is the End of Time,
        // and that is exactly where pressing minus here should take you.
        if (useTime) {
            if (day > END_OF_TIME && hovered(mx, my, contentX + 22, dayRowY, STEP_W, BUTTON_H)) {
                day = day - 1;
                return true;
            }
            if (hovered(mx, my, contentX + 74, dayRowY, STEP_W, BUTTON_H)) {
                day = day + 1;
                return true;
            }
            if (hovered(mx, my, contentX + 30, timeRowY, STEP_W, BUTTON_H)) {
                stepTime(-1);
                return true;
            }
            if (hovered(mx, my, contentX + 120, timeRowY, STEP_W, BUTTON_H)) {
                stepTime(1);
                return true;
            }
        }

        if (clickButtons(mx, my)) {
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    /**
     * The four button rows, in one place for list and manual views.
     *
     * <p>Only when it swallowed a click does it say so.</p>
     */
    private boolean clickButtons(int mx, int my) {
        int half = (contentW - 4) / 2;
        int y2 = buttonsY + BUTTON_H + 4;
        int y3 = y2 + BUTTON_H + 4;

        if (hovered(mx, my, contentX, buttonsY, half, BUTTON_H)) {
            // The manual view's front door: turn it on anywhere, off while on.
            if (manual) {
                endManual(false);
            } else {
                beginManual();
            }
            return true;
        }
        if (manual && hovered(mx, my, contentX, y2, half, BUTTON_H)) {
            endManual(true);
            return true;
        }
        if (manual && hovered(mx, my, contentX + half + 4, y2, half, BUTTON_H)) {
            this.onClose();
            return true;
        }
        if (manual && hovered(mx, my, contentX, y3, contentW, BUTTON_H)) {
            // Travelling from the manual view submits the boxes first, so the
            // door opens at the typed spot - at the current time of day,
            // because the manual view has no history dial of its own.
            endManual(true);
            send(TvaNetwork.MENU_TRAVEL);
            this.onClose();
            return true;
        }

        boolean haveMark = selected >= 0 && selected < data.labels().size();
        if (!manual && hovered(mx, my, contentX, buttonsY, half, BUTTON_H)) {
            send(TvaNetwork.MENU_MAKE_MARK);
            return true;
        }
        if (!manual && selected >= 0 && hovered(mx, my, contentX + half + 4, buttonsY, half, BUTTON_H)) {
            beginRename();
            return true;
        }
        if (!manual && selected >= 0 && hovered(mx, my, contentX, y2, half, BUTTON_H)) {
            send(TvaNetwork.MENU_DELETE_MARK);
            selected = -1;
            scroll = 0;
            return true;
        }
        if (!manual && hovered(mx, my, contentX + half + 4, y2, half, BUTTON_H)) {
            // The TIME CELLS switch: the next door this TemPad opens runs red.
            cellMode = !cellMode;
            return true;
        }
        if (!manual && hovered(mx, my, contentX, y3, contentW, BUTTON_H)) {
            send(TvaNetwork.MENU_TRAVEL);
            this.onClose();
            return true;
        }
        return false;
    }

    /**
     * The wheel scrolls the mark list.
     *
     * <p>Only when the cursor is over the list, so the wheel does nothing
     * surprising while you are dialling in a day.</p>
     */
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        layout();
        int total = data.labels().size();
        if (total > MAX_ROWS
                && mouseX >= contentX && mouseX < contentX + contentW
                && mouseY >= listY && mouseY < listY + MAX_ROWS * ROW_H) {
            scroll -= (int) Math.signum(scrollY);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (renaming) {
            if (keyCode == com.mojang.blaze3d.platform.InputConstants.KEY_ESCAPE) {
                endRename(false);
                return true;
            }
            if (nameBox != null && nameBox.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }
            return true;
        }
        if (manual) {
            if (keyCode == com.mojang.blaze3d.platform.InputConstants.KEY_ESCAPE) {
                endManual(false);
                return true;
            }
            if (xBox != null && xBox.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }
            if (yBox != null && yBox.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }
            if (zBox != null && zBox.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }
            if (dimBox != null && dimBox.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (renaming && nameBox != null) {
            return nameBox.charTyped(codePoint, modifiers);
        }
        if (manual) {
            if (xBox != null && xBox.charTyped(codePoint, modifiers)) {
                return true;
            }
            if (yBox != null && yBox.charTyped(codePoint, modifiers)) {
                return true;
            }
            if (zBox != null && zBox.charTyped(codePoint, modifiers)) {
                return true;
            }
            if (dimBox != null && dimBox.charTyped(codePoint, modifiers)) {
                return true;
            }
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    private void send(int action) {
        send(action, "");
    }

    private void send(int action, String name) {
        int mx = 0;
        int my = 0;
        int mz = 0;
        String mdim = "";
        if (manual && xBox != null) {
            mx = parseIntOrZero(xBox.getValue());
            my = parseIntOrZero(yBox.getValue());
            mz = parseIntOrZero(zBox.getValue());
            mdim = dimBox != null ? dimBox.getValue().strip() : "";
        }
        TvaNetwork.sendToServer(new TvaNetwork.TemPadMenuActionPayload(
                action, selected, day, hour, useTime, name, mx, my, mz, mdim,
                cellMode));
    }

    /** A box that has not been typed into yet counts as zero. */
    private static int parseIntOrZero(String text) {
        try {
            return Integer.parseInt(text.strip());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** The dial moves in whole hours, wrapping around midnight. */
    private void stepTime(int hours) {
        hour = Math.floorMod(hour + hours, 24);
    }
}