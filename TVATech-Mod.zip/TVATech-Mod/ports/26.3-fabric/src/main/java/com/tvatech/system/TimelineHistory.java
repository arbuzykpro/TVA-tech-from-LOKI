package com.tvatech.system;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import com.tvatech.TvaConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Remembers how the world looked at every hour of the timeline.
 *
 * <p>Time travel is only fun if the past is actually there. Every block the
 * player changes is filed as one change record - {@code (hour, before, after)} -
 * and the world is rebuilt for an hour by replaying those records:</p>
 *
 * <ul>
 *   <li>The newest change on or before the hour you arrive on wins.</li>
 *   <li>If the moment predates every record for that spot, the block goes back to
 *       what it was <i>before</i> the first recorded change - which is how a
 *       build you knock down at 2 pm comes back when you drop to 10 am.</li>
 * </ul>
 *
 * <p>Only positions somebody actually changed are stored, so the cost is
 * proportional to what you built, not to the size of the world. Block states
 * are kept as their registry id (a single int), which makes the save file tiny.</p>
 */
public final class TimelineHistory extends SavedData {

    public TimelineHistory() {
    }

    public static final SavedDataType<TimelineHistory> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(com.tvatech.TVATech.MODID, "timeline_hourly"),
            TimelineHistory::new,
            Codec.STRING.xmap(TimelineHistory::fromJson, TimelineHistory::toJson),
            DataFixTypes.LEVEL);

    // ------------------------------------------------------------------
    // Storage
    // ------------------------------------------------------------------

    /**
     * One position's history: parallel arrays of hour, state-before and
     * state-after, kept sorted by hour and with at most one entry per hour.
     */
    private static final class Changes {
        long[] hours = new long[2];
        int[] before = new int[2];
        int[] after = new int[2];
        int size;

        void add(long hour, int from, int to) {
            // Same hour as the newest entry: that hour's final state replaces it.
            if (size > 0 && hours[size - 1] == hour) {
                after[size - 1] = to;
                return;
            }
            if (size == hours.length) {
                grow();
            }
            // Keep sorted: recordings normally arrive in order, but a jump can
            // interleave them.
            int at = size;
            while (at > 0 && hours[at - 1] > hour) {
                at--;
            }
            for (int i = size; i > at; i--) {
                hours[i] = hours[i - 1];
                before[i] = before[i - 1];
                after[i] = after[i - 1];
            }
            hours[at] = hour;
            before[at] = from;
            after[at] = to;
            size++;
        }

        private void grow() {
            int bigger = hours.length * 2;
            hours = java.util.Arrays.copyOf(hours, bigger);
            before = java.util.Arrays.copyOf(before, bigger);
            after = java.util.Arrays.copyOf(after, bigger);
        }

        /** The state to show at {@code hour}, or -1 when nothing is known. */
        int resolve(long hour) {
            if (size == 0) {
                return -1;
            }
            int newest = -1;
            for (int i = 0; i < size; i++) {
                if (hours[i] <= hour) {
                    newest = i;
                } else {
                    break;
                }
            }
            // Before anything was recorded by then, the spot held whatever
            // it held before the very first change.
            return newest < 0 ? before[0] : after[newest];
        }
    }

    private final Map<Long, Changes> changes = new HashMap<>();
    /** Positions grouped by chunk, so loading a chunk only walks its own blocks. */
    private final Map<ChunkPos, List<Long>> byChunk = new HashMap<>();
    /** Guards against a runaway world eating all memory. */
    private boolean full;

    public int size() {
        return changes.size();
    }

    private void index(BlockPos pos) {
        byChunk.computeIfAbsent(ChunkPos.containing(pos), key -> new ArrayList<>()).add(pos.asLong());
    }

    public boolean isFull() {
        return full;
    }

    /** Files one change. A no-op when the hour already shows that state. */
    public void record(long posKey, long hour, int fromState, int toState) {
        if (fromState == toState) {
            return;
        }
        Changes entry = changes.get(posKey);
        if (entry == null) {
            if (TvaConfig.timelineMaxEntries > 0 && changes.size() >= TvaConfig.timelineMaxEntries) {
                full = true;
                return;
            }
            entry = new Changes();
            changes.put(posKey, entry);
            index(BlockPos.of(posKey));
        }
        entry.add(hour, fromState, toState);
        setDirty();
    }

    /** The state this position shows on {@code hour}, or -1 if never touched. */
    public int resolve(long posKey, long hour) {
        Changes entry = changes.get(posKey);
        return entry == null ? -1 : entry.resolve(hour);
    }

    public boolean isTracked(long posKey) {
        return changes.containsKey(posKey);
    }

    // ------------------------------------------------------------------
    // Applying the timeline to the world
    // ------------------------------------------------------------------

    /**
     * Rebuilds the world as it was on {@code hour}.
     *
     * <p>Chunks that are not loaded are left alone; {@link #applyChunk} puts
     * them right when they come back in.</p>
     *
     * @return how many blocks actually changed
     */
    public int applyTo(ServerLevel level, long hour) {
        int changed = 0;
        for (Map.Entry<Long, Changes> entry : changes.entrySet()) {
            BlockPos pos = BlockPos.of(entry.getKey());
            if (!level.isLoaded(pos)) {
                continue;
            }
            if (applyOne(level, pos, entry.getValue().resolve(hour))) {
                changed++;
            }
        }
        return changed;
    }

    /** Same as {@link #applyTo} but limited to one chunk. */
    public int applyChunk(ServerLevel level, ChunkPos chunkPos, long hour) {
        List<Long> positions = byChunk.get(chunkPos);
        if (positions == null || positions.isEmpty()) {
            return 0;
        }
        if (!level.getChunkSource().hasChunk(chunkPos.x(), chunkPos.z())) {
            return 0;
        }
        int changed = 0;
        for (Long key : positions) {
            Changes entry = changes.get(key);
            if (entry == null) {
                continue;
            }
            BlockPos pos = BlockPos.of(key);
            if (!level.isLoaded(pos)) {
                continue;
            }
            if (applyOne(level, pos, entry.resolve(hour))) {
                changed++;
            }
        }
        return changed;
    }

    private static boolean applyOne(ServerLevel level, BlockPos pos, int stateId) {
        if (stateId < 0) {
            return false;
        }
        BlockState wanted = Block.stateById(stateId);
        BlockState live = level.getBlockState(pos);
        if (live == wanted) {
            return false;
        }
        // Flags 3: tell the client and run neighbour updates, so chests,
        // pistons and redstone all react to the rebuilt world.
        level.setBlock(pos, wanted, Block.UPDATE_ALL, 0);
        return true;
    }

    /**
     * Catches world changes that no place/break event reported - fire spread,
     * decay, pistons, fluids, other mods.
     */
    public int sweep(ServerLevel level, long hour) {
        int recorded = 0;
        for (Map.Entry<Long, Changes> entry : changes.entrySet()) {
            BlockPos pos = BlockPos.of(entry.getKey());
            if (!level.isLoaded(pos)) {
                continue;
            }
            int expected = entry.getValue().resolve(hour);
            int live = Block.getId(level.getBlockState(pos));
            if (expected != live) {
                record(entry.getKey(), hour, expected, live);
                recorded++;
            }
        }
        return recorded;
    }

    /** Test helper: how many positions are tracked inside a radius of a point. */
    public int trackedNear(BlockPos centre, int radius) {
        long r2 = (long) radius * radius;
        int count = 0;
        for (Long key : changes.keySet()) {
            BlockPos pos = BlockPos.of(key);
            long dx = pos.getX() - centre.getX();
            long dy = pos.getY() - centre.getY();
            long dz = pos.getZ() - centre.getZ();
            if (dx * dx + dy * dy + dz * dz <= r2) {
                count++;
            }
        }
        return count;
    }

    // ------------------------------------------------------------------
    // Saving
    // ------------------------------------------------------------------

    /**
     * Compact JSON: one line per tracked block, for example
     * {@code "128,71,-256": [[3,0,81],[7,81,0]]}.
     */
    public String toJson() {
        JsonArray list = new JsonArray();
        List<Map.Entry<Long, Changes>> entries = new ArrayList<>(changes.entrySet());
        for (Map.Entry<Long, Changes> entry : entries) {
            BlockPos pos = BlockPos.of(entry.getKey());
            Changes value = entry.getValue();
            JsonArray line = new JsonArray();
            line.add(pos.getX());
            line.add(pos.getY());
            line.add(pos.getZ());
            JsonArray records = new JsonArray();
            for (int i = 0; i < value.size; i++) {
                JsonArray record = new JsonArray();
                record.add(value.hours[i]);
                record.add(value.before[i]);
                record.add(value.after[i]);
                records.add(record);
            }
            line.add(records);
            list.add(line);
        }
        return list.toString();
    }

    public static TimelineHistory fromJson(String json) {
        TimelineHistory history = new TimelineHistory();
        if (json == null || json.isBlank()) {
            return history;
        }
        try {
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonArray()) {
                return history;
            }
            for (JsonElement lineElement : root.getAsJsonArray()) {
                JsonArray line = lineElement.getAsJsonArray();
                if (line.size() < 4) {
                    continue;
                }
                BlockPos pos = new BlockPos(line.get(0).getAsInt(), line.get(1).getAsInt(),
                        line.get(2).getAsInt());
                Changes entry = new Changes();
                for (JsonElement recordElement : line.get(3).getAsJsonArray()) {
                    JsonArray record = recordElement.getAsJsonArray();
                    if (record.size() < 3) {
                        continue;
                    }
                    entry.add(record.get(0).getAsLong(), record.get(1).getAsInt(),
                            record.get(2).getAsInt());
                }
                if (entry.size > 0) {
                    history.changes.put(pos.asLong(), entry);
                    history.index(pos);
                }
            }
        } catch (RuntimeException e) {
            // A corrupt save must not stop the world from loading.
            com.tvatech.TVATech.LOG.warn("TVA: could not read the block timeline, starting empty", e);
        }
        return history;
    }

    /** Heightmap helper kept for callers that want the surface of a column. */
    public static BlockPos surface(ServerLevel level, int x, int z) {
        return new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z);
    }
}
