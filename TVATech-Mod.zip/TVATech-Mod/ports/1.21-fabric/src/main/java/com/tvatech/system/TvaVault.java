package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * The Time Variance Authority.
 *
 * <p>The Vault under the city: a sealed brutalist administrative block with a
 * glazed atrium in the middle, four storeys of open-plan offices wrapped around
 * it, two scissor stairwells in opposite corners, a cafeteria, a records hall,
 * and underneath all of it the room with the button that resets everything.</p>
 *
 * <p>Getting around it is by stair and nothing else. Every storey is six blocks
 * high and every storey has a real, walkable route to the one below it: a pair
 * of half-turn stairwells in the north-east and south-west corners, and the two
 * monumental flights that climb the atrium. There are no lifts, which is both
 * how the building looks on television and very much in character.</p>
 *
 * <p>Built with ordinary block writes the first time anybody arrives. Nothing
 * here is meant to be dug through: the shell is solid to the roof, and the
 * world border is pulled in tight around it, so the only way out of this
 * dimension is the way it should be - a TemPad.</p>
 */
public final class TvaVault {

    private TvaVault() {}

    // ---- the shell -------------------------------------------------------

    /** The building's outer half-width. */
    public static final int R = 40;
    /** Half-width of the atrium void, which is open the full height. */
    public static final int ATRIUM = 14;
    /** The slab you arrive on. */
    public static final int FLOOR_Y = 12;
    /** Floor to floor. Six blocks, because a switchback needs the headroom. */
    public static final int STOREY = 6;
    /** The highest slab you can stand on. */
    public static final int TOP_Y = FLOOR_Y + STOREY * 3;
    /** The underside of the roof slab. */
    public static final int ROOF_Y = TOP_Y + 6;
    /** You arrive in the lobby, north of the reception desk. */
    public static final int ARRIVAL_Z = ATRIUM + 8;
    /** Below here is the sub-basement, and the button. */
    public static final int RESET_ROOM_Y = 2;
    /** How much room to leave outside the walls before the border stops you. */
    private static final int BORDER_MARGIN = 6;

    /** The two scissor stairwells: {min x, entry z}, {which way it climbs, 0}. */
    private static final int[][] STAIR_A = {{20, 17}, {1, 0}};
    private static final int[][] STAIR_B = {{-28, -17}, {-1, 0}};

    private static final BlockState WALL = Blocks.SMOOTH_QUARTZ.defaultBlockState();
    private static final BlockState WALL_IN = Blocks.QUARTZ_BRICKS.defaultBlockState();
    private static final BlockState SLAB = Blocks.SMOOTH_QUARTZ_SLAB.defaultBlockState();
    private static final BlockState FLOOR = Blocks.POLISHED_ANDESITE.defaultBlockState();
    private static final BlockState DECK = Blocks.SMOOTH_QUARTZ.defaultBlockState();
    private static final BlockState STAIR_N = Blocks.QUARTZ_STAIRS.defaultBlockState()
            .setValue(StairBlock.FACING, Direction.NORTH);
    private static final BlockState STAIR_S = Blocks.QUARTZ_STAIRS.defaultBlockState()
            .setValue(StairBlock.FACING, Direction.SOUTH);
    private static final BlockState AMBER = Blocks.ORANGE_STAINED_GLASS.defaultBlockState();
    private static final BlockState AMBER_LIT = Blocks.SEA_LANTERN.defaultBlockState();
    private static final BlockState GRAY = Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
    private static final BlockState DARK = Blocks.GRAY_CONCRETE.defaultBlockState();
    private static final BlockState BLACK = Blocks.BLACK_CONCRETE.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState CHAIN = Blocks.IRON_BARS.defaultBlockState();
    private static final BlockState REDSTONE = Blocks.REDSTONE_BLOCK.defaultBlockState();
    private static final BlockState REDSTONE_TORCH = Blocks.REDSTONE_TORCH.defaultBlockState();

    /** Marks the Vault as built so it is only ever done once. */
    private static final String KEY_BUILT = "tva_vault_built";

    /**
     * Builds the Vault if it is not there yet.
     *
     * @return true when something was actually built
     */
    public static boolean ensureBuilt(ServerLevel level, BlockPos centre) {
        var data = level.getDataStorage().computeIfAbsent(Marker.FACTORY, Marker.STORAGE_KEY);
        if (data.built && isStanding(level, centre)) {
            return false;
        }
        // A build that was interrupted - or one that ran before its chunks
        // existed - must not poison the dimension forever, so check the floor is
        // really there before trusting the flag.
        loadArea(level, centre, R + 8);
        build(level, centre);
        data.built = true;
        data.setDirty();
        level.getDataStorage().save();
        return true;
    }

    /** Is the Vault actually standing? One block on the arrival slab is enough. */
    private static boolean isStanding(ServerLevel level, BlockPos centre) {
        BlockPos probe = new BlockPos(centre.getX(), FLOOR_Y, centre.getZ() + ARRIVAL_Z);
        return level.isLoaded(probe) && level.getBlockState(probe).isSolidRender(level, probe);
    }

    /**
     * Makes sure every chunk the Vault needs is actually there.
     *
     * <p>Writes into a chunk that is not loaded are silently dropped, and at
     * server start none of these chunks exist yet - so the build would come out
     * as an empty sky.</p>
     */
    private static void loadArea(ServerLevel level, BlockPos centre, int radius) {
        int min = (centre.getX() - radius) >> 4;
        int max = (centre.getX() + radius) >> 4;
        int minZ = (centre.getZ() - radius) >> 4;
        int maxZ = (centre.getZ() + radius) >> 4;
        for (int cx = min; cx <= max; cx++) {
            for (int cz = minZ; cz <= maxZ; cz++) {
                level.getChunk(cx, cz);
            }
        }
    }

    /** A one-flag saved data, so the build happens exactly once per world. */
    private static final class Marker extends net.minecraft.world.level.saveddata.SavedData {
        static final String STORAGE_KEY = "tvatech_vault";
        static final SavedData.Factory<Marker> FACTORY = new SavedData.Factory<>(
                Marker::new,
                (tag, registries) -> {
                    Marker marker = new Marker();
                    marker.built = tag.getBoolean("built");
                    return marker;
                },
                net.minecraft.util.datafix.DataFixTypes.LEVEL);
        boolean built;

        @Override
        public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
            tag.putBoolean("built", built);
            return tag;
        }
    }

    // ------------------------------------------------------------------
    // The build
    // ------------------------------------------------------------------

    private static void build(ServerLevel level, BlockPos centre) {
        int x = centre.getX();
        int z = centre.getZ();

        // Nothing leaves this dimension on foot. The building is sealed and the
        // world border is pulled in tight around it, so the only way out is a
        // TemPad - which is the entire premise of the place.
        try {
            level.getWorldBorder().setSize((R + BORDER_MARGIN) * 2.0);
        } catch (RuntimeException e) {
            com.mojang.logging.LogUtils.getLogger()
                    .warn("TVA: could not set the world border: {}", e.toString());
        }

        shell(level, x, z);
        subBasement(level, x, z);
        floors(level, x, z);
        atriumStairs(level, x, z);
        atrium(level, x, z);
        stairwells(level, x, z);
        offices(level, x, z);
        pictures(level, x, z);
        entrance(level, x, z);
    }

    // ------------------------------------------------------------------
    // The shell - this is what stops you walking out
    // ------------------------------------------------------------------

    /**
     * Walls, roof and base slab.
     *
     * <p>Two blocks thick at the corners, closed on all four sides and roofed,
     * so you cannot walk out of it and nothing can dig through. Beyond that the
     * dimension is simply dark, and a world border at {@link #R} +
     * {@link #BORDER_MARGIN} means there is nowhere out there to walk to.</p>
     */
    private static void shell(ServerLevel level, int x, int z) {
        // Clear the inside first. The dimension generates its own terrain, and
        // without this the building comes out as a solid block of stone with a
        // few of our blocks showing through.
        fill(level, x - R + 1, 2, z - R + 1, x + R - 1, ROOF_Y - 1, z + R - 1, AIR);

        // Walls, base slab and roof.
        for (int dy = 1; dy <= ROOF_Y; dy++) {
            boolean roof = dy == ROOF_Y;
            for (int dx = -R; dx <= R; dx++) {
                for (int dz = -R; dz <= R; dz++) {
                    boolean wall = Math.abs(dx) == R || Math.abs(dz) == R;
                    if (!wall && !roof && dy != 1) {
                        continue;
                    }
                    boolean corner = Math.abs(dx) == R && Math.abs(dz) == R;
                    set(level, x + dx, dy, z + dz,
                            roof && !wall ? SLAB : dy == 1 ? FLOOR : corner ? WALL : WALL_IN);
                }
            }
        }
        facade(level, x, z);
    }

    /**
     * The outside face.
     *
     * <p>The Authority's building is a slab of pale stone with deep vertical
     * ribs and a band of amber glazing at every storey. It reads as a very
     * large, very serious office block from the outside, which is the point.</p>
     */
    private static void facade(ServerLevel level, int x, int z) {
        for (int dy = 2; dy <= TOP_Y; dy++) {
            // A band of glazing on each storey, set back from the ground floor
            // so the base of the building stays solid stone.
            boolean glazing = false;
            for (int y0 = FLOOR_Y; y0 <= TOP_Y; y0 += STOREY) {
                if (dy >= y0 + 3 && dy <= y0 + 4) {
                    glazing = true;
                }
            }
            for (int dx = -R; dx <= R; dx++) {
                for (int dz = -R; dz <= R; dz++) {
                    boolean edgeX = Math.abs(dx) == R;
                    boolean edgeZ = Math.abs(dz) == R;
                    if ((!edgeX && !edgeZ) || (edgeX && edgeZ)) {
                        continue;
                    }
                    int along = edgeX ? dz : dx;
                    // A rib every four blocks, standing proud of the wall.
                    boolean rib = ((along + R) % 4) == 0;
                    if (glazing && !rib) {
                        set(level, x + dx, dy, z + dz, AMBER);
                    } else if (rib) {
                        set(level, x + dx, dy, z + dz, WALL);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Below ground
    // ------------------------------------------------------------------

    /**
     * The sub-basement.
     *
     * <p>One room, kept deliberately plain, with the reset lever in the middle
     * of it on a pedestal of chronovium. It is lit, and there is a proper stair
     * up the side back to the ground floor.</p>
     */
    private static void subBasement(ServerLevel level, int x, int z) {
        int y = RESET_ROOM_Y;
        int s = 20;

        box(level, x - s, y, z - s, x + s, y, z + s, FLOOR);
        box(level, x - s, y, z - s, x - s + 1, y + 7, z + s, WALL_IN);
        box(level, x + s - 1, y, z - s, x + s, y + 7, z + s, WALL_IN);
        box(level, x - s, y, z - s, x + s, y + 7, z - s + 1, WALL_IN);
        box(level, x - s, y, z + s - 1, x + s, y + 7, z + s, WALL_IN);
        // The ceiling, with the stairwell punched through it.
        box(level, x - s, y + 7, z - s, x + s, y + 7, z + s, SLAB);
        box(level, x + 13, y + 7, z - 19, x + 18, y + 7, z - 6, AIR);

        // Lighting: cold, institutional, not amber. This is not the lobby.
        for (int i = -16; i <= 16; i += 8) {
            for (int dz : new int[]{-16, 16}) {
                set(level, x + i, y + 6, z + dz,
                        Blocks.GRAY_STAINED_GLASS_PANE.defaultBlockState());
                set(level, x + dz, y + 6, z + i,
                        Blocks.GRAY_STAINED_GLASS_PANE.defaultBlockState());
            }
        }

        // The pedestal, and the lever on it.
        box(level, x - 3, y + 1, z - 3, x + 3, y + 2, z + 3, BLACK);
        set(level, x, y + 3, z, com.tvatech.ModContent.CHRONOVIUM_BLOCK.get().defaultBlockState());
        set(level, x, y + 4, z, REDSTONE);
        set(level, x, y + 5, z, REDSTONE_TORCH);
        // Two chains running up into the dark, because someone has to hold it.
        for (int dz = -2; dz <= 2; dz += 4) {
            for (int dy = 6; dy <= 7; dy++) {
                set(level, x, y + dy, z + dz, CHAIN);
            }
        }

        // A real stair up to the ground floor: nine treads climbing north.
        for (int k = 0; k <= 8; k++) {
            box(level, x + 14, y + 1 + k, z - 18 + k, x + 17, y + 1 + k, z - 18 + k, STAIR_N);
        }

        // One bench, because somebody sat here a very long time.
        set(level, x - 8, y + 1, z, Blocks.DARK_OAK_SLAB.defaultBlockState());
        set(level, x - 8, y + 2, z, Blocks.DARK_OAK_SLAB.defaultBlockState());
    }

    // ------------------------------------------------------------------
    // The floors
    // ------------------------------------------------------------------

    /**
     * Every storey: a slab, a balcony round the atrium, and a hole where the
     * two corner stairwells come through.
     */
    private static void floors(ServerLevel level, int x, int z) {
        for (int y = FLOOR_Y; y <= TOP_Y; y += STOREY) {
            for (int dx = -R + 1; dx <= R - 1; dx++) {
                for (int dz = -R + 1; dz <= R - 1; dz++) {
                    if (inAtrium(dx, dz) && y > FLOOR_Y) {
                        continue;
                    }
                    if (inWell(dx, dz) || inBasementShaft(dx, dz)) {
                        continue;
                    }
                    boolean walkway = Math.abs(dx) <= ATRIUM + 2 || Math.abs(dz) <= ATRIUM + 2;
                    set(level, x + dx, y, z + dz, walkway ? DECK : FLOOR);
                }
            }
            // A railing round the atrium so you do not walk off the edge. The
            // gaps at each end are where the monumental flights land.
            for (int dx = -ATRIUM - 1; dx <= ATRIUM + 1; dx++) {
                for (int dz = -ATRIUM - 1; dz <= ATRIUM + 1; dz++) {
                    boolean onEdge = dx == -ATRIUM - 1 || dx == ATRIUM + 1
                            || dz == -ATRIUM - 1 || dz == ATRIUM + 1;
                    if (!onEdge) {
                        continue;
                    }
                    if (Math.abs(dx) == ATRIUM + 1 && Math.abs(dz) == ATRIUM + 1) {
                        continue;
                    }
                    // Leave a landing where the atrium stairs arrive.
                    if (y > FLOOR_Y && landingGap(dx, dz)) {
                        continue;
                    }
                    // The ground floor's south side is the way in from the
                    // lobby, so there is no railing across the doorway.
                    if (y == FLOOR_Y && dz == ATRIUM + 1) {
                        continue;
                    }
                    set(level, x + dx, y + 1, z + dz, Blocks.IRON_BARS.defaultBlockState());
                }
            }
        }
    }

    private static boolean inAtrium(int dx, int dz) {
        return Math.abs(dx) <= ATRIUM && Math.abs(dz) <= ATRIUM;
    }

    /** Where the two atrium flights meet the balcony: z of each bridge. */
    private static final int[] LANDING_EAST = {-7, -1, 5};
    private static final int[] LANDING_WEST = {7, 1, -5};

    private static boolean landingGap(int dx, int dz) {
        for (int z : LANDING_EAST) {
            if (dz == z && dx >= ATRIUM + 1 && dx <= ATRIUM + 2) {
                return true;
            }
        }
        for (int z : LANDING_WEST) {
            if (dz == z && dx <= -ATRIUM - 1 && dx >= -ATRIUM - 2) {
                return true;
            }
        }
        return false;
    }

    /** The hole in the ground floor the sub-basement stair comes up through. */
    private static boolean inBasementShaft(int dx, int dz) {
        return dx >= 14 && dx <= 17 && dz >= -19 && dz <= -10;
    }

    private static boolean inWell(int dx, int dz) {
        return inWell(dx, dz, STAIR_A) || inWell(dx, dz, STAIR_B);
    }

    /** The well is nine wide and eleven deep; it may run either way in z. */
    private static boolean inWell(int dx, int dz, int[][] well) {
        int x0 = well[0][0];
        int wz = well[0][1];
        int zEnd = wz + well[1][0] * 10;
        return dx >= x0 && dx <= x0 + 8 && dz >= Math.min(wz, zEnd) && dz <= Math.max(wz, zEnd);
    }

    // ------------------------------------------------------------------
    // The atrium
    // ------------------------------------------------------------------

    /**
     * The middle of the building, glazed the whole way up.
     *
     * <p>This is the bit people photograph, so it gets the treatment: a brass
     * compass rose set into the ground floor, the Authority's mark cut out of
     * amber on the end wall, and four tall window panels running floor to
     * roof. Above the ground floor it is an open void, with the balconies and
     * the two big flights hanging in it.</p>
     */
    private static void atrium(ServerLevel level, int x, int z) {
        // The compass rose, laid into the ground floor. Solid all the way, so
        // you can walk across it rather than fall through the glazing.
        for (int dx = -ATRIUM; dx <= ATRIUM; dx++) {
            for (int dz = -ATRIUM; dz <= ATRIUM; dz++) {
                int d = Math.max(Math.abs(dx), Math.abs(dz));
                boolean diagonal = Math.abs(Math.abs(dx) - Math.abs(dz)) <= 1;
                boolean cross = dx == 0 || dz == 0;
                if (!diagonal && !cross) {
                    continue;
                }
                set(level, x + dx, FLOOR_Y, z + dz, AMBER_LIT);
            }
        }

        // Glazing, floor to roof. The east and west walls carry the bridges, so
        // they leave those openings clear. The south side is the way in from
        // the lobby and is left open on the ground floor - glaze it and the
        // bottom of the stairs is a sealed box nobody can reach.
        for (int y = FLOOR_Y; y <= TOP_Y; y++) {
            for (int dz = -ATRIUM; dz <= ATRIUM; dz++) {
                for (int dx : new int[]{-ATRIUM, ATRIUM}) {
                    if (bridgeKeep(dx, dz)) {
                        continue;
                    }
                    set(level, x + dx, y, z + dz, AMBER);
                }
            }
            // North wall, glazed the whole way: the V is cut into it.
            for (int dx = -ATRIUM; dx <= ATRIUM; dx++) {
                if (!bridgeKeep(dx, -ATRIUM)) {
                    set(level, x + dx, y, z - ATRIUM, AMBER);
                }
            }
            // South wall, glazed above the ground floor only.
            if (y > FLOOR_Y + 1) {
                for (int dx = -ATRIUM; dx <= ATRIUM; dx++) {
                    if (!bridgeKeep(dx, ATRIUM)) {
                        set(level, x + dx, y, z + ATRIUM, AMBER);
                    }
                }
            }
        }

        // The Authority's mark on the end wall: a V cut out of amber.
        int wallZ = z - ATRIUM;
        for (int y = FLOOR_Y + 4; y <= FLOOR_Y + 14; y++) {
            int spread = (y - (FLOOR_Y + 4)) / 2;
            for (int dx = -spread; dx <= spread; dx++) {
                set(level, x + dx, y, wallZ, AMBER_LIT);
            }
        }
        for (int dx = -6; dx <= 6; dx++) {
            set(level, x + dx, FLOOR_Y + 16, wallZ, AMBER);
        }

        // Amber uplighters on the ground floor, all the way round. The doorway
        // on the south side is left clear.
        for (int i = -ATRIUM + 2; i <= ATRIUM - 2; i += 4) {
            for (int dx : new int[]{-ATRIUM + 1, ATRIUM - 1}) {
                set(level, x + dx, FLOOR_Y + 1, z + i, AMBER_LIT);
            }
            for (int dz : new int[]{-ATRIUM + 1}) {
                set(level, x + i, FLOOR_Y + 1, z + dz, AMBER_LIT);
            }
        }
    }

    /**
     * The two monumental flights that climb the atrium.
     *
     * <p>Six wide, running the length of the void, one on each side, climbing
     * south and north respectively. They are the reason the atrium is a void
     * rather than a stack of floors, and they land on the balcony at every
     * storey through a short bridge.</p>
     */
    private static void atriumStairs(ServerLevel level, int x, int z) {
        // Open the void first. This has to happen before anything is built
        // into it, or it clears away the very treads it is meant to sit under.
        for (int y = FLOOR_Y + STOREY; y <= TOP_Y; y += STOREY) {
            for (int dx = -ATRIUM; dx <= ATRIUM; dx++) {
                for (int dz = -ATRIUM; dz <= ATRIUM; dz++) {
                    set(level, x + dx, y, z + dz, AIR);
                }
            }
        }

        // East flight: six wide, climbing north (+z) from the ground floor. The
        // first tread sits clear of the north wall so you can actually board it.
        for (int k = 0; k <= TOP_Y - FLOOR_Y - 1; k++) {
            int stepY = FLOOR_Y + 1 + k;
            int stepZ = -ATRIUM + 2 + k;
            box(level, x + 6, stepY, z + stepZ, x + 11, stepY, z + stepZ, STAIR_N);
            // A bridge onto the balcony wherever this flight crosses a storey.
            if (stepY % STOREY == 0 && stepY > FLOOR_Y) {
                box(level, x + 12, stepY, z + stepZ, x + ATRIUM + 2, stepY,
                        z + stepZ, DECK);
            }
        }

        // West flight: the same, mirrored, climbing south (-z).
        for (int k = 0; k <= TOP_Y - FLOOR_Y - 1; k++) {
            int stepY = FLOOR_Y + 1 + k;
            int stepZ = ATRIUM - 2 - k;
            box(level, x - 11, stepY, z + stepZ, x - 6, stepY, z + stepZ, STAIR_S);
            if (stepY % STOREY == 0 && stepY > FLOOR_Y) {
                box(level, x - ATRIUM - 2, stepY, z + stepZ, x - 12, stepY,
                        z + stepZ, DECK);
            }
        }
    }

    /** The whole span of a bridge, not just the gap in the railing. */
    private static boolean bridgeKeep(int dx, int dz) {
        for (int z : LANDING_EAST) {
            if (dz == z && dx >= ATRIUM - 2 && dx <= ATRIUM + 2) {
                return true;
            }
        }
        for (int z : LANDING_WEST) {
            if (dz == z && dx <= -ATRIUM + 2 && dx >= -ATRIUM - 2) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // The stairwells
    // ------------------------------------------------------------------

    /**
     * A scissor stair in each of two opposite corners.
     *
     * <p>Each storey gets a half-turn: a flight of three treads climbing north
     * up the west half of the well, a landing at the far end, then a flight of
     * three climbing south up the east half, arriving at the storey above on
     * the corridor side. Six blocks of floor to floor is what makes that fit -
     * the two flights of one storey never end up under the two flights of the
     * next.</p>
     */
    private static void stairwells(ServerLevel level, int x, int z) {
        for (int y = FLOOR_Y; y < TOP_Y; y += STOREY) {
            stairwell(level, x, y, z, STAIR_A);
            stairwell(level, x, y, z, STAIR_B);
        }
    }

    private static void stairwell(ServerLevel level, int x, int y, int z, int[][] well) {
        int wx = well[0][0];
        int wz = well[0][1];
        int dir = well[1][0];

        // Lower landing, open to the corridor.
        box(level, x + wx, y, z + t(wz, dir, 0), x + wx + 8, y, z + t(wz, dir, 4), DECK);
        // Flight one: three treads climbing away from the corridor, west half.
        for (int k = 1; k <= 3; k++) {
            int zz = t(wz, dir, 4 + k);
            box(level, x + wx, y + k, z + zz, x + wx + 3, y + k, z + zz, STAIR_N);
        }
        // Half-landing at the far end.
        box(level, x + wx, y + 3, z + t(wz, dir, 7), x + wx + 8, y + 3,
                z + t(wz, dir, 10), DECK);
        // Flight two: three treads climbing back, east half.
        for (int k = 1; k <= 3; k++) {
            int zz = t(wz, dir, 9 - k);
            box(level, x + wx + 5, y + 3 + k, z + zz, x + wx + 8, y + 3 + k, z + zz, STAIR_S);
        }
        // The bridge across to the landing of the storey above.
        int bridge = t(wz, dir, 5);
        box(level, x + wx + 5, y + 6, z + bridge, x + wx + 8, y + 6, z + bridge, DECK);
    }

    /** Distance {@code d} along the well's axis, in whichever way it runs. */
    private static int t(int wz, int dir, int d) {
        return wz + dir * d;
    }

    // ------------------------------------------------------------------
    // The offices
    // ------------------------------------------------------------------

    /**
     * Cubicles and terminal banks, on every floor.
     *
     * <p>Done as one long band per side with regular partitions and a terminal
     * on every desk, which is what the floors of the Vault actually look like.
     * The corridors run round the atrium and past the stairwells.</p>
     */
    private static void offices(ServerLevel level, int x, int z) {
        for (int y = FLOOR_Y; y <= TOP_Y; y += STOREY) {
            officeBand(level, x, y, z, 1);
            officeBand(level, x, y, z, -1);
            officeBand(level, x, y, z, 2);
            officeBand(level, x, y, z, -2);
        }

        // The cafeteria, on the second floor, north-west corner.
        cafeteria(level, x, FLOOR_Y + STOREY, z);

        // Records: a tall hall of shelves, ground floor, south-east corner.
        records(level, x, FLOOR_Y, z);
    }

    /** Cubicles along one side of the building. */
    private static void officeBand(ServerLevel level, int x, int y, int z, int side) {
        boolean alongX = side == 1 || side == -1;
        int inner = ATRIUM + 3;
        int outer = R - 2;

        if (alongX) {
            int dz = side * (inner + 1);
            for (int dx = -outer; dx <= outer; dx++) {
                if (Math.abs(dx) > outer || inWell(dx, dz)) {
                    continue;
                }
                if ((dx + outer) % 8 == 0) {
                    for (int dy = 1; dy <= 3; dy++) {
                        set(level, x + dx, y + dy, z + dz, GRAY);
                    }
                }
                if ((dx + outer) % 4 == 2 && !inWell(dx, dz - side)) {
                    set(level, x + dx, y + 1, z + dz - side,
                            com.tvatech.ModContent.COMPUTER.get().defaultBlockState());
                }
                if ((dx + outer) % 8 == 5 && !inWell(dx, dz)) {
                    set(level, x + dx, y + 4, z + dz, AMBER_LIT);
                }
            }
        } else {
            int dx = side * (inner + 1);
            for (int dz = -outer; dz <= outer; dz++) {
                if (inWell(dx, dz)) {
                    continue;
                }
                if ((dz + outer) % 8 == 0) {
                    for (int dy = 1; dy <= 3; dy++) {
                        set(level, x + dx, y + dy, z + dz, GRAY);
                    }
                }
                if ((dz + outer) % 4 == 2 && !inWell(dx - side, dz)) {
                    set(level, x + dx - side, y + 1, z + dz,
                            com.tvatech.ModContent.COMPUTER.get().defaultBlockState());
                }
                if ((dz + outer) % 8 == 5 && !inWell(dx, dz)) {
                    set(level, x + dx, y + 4, z + dz, AMBER_LIT);
                }
            }
        }
    }

    /** Long tables, a servery, and nobody in it. */
    private static void cafeteria(ServerLevel level, int x, int y, int z) {
        int cx = x - 14;
        int cz = z - 30;

        for (int dz = 4; dz <= 24; dz += 5) {
            for (int dx = 4; dx <= 20; dx += 6) {
                box(level, cx + dx, y + 1, cz + dz, cx + dx + 4, y + 1, cz + dz + 2,
                        Blocks.SPRUCE_PLANKS.defaultBlockState());
                set(level, cx + dx + 2, y + 1, cz + dz + 1, Blocks.CANDLE.defaultBlockState());
                set(level, cx + dx, y + 1, cz + dz + 2, Blocks.SPRUCE_STAIRS.defaultBlockState());
                set(level, cx + dx + 4, y + 1, cz + dz + 2, Blocks.SPRUCE_STAIRS.defaultBlockState());
            }
        }
        box(level, cx + 2, y + 1, cz + 1, cx + 22, y + 2, cz + 3,
                Blocks.SMOOTH_QUARTZ.defaultBlockState());
        for (int dx = 3; dx <= 21; dx += 3) {
            set(level, cx + dx, y + 3, cz + 2, Blocks.IRON_TRAPDOOR.defaultBlockState());
        }
    }

    /** A hall of shelves, floor to ceiling, packed. */
    private static void records(ServerLevel level, int x, int y, int z) {
        for (int dz = 20; dz <= 34; dz += 4) {
            for (int dy = 1; dy <= 7; dy++) {
                set(level, x + 34, y + dy, z + dz, Blocks.BOOKSHELF.defaultBlockState());
            }
            set(level, x + 34, y + 8, z + dz, AMBER_LIT);
        }
    }

    // ------------------------------------------------------------------
    // The entrance
    // ------------------------------------------------------------------

    /**
     * The lobby you arrive in: a reception desk, a big TVA sign, and the top
     * of the stair down to the sub-basement.
     */
    private static void entrance(ServerLevel level, int x, int z) {
        int y = FLOOR_Y;

        // Reception desk, facing the atrium.
        box(level, x - 8, y + 1, z + ATRIUM + 5, x + 8, y + 2, z + ATRIUM + 6,
                Blocks.POLISHED_BLACKSTONE.defaultBlockState());
        set(level, x, y + 3, z + ATRIUM + 5,
                com.tvatech.ModContent.COMPUTER.get().defaultBlockState());
        set(level, x + 3, y + 3, z + ATRIUM + 5,
                com.tvatech.ModContent.CONSOLE.get().defaultBlockState());

        // The sign above it: T V A in amber.
        for (int dy = 4; dy <= 6; dy++) {
            for (int dx = -9; dx <= 9; dx++) {
                if (Math.abs(dx) == 9 || Math.abs(dx) == 3 || dx == 0) {
                    set(level, x + dx, y + dy, z + ATRIUM + 3, AMBER_LIT);
                }
            }
        }
    }

    /**
     * Framed diagrams on the balcony walls.
     *
     * <p>They sit flush in the amber glass panels, two rows high, so there is
     * something to actually read while you walk round the middle of the
     * building: the mark, a plan of the Vault, the TemPad, the lever, a
     * timeline, and the motto.</p>
     */
    private static void pictures(ServerLevel level, int x, int z) {
        BlockState picture = com.tvatech.ModContent.TVA_PICTURE.get().defaultBlockState();
        int[] arts = {0, 1, 2, 3, 4, 5};

        for (int row = 0; row < 2; row++) {
            int y = FLOOR_Y + 2 + row * 3;
            for (int i = 0; i < 3; i++) {
                int dz = -10 + i * 10;
                set(level, x + ATRIUM, y, z + dz, picture.setValue(
                        com.tvatech.block.TvaPictureBlock.ART, arts[i]));
                set(level, x - ATRIUM, y, z + dz, picture.setValue(
                        com.tvatech.block.TvaPictureBlock.ART, arts[arts.length - 1 - i]));
            }
            set(level, x - 10, y, z - ATRIUM, picture.setValue(
                    com.tvatech.block.TvaPictureBlock.ART, arts[0]));
            set(level, x + 10, y, z - ATRIUM, picture.setValue(
                    com.tvatech.block.TvaPictureBlock.ART, arts[5]));
        }
    }

    // ------------------------------------------------------------------
    // Block writes
    // ------------------------------------------------------------------

    private static void box(ServerLevel level, int x0, int y0, int z0,
            int x1, int y1, int z1, BlockState state) {
        for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
            for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) {
                    set(level, x, y, z, state);
                }
            }
        }
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlockAndUpdate(new BlockPos(x, y, z), state);
    }

    /**
     * A bulk fill with neighbour updates suppressed.
     *
     * <p>Clearing the inside of the building is a quarter of a million blocks
     * and nothing is listening yet, so the updates are pure cost.</p>
     */
    private static void fill(ServerLevel level, int x0, int y0, int z0,
            int x1, int y1, int z1, BlockState state) {
        int flags = net.minecraft.world.level.block.Block.UPDATE_CLIENTS;
        for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
            for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) {
                    level.setBlock(new BlockPos(x, y, z), state, flags);
                }
            }
        }
    }
}
