package com.tvatech.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import com.tvatech.ModContent;
import com.tvatech.TvaMessages;
import com.tvatech.block.TimedoorFieldBlock;
import com.tvatech.util.TvaFeedback;

/**
 * Time doors you can walk through.
 *
 * <p>Pressing TRAVEL does not blink you anywhere. The TemPad builds a real
 * doorway out of real blocks a few paces in front of you, and it stands open for
 * ten seconds. Walk into it and you travel; stand still and it closes again on
 * its own.</p>
 *
 * <p>Every door is a session: where it was built, where it is going, and how
 * far through its own life it is. Sessions tick once per server tick, which is
 * what lets the doorway ripple, notice the player walking into it, and shut
 * itself afterwards without anybody having to remember it.</p>
 */
public final class TimedoorPortal {

    private TimedoorPortal() {}

    /** How long a door stays open, in ticks. Ten seconds. */
    public static final int LIFETIME = 200;

    /** Ticks the doorway takes to draw itself in. */
    private static final int OPEN_ANIM = 12;
    /** Ticks the doorway takes to fall apart again. */
    private static final int CLOSE_ANIM = 14;
    /** Ticks between frames of the swirl. */
    private static final int FRAME_TICKS = 2;

    /** The doorway is this many blocks across and tall. */
    private static final int WIDTH = 3;
    private static final int HEIGHT = 4;

    /** How far in front of the player the door would like to stand. */
    private static final int IDEAL_DISTANCE = 3;

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    /** Where walking through a door takes you. */
    public record Destination(ServerLevel level, BlockPos pos, long day, int hour,
                              boolean useTime, boolean tva, boolean cell) {

        public static Destination to(ServerLevel level, BlockPos pos) {
            return new Destination(level, pos.immutable(), 0, 0, false, false, false);
        }

        public static Destination timed(ServerLevel level, BlockPos pos,
                                        long day, int hour) {
            return new Destination(level, pos.immutable(), day, hour, true, false, false);
        }

        public static Destination toTva() {
            return new Destination(null, new BlockPos(0, 0, 0), 0, 0, false, true, false);
        }

        /** The same trip, run as a time cell - the red trap doorway. */
        public Destination withCell() {
            return new Destination(level, pos, day, hour, useTime, tva, true);
        }
    }

    // ------------------------------------------------------------------
    // The session
    // ------------------------------------------------------------------

    /** One open doorway, and where walking into it takes you. */
    private static final class Session {
        final UUID playerId;
        /** The traveller. Held directly, so a door never depends on a lookup. */
        final ServerPlayer player;
        final ServerLevel origin;
        /** Bottom-centre of the field, the block the door is built around. */
        final BlockPos base;
        final Direction facing;
        /** Every field block, ordered middle outwards. */
        final List<BlockPos> field = new ArrayList<>();
        /** The surround. */
        final List<BlockPos> frame = new ArrayList<>();
        final Destination destination;
        /** True when this doorway runs red: a time cell trap. */
        final boolean cell;

        int age;
        boolean closing;
        int frameIndex;
        int sinceFrame;

        Session(ServerPlayer player, ServerLevel origin, BlockPos base, Direction facing,
                Destination destination) {
            this.playerId = player.getUUID();
            this.player = player;
            this.origin = origin;
            this.base = base.immutable();
            this.facing = facing;
            this.destination = destination;
            this.cell = destination.cell();

            Direction right = facing.getClockWise();
            int midX = (WIDTH - 1) / 2;

            for (int y = 0; y < HEIGHT; y++) {
                for (int x = 0; x < WIDTH; x++) {
                    BlockPos pos = new BlockPos(base.getX(), base.getY() + y, base.getZ())
                            .relative(right, x - midX);
                    field.add(pos.immutable());
                }
            }
            // Middle first, so the door draws itself in and falls apart from
            // the edges.
            field.sort((a, b) -> Integer.compare(ring(a), ring(b)));

            for (int y = -1; y <= HEIGHT; y++) {
                for (int x = -1; x <= WIDTH; x++) {
                    boolean border = x == -1 || x == WIDTH || y == -1 || y == HEIGHT;
                    if (!border) {
                        continue;
                    }
                    frame.add(new BlockPos(base.getX(), base.getY() + y, base.getZ())
                            .relative(right, x - midX).immutable());
                }
            }
        }

        /** How far a block is from the middle of the doorway. */
        private int ring(BlockPos pos) {
            return Math.abs(pos.getY() - base.getY()) * 2
                    + Math.abs(pos.getX() - base.getX()) + Math.abs(pos.getZ() - base.getZ());
        }

        /** Where the door is in its own life. */
        int phase() {
            return closing ? Math.max(0, age - OPEN_ANIM) : age;
        }
    }

    // ------------------------------------------------------------------
    // Opening
    // ------------------------------------------------------------------

    /**
     * Builds a doorway in front of the player.
     *
     * @return true if a door went up, false if there was no room for one
     */
    public static boolean open(ServerPlayer player, Destination destination) {
        // Building a door means reaching for the TemPad again; that is the
        // one gesture a time cell respects, so it lets its prisoner go.
        TimeCells.release(player.getUUID());
        ServerLevel level = player.serverLevel();
        close(player, false);

        BlockPos base = findRoom(player, level);
        if (base == null) {
            return false;
        }

        Session session = new Session(player, level, base,
                player.getDirection(), destination);
        SESSIONS.put(player.getUUID(), session);

        // A short charge, so the door hums to life rather than simply appearing.
        level.playSound(null, base, SoundEvents.RESPAWN_ANCHOR_CHARGE,
                SoundSource.PLAYERS, 0.6F, 1.4F);
        level.playSound(null, base, SoundEvents.BEACON_POWER_SELECT,
                SoundSource.PLAYERS, 0.7F, 1.7F);

        TvaFeedback.actionBar(player, TvaMessages.doorOpened(LIFETIME / 20));
        return true;
    }

    /** The first clear spot in front of the player that fits a whole doorway. */
    private static BlockPos findRoom(ServerPlayer player, ServerLevel level) {
        Direction facing = player.getDirection();
        for (int distance = IDEAL_DISTANCE; distance >= 1; distance--) {
            BlockPos stand = player.blockPosition().relative(facing, distance);
            if (clear(level, stand)) {
                return stand.immutable();
            }
        }
        return null;
    }

    /** Is there room for a doorway plus its surround, and nothing to destroy? */
    private static boolean clear(ServerLevel level, BlockPos base) {
        for (int y = -1; y <= HEIGHT; y++) {
            for (int x = -1; x <= WIDTH; x++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos pos = new BlockPos(base.getX() + x, base.getY() + y, base.getZ() + z);
                    if (!level.isLoaded(pos)) {
                        return false;
                    }
                    BlockState state = level.getBlockState(pos);
                    if (!state.isAir() && !state.getFluidState().isEmpty()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------
    // Ticking
    // ------------------------------------------------------------------

    /** Called once per server tick. */
    public static void tick(MinecraftServer server) {
        if (SESSIONS.isEmpty()) {
            return;
        }
        for (Session session : new ArrayList<>(SESSIONS.values())) {
            ServerPlayer player = session.player;
            if (!player.isAlive() || player.level() != session.origin) {
                // Died or left the dimension: the door has nobody to hold it
                // open. A disconnect is handled by the logout hook, because a
                // disconnected player object is still perfectly alive.
                remove(session);
                continue;
            }
            step(session, player);
        }
    }

    private static void step(Session session, ServerPlayer player) {
        session.age++;
        animate(session);

        if (session.closing) {
            if (session.phase() >= CLOSE_ANIM) {
                SESSIONS.remove(session.playerId);
                tearDown(session);
            }
            return;
        }

        stepMobs(session);

        if (inside(session, player)) {
            // Taken. Shutter the doorway behind them and go.
            session.closing = true;
            session.age = OPEN_ANIM;
            depart(session, player);
            return;
        }

        if (session.age >= LIFETIME) {
            session.closing = true;
            session.age = OPEN_ANIM;
            TvaFeedback.actionBar(player, TvaMessages.doorExpired());
        }
    }

    /** Ripples the field, and draws it in or takes it apart. */
    private static void animate(Session session) {
        int phase = session.phase();
        boolean closing = session.closing;

        if (++session.sinceFrame >= FRAME_TICKS) {
            session.sinceFrame = 0;
            session.frameIndex = (session.frameIndex + 1) % 8;
        }
        BlockState field = ModContent.TIMEDOOR_FIELD.get().defaultBlockState()
                .setValue(TimedoorFieldBlock.FRAME, session.frameIndex)
                .setValue(TimedoorFieldBlock.CELL, session.cell);

        // How many field blocks are standing this tick.
        int alive = closing
                ? Math.max(0, (WIDTH * HEIGHT) - phase * (WIDTH * HEIGHT) / CLOSE_ANIM)
                : Math.min(WIDTH * HEIGHT, phase * (WIDTH * HEIGHT) / OPEN_ANIM);

        for (int i = 0; i < session.field.size(); i++) {
            BlockPos pos = session.field.get(i);
            boolean standing = i < alive;
            boolean isField = session.origin.getBlockState(pos)
                    .is(ModContent.TIMEDOOR_FIELD.get());
            if (standing) {
                session.origin.setBlock(pos, field, Block.UPDATE_CLIENTS);
            } else if (isField) {
                if (closing) {
                    // A last puff of light as each block lets go.
                    session.origin.sendParticles(
                            net.minecraft.core.particles.ParticleTypes.PORTAL,
                            pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                            6, 0.3, 0.3, 0.3, 0.4);
                }
                session.origin.setBlock(pos, Blocks.AIR.defaultBlockState(),
                        Block.UPDATE_CLIENTS);
            }
        }

        // The surround goes up with the door and comes down with it. Only our
        // own alloy is ever removed, so nothing a player built goes with it.
        BlockState alloy = ModContent.CHRONOVIUM_BLOCK.get().defaultBlockState();
        boolean frameStands = !closing || phase < CLOSE_ANIM;
        for (BlockPos pos : session.frame) {
            boolean isFrame = session.origin.getBlockState(pos)
                    .is(ModContent.CHRONOVIUM_BLOCK.get());
            if (frameStands && !isFrame) {
                session.origin.setBlock(pos, alloy, Block.UPDATE_CLIENTS);
            } else if (!frameStands && isFrame) {
                session.origin.setBlock(pos, Blocks.AIR.defaultBlockState(),
                        Block.UPDATE_CLIENTS);
            }
        }
    }

    /** Is the player standing in the doorway? */
    private static boolean inside(Session session, ServerPlayer player) {
        AABB body = player.getBoundingBox();
        for (BlockPos pos : session.field) {
            if (body.intersects(new AABB(pos))) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Other travellers
    // ------------------------------------------------------------------

    /**
     * Anything standing in the field takes the trip with the door's course.
     *
     * <p>Mobs, dropped items, minecarts - whatever wanders in moves to the
     * destination just as the owner would, minus the bookkeeping only a
     * player can carry: no clock pinning, no timeline log. Players other
     * than the owner walk through the doorway untouched; the trip stays
     * keyed to the gadget's holder.</p>
     */
    private static void stepMobs(Session session) {
        List<Entity> travellers = session.origin.getEntitiesOfClass(Entity.class,
                fieldArea(session),
                e -> e != session.player && e.isAlive() && !e.isRemoved()
                        && !(e instanceof Player));
        for (Entity traveller : travellers) {
            sendEntity(session, traveller);
        }
    }

    /** The space of the whole open doorway, for the entity sweep. */
    private static AABB fieldArea(Session session) {
        boolean first = true;
        double minX = 0, minY = 0, minZ = 0, maxX = 0, maxY = 0, maxZ = 0;
        for (BlockPos pos : session.field) {
            if (first) {
                minX = maxX = pos.getX();
                minY = maxY = pos.getY();
                minZ = maxZ = pos.getZ();
                first = false;
            } else {
                minX = Math.min(minX, pos.getX());
                minY = Math.min(minY, pos.getY());
                minZ = Math.min(minZ, pos.getZ());
                maxX = Math.max(maxX, pos.getX());
                maxY = Math.max(maxY, pos.getY());
                maxZ = Math.max(maxZ, pos.getZ());
            }
        }
        // A sliver of slack so a critter brushing the surface counts too.
        return new AABB(minX - 0.2, minY - 0.2, minZ - 0.2,
                maxX + 1.2, maxY + 1.2, maxZ + 1.2);
    }

    /** Moves one creature or object through to the door's destination. */
    private static void sendEntity(Session session, Entity entity) {
        Destination destination = session.destination;
        ServerLevel target;
        BlockPos arrival;

        if (session.cell) {
            // A red door: the traveller is taken by the cell, not ferried.
            TimeCells.trap(entity, destination);
            return;
        }

        if (destination.tva()) {
            // Past the first hour everything ends up at the landing gate.
            target = session.origin.getServer().getLevel(com.tvatech.system.TemPadMenu.TVA);
            if (target == null) {
                return;
            }
            com.tvatech.system.TvaVault.ensureBuilt(target, new BlockPos(0, TvaVault.FLOOR_Y, 0));
            arrival = new BlockPos(0, TvaVault.FLOOR_Y + 1, TvaVault.ARRIVAL_Z);
        } else {
            target = destination.level();
            arrival = TimeTravel.nearestSafe(target, destination.pos());
            if (destination.useTime()) {
                // The whole doorway shares the clock the owner dialled in,
                // so a beast stepping in first lands in the same moment.
                WorldTime.setTime(target, destination.day(), destination.hour());
            }
        }

        // The same passage puff the hop uses, at both ends.
        session.origin.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                entity.getX(), entity.getY() + 1.0, entity.getZ(),
                24, 0.4, 0.8, 0.4, 0.08);

        boolean moved = moveEntity(entity, target,
                arrival.getX() + 0.5, arrival.getY(), arrival.getZ() + 0.5);

        if (moved) {
            target.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                    arrival.getX() + 0.5, arrival.getY() + 1.0, arrival.getZ() + 0.5,
                    24, 0.4, 0.8, 0.4, 0.08);
            target.playSound(null, arrival, SoundEvents.PORTAL_TRAVEL,
                    SoundSource.PLAYERS, 0.7F, 1.0F);
        }
    }

    // ------------------------------------------------------------------
    // Travelling
    // ------------------------------------------------------------------

    /**
     * This version's cross-level {@code Entity#teleportTo} flavor.
     *
     * <p>Both flavors move a creature of any kind to an exact spot in another
     * dimension; the 26.3 one just carries one extra argument.</p>
     */
    static boolean moveEntity(Entity entity, ServerLevel target,
                              double x, double y, double z) {
        return entity.teleportTo(target, x, y, z, java.util.Set.of(),
                entity.getYRot(), entity.getXRot());
    }

    private static void depart(Session session, ServerPlayer player) {
        Destination destination = session.destination;

        if (destination.cell()) {
            // The red door: the trip is the trap. The cell files them away,
            // lifts them into the sky above the destination and lets them
            // fall without harm, again and again, until a TemPad takes them
            // out.
            TimeCells.trap(player, destination);
            return;
        }

        if (destination.tva()) {
            TemPadMenu.goToTva(player);
            return;
        }

        ItemStack gadget = player.getMainHandItem();
        if (!gadget.is(ModContent.TEMPAD.get())) {
            gadget = player.getOffhandItem();
        }

        if (destination.useTime()) {
            // Put the clock where they asked for it, then go.
            WorldTime.setTime(destination.level(), destination.day(), destination.hour());
            TimeTravel.markExplicitClock(player);
        }
        TimeTravel.setPin(gadget, destination.level(), destination.pos);
        TimeTravel.hop(player, gadget);
    }

    // ------------------------------------------------------------------
    // Closing
    // ------------------------------------------------------------------

    /** Shuts a door early - because the traveller is gone, or asked again. */
    public static void close(ServerPlayer player, boolean loudly) {
        Session session = SESSIONS.remove(player.getUUID());
        if (session == null) {
            return;
        }
        if (loudly) {
            session.origin.playSound(null, session.base, SoundEvents.BEACON_DEACTIVATE,
                    SoundSource.PLAYERS, 0.6F, 1.5F);
            TvaFeedback.actionBar(player, TvaMessages.doorClosed());
        }
        tearDown(session);
    }

    /** Shuts a door by identity, for the logout hook. */
    public static void close(UUID playerId) {
        Session session = SESSIONS.remove(playerId);
        if (session != null) {
            tearDown(session);
        }
    }

    private static void remove(Session session) {
        SESSIONS.remove(session.playerId);
        tearDown(session);
    }

    /** Takes every block of the doorway back out of the world. */
    private static void tearDown(Session session) {
        for (BlockPos pos : session.field) {
            if (session.origin.getBlockState(pos).is(ModContent.TIMEDOOR_FIELD.get())) {
                session.origin.setBlock(pos, Blocks.AIR.defaultBlockState(),
                        Block.UPDATE_CLIENTS);
            }
        }
        for (BlockPos pos : session.frame) {
            if (session.origin.getBlockState(pos).is(ModContent.CHRONOVIUM_BLOCK.get())) {
                session.origin.setBlock(pos, Blocks.AIR.defaultBlockState(),
                        Block.UPDATE_CLIENTS);
            }
        }
        session.origin.playSound(null, session.base, SoundEvents.PORTAL_TRIGGER,
                SoundSource.PLAYERS, 0.7F, 0.7F);
    }

    /** True when this player already has a door standing. */
    public static boolean isOpen(ServerPlayer player) {
        return SESSIONS.containsKey(player.getUUID());
    }

    /**
     * Travels with no door at all.
     *
     * <p>The fallback for a player with no clear space in front of them. Being
     * unable to open a doorway is not a reason to be stranded where you
     * stand.</p>
     */
    public static void stepThroughNow(ServerPlayer player, Destination destination) {
        TimeCells.release(player.getUUID());
        depart(new Session(player, player.serverLevel(), player.blockPosition(),
                player.getDirection(), destination), player);
    }

    /** Drops every open door. */
    public static void closeAll() {
        for (Session session : new ArrayList<>(SESSIONS.values())) {
            remove(session);
        }
        SESSIONS.clear();
    }
}
