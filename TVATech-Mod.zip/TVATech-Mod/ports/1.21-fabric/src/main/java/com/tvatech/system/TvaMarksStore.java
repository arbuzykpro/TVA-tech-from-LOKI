package com.tvatech.system;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Where the TemPad marks live: one entry per player, saved with the world.
 *
 * <p>Marks used to sit in the player's own NBT. That worked - until the player
 * died, logged out, or respawned, and any of those could drop the bag. A world
 * save has none of those claws: it is rewritten on every change and exists
 * before the first player joins and after the last one leaves, so marks now
 * simply survive death, relog and restart.</p>
 *
 * <p>The per-player list is carried as a JSON string, the same trick the
 * timeline storage uses, so the values can only ever be plain numbers and
 * names.</p>
 */
public final class TvaMarksStore extends SavedData {

    public TvaMarksStore() {
    }

    public static final SavedData.Factory<TvaMarksStore> TYPE = new SavedData.Factory<>(
            TvaMarksStore::new,
            (tag, registries) -> TvaMarksStore.fromJson(tag.getString("data")),
            DataFixTypes.LEVEL);

    public static final String STORAGE_KEY = "tvatech_tempad_marks";

    /** Player uuid -> that player's mark list, as JSON. */
    public final Map<String, String> players = new HashMap<>();

    // ------------------------------------------------------------------
    // Per-player json <-> Mark list
    // ------------------------------------------------------------------

    /** Decodes one player's mark list; an unreadable list becomes empty. */
    public static List<TvaMarks.Mark> readList(String json) {
        List<TvaMarks.Mark> marks = new ArrayList<>();
        if (json == null || json.isBlank()) {
            return marks;
        }
        try {
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonArray()) {
                return marks;
            }
            for (JsonElement element : root.getAsJsonArray()) {
                if (!element.isJsonObject()) {
                    continue;
                }
                JsonObject entry = element.getAsJsonObject();
                if (!entry.has("label") || !entry.has("dim")) {
                    continue;
                }
                marks.add(new TvaMarks.Mark(
                        entry.get("label").getAsString(),
                        entry.get("dim").getAsString(),
                        entry.has("x") ? entry.get("x").getAsInt() : 0,
                        entry.has("y") ? entry.get("y").getAsInt() : 0,
                        entry.has("z") ? entry.get("z").getAsInt() : 0,
                        entry.has("day") ? entry.get("day").getAsLong() : 0L,
                        entry.has("hour") ? entry.get("hour").getAsInt() : 0));
            }
        } catch (Exception ignored) {
            // A torn entry can never be worse than an empty list.
            marks.clear();
        }
        return marks;
    }

    /** Encodes one player's mark list. */
    public static String writeList(List<TvaMarks.Mark> marks) {
        JsonArray root = new JsonArray();
        for (TvaMarks.Mark mark : marks) {
            JsonObject entry = new JsonObject();
            entry.addProperty("label", mark.label());
            entry.addProperty("dim", mark.dimension());
            entry.addProperty("x", mark.x());
            entry.addProperty("y", mark.y());
            entry.addProperty("z", mark.z());
            entry.addProperty("day", mark.markedDay());
            entry.addProperty("hour", mark.markedHour());
            root.add(entry);
        }
        return root.toString();
    }

    // ------------------------------------------------------------------
    // Whole-store json <-> SavedData
    // ------------------------------------------------------------------

    public static TvaMarksStore fromJson(String json) {
        TvaMarksStore store = new TvaMarksStore();
        if (json == null || json.isBlank()) {
            return store;
        }
        try {
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonObject()) {
                return store;
            }
            for (Map.Entry<String, JsonElement> line : root.getAsJsonObject().entrySet()) {
                if (line.getValue() != null && line.getValue().isJsonPrimitive()) {
                    store.players.put(line.getKey(), line.getValue().getAsString());
                }
            }
        } catch (Exception ignored) {
            store.players.clear();
        }
        return store;
    }

    public String toJson() {
        JsonObject root = new JsonObject();
        for (Map.Entry<String, String> line : players.entrySet()) {
            root.addProperty(line.getKey(), line.getValue());
        }
        return root.toString();
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putString("data", toJson());
        return tag;
    }
}
