package com.tvatech.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * The TVA time door: a glowing amber portal frame.
 *
 * <p>It cannot be walked through - in the show you always need a TemPad to
 * open one. Interactions (open/close, travel) are handled in
 * {@code com.tvatech.event.TvaInteractionEvents} so the block itself stays
 * free of behaviour overrides.</p>
 */
public class TimeDoorBlock extends Block {

    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    public TimeDoorBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(getStateDefinition().any().setValue(OPEN, Boolean.FALSE));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(OPEN);
    }

    /** Doors start life closed. */
    @Override
    public BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext context) {
        return defaultBlockState().setValue(OPEN, Boolean.FALSE);
    }

    /** Sound + light helper shared with the event handler. */
    public static void setOpen(Level level, BlockPos pos, boolean open) {
        var state = level.getBlockState(pos);
        if (state.hasProperty(OPEN) && state.getValue(OPEN) != open) {
            level.setBlockAndUpdate(pos, state.setValue(OPEN, open));
        }
    }
}