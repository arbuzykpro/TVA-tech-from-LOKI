package com.tvatech.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The surface of an open time door.
 *
 * <p>This is a real block, not a particle effect: the TemPad builds a doorway
 * out of these in front of you and you walk through it. The block cycles
 * through eight frames, which is what gives the field its movement - the
 * server swaps the state and the whole doorway ripples.</p>
 *
 * <p>It has no collision and no shape, so you pass straight through it, and it
 * is not obtainable, so it cannot be left lying around by accident. Breaking
 * one is refused in {@code com.tvatech.event.TvaEvents}: a door that is already
 * falling apart is not a door.</p>
 */
public class TimedoorFieldBlock extends Block {

    /** Which frame of the swirl this block is showing. */
    public static final IntegerProperty FRAME = IntegerProperty.create("frame", 0, 7);

    /** True on the red "time cell" doorway - the trap door. */
    public static final BooleanProperty CELL = BooleanProperty.create("cell");

    public TimedoorFieldBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(getStateDefinition().any().setValue(FRAME, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FRAME);
        builder.add(CELL);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos,
                               CollisionContext context) {
        // Nothing to walk into, even though there is plenty to look at.
        return Shapes.empty();
    }

    @Override
    protected boolean isPathfindable(BlockState state, PathComputationType type) {
        return false;
    }

    /** The next frame in the loop. */
    public static BlockState advance(BlockState state) {
        return state.setValue(FRAME, (state.getValue(FRAME) + 1) % 8);
    }
}
