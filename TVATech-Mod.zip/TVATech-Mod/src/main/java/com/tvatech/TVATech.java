package com.tvatech;

import com.mojang.logging.LogUtils;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import com.tvatech.event.TvaEvents;
import com.tvatech.network.TvaNetwork;
import org.slf4j.Logger;

/**
 * TVA Tech - Marvel's Loki (TVA) technology for Minecraft.
 *
 * <p>Adds the TemPad, the Mobius Mobile, variant scanning, pruning,
 * chrono-freeze and the glowing Time Door blocks.</p>
 */
@Mod(TVATech.MODID)
public final class TVATech {

    public static final String MODID = "tvatech";

    private static final Logger LOGGER = LogUtils.getLogger();

/** Shared logger, also used by the client-only helpers. */
public static final Logger LOG = LOGGER;

    public TVATech(FMLJavaModLoadingContext context) {
        var modBus = context.getModBusGroup();

        // Register the network channel NOW, while the registry is still open.
        // See TvaNetwork#init for why lazy registration is fatal.
        TvaNetwork.init();

        ModContent.BLOCKS.register(modBus);
        ModContent.ITEMS.register(modBus);
        ModContent.TABS.register(modBus);

        FMLCommonSetupEvent.getBus(modBus).addListener(TVATech::commonSetup);

        BuildCreativeModeTabContentsEvent.BUS.addListener(TVATech::addToVanillaTabs);

        // Gameplay listeners (interactions, ticks, respawns).
        TvaEvents.register();

        context.registerConfig(ModConfig.Type.COMMON, TvaConfig.SPEC);

        LOGGER.info("TVA Tech initialised - mind the reset button.");
    }

    private static void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("TVA Tech common setup complete.");
    }

    /** Also surface the gadgets in the vanilla Tools & Utilities tab. */
    private static void addToVanillaTabs(BuildCreativeModeTabContentsEvent event) {
        var tab = event.getTabKey();
        if (tab == net.minecraft.world.item.CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModContent.TEMPAD.get());
            event.accept(ModContent.MOBIUS_MOBILE.get());
            event.accept(ModContent.VARIANT_SCANNER.get());
            event.accept(ModContent.CHRONO_BATTERY.get());
        } else if (tab == net.minecraft.world.item.CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(ModContent.ARC_REACTOR_ITEM.get());
        } else if (tab == net.minecraft.world.item.CreativeModeTabs.BUILDING_BLOCKS) {
            event.accept(ModContent.TIME_DOOR_ITEM.get());
            event.accept(ModContent.CHRONOVIUM_BLOCK_ITEM.get());
        }
    }
}