package com.tvatech.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import com.tvatech.network.TvaNetwork;

import java.util.List;

/**
 * The Mobius Mobile interface: a chunky phone with a handful of TVA buttons.
 *
 * <p>Every press is sent to the server as a {@link TvaNetwork.MobileActionPayload};
 * the server answers with fresh state, so the screen only ever draws what it is
 * told and never decides whether an action is legal.</p>
 */
public class MobileScreen extends Screen {

    // Phone frame size, centred on the screen.
    private static final int PHONE_W = 190;
    private static final int PHONE_H = 156;
    private static final int PAD = 8;
    private static final int BUTTON_H = 14;
    private static final int BUTTON_GAP = 2;
    private static final int BUTTON_COUNT = 5;

    private static final int FRAME = 0xFF241A12;
    private static final int FRAME_LIGHT = 0xFF4A3826;
    private static final int SCREEN_BG = 0xFF2B1A0C;
    private static final int SCREEN_EDGE = 0xFFD8862F;
    private static final int TEXT = 0xFFFFCE93;
    private static final int TEXT_DIM = 0xFFB08452;
    private static final int AMBER = 0xFFFFB04A;
    private static final int BUTTON = 0xFF3A2412;
    private static final int BUTTON_HOVER = 0xFF54341A;
    private static final int BUTTON_OFF = 0xFF2A231C;

    private final TvaNetwork.OpenMobilePayload data;

    // Cached layout so drawing and hit testing cannot drift apart.
    private int phoneX;
    private int phoneY;
    private int screenX;
    private int screenY;
    private int screenW;
    private int screenH;
    private int contentX;
    private int contentY;
    private int contentW;
    private int buttonsY;

    public MobileScreen(TvaNetwork.OpenMobilePayload data) {
        super(Component.translatable("tvatech.mobile.title"));
        this.data = data;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Recomputes every rectangle the screen draws or hit tests. */
    private void layout() {
        phoneX = (this.width - PHONE_W) / 2;
        phoneY = (this.height - PHONE_H) / 2;

        screenX = phoneX + PAD;
        screenY = phoneY + PAD;
        screenW = PHONE_W - PAD * 2;
        screenH = PHONE_H - PAD * 2;

        contentX = screenX + 8;
        contentY = screenY + 7;
        contentW = screenW - 16;

        // header (12) + status line (11) + charge bar (3+6) + reactor line (12)
        buttonsY = contentY + 12 + 11 + 9 + 12;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        layout();

        drawShell(graphics);
        drawScreen(graphics);
        drawButtons(graphics, mouseX, mouseY);
        drawTimelinePreview(graphics);
    }

    private void drawShell(GuiGraphicsExtractor graphics) {
        graphics.fill(phoneX, phoneY, phoneX + PHONE_W, phoneY + PHONE_H, FRAME);
        graphics.fill(phoneX, phoneY, phoneX + PHONE_W, phoneY + 1, FRAME_LIGHT);
        graphics.fill(phoneX, phoneY, phoneX + 1, phoneY + PHONE_H, FRAME_LIGHT);
        graphics.fill(phoneX + PHONE_W - 1, phoneY, phoneX + PHONE_W, phoneY + PHONE_H, 0xFF101015);
        graphics.fill(phoneX, phoneY + PHONE_H - 1, phoneX + PHONE_W, phoneY + PHONE_H, 0xFF101015);
    }

    private void drawScreen(GuiGraphicsExtractor graphics) {
        graphics.fill(screenX, screenY, screenX + screenW, screenY + screenH, SCREEN_BG);
        outline(graphics, screenX, screenY, screenW, screenH, SCREEN_EDGE);

        // faint scanlines for the CRT feel
        for (int y = screenY + 2; y < screenY + screenH - 1; y += 3) {
            graphics.fill(screenX + 1, y, screenX + screenW - 1, y + 1, 0x14000000);
        }

        int y = contentY;

        graphics.text(this.font, title.copy().withStyle(ChatFormatting.AQUA), contentX, y, TEXT, false);
        y += 12;

        graphics.text(this.font,
                Component.translatable("tvatech.mobile.variant", data.variantId()), contentX, y, AMBER, false);
        graphics.text(this.font,
                Component.translatable("tvatech.mobile.charge", data.charge(), data.maxCharge()),
                contentX + 70, y, TEXT_DIM, false);
        y += 11;

        // charge bar
        graphics.fill(contentX, y, contentX + contentW, y + 3, 0xFF241207);
        int filled = data.maxCharge() <= 0
                ? 0
                : (int) Math.round((double) data.charge() / data.maxCharge() * contentW);
        graphics.fill(contentX, y, contentX + filled, y + 3, data.charge() > 0 ? TEXT : 0xFF7A3B2B);
        y += 9;

        graphics.text(this.font,
                Component.translatable(data.reactorLinked()
                        ? "tvatech.mobile.reactor_on" : "tvatech.mobile.reactor_off"),
                contentX, y, data.reactorLinked() ? TEXT : 0xFF8A5A3A, false);
    }

    private void drawButtons(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        for (int i = 0; i < BUTTON_COUNT; i++) {
            int bx = contentX;
            int by = buttonsY + i * (BUTTON_H + BUTTON_GAP);
            boolean hover = mouseX >= bx && mouseX < bx + contentW && mouseY >= by && mouseY < by + BUTTON_H;
            boolean enabled = isEnabled(i);

            graphics.fill(bx, by, bx + contentW, by + BUTTON_H,
                    enabled ? (hover ? BUTTON_HOVER : BUTTON) : BUTTON_OFF);
            outline(graphics, bx, by, contentW, BUTTON_H, enabled ? SCREEN_EDGE : 0xFF3A322A);

            int color = enabled ? (hover ? 0xFFFFFFFF : TEXT) : 0xFF6E6058;
            graphics.text(this.font, buttonLabel(i), bx + 5, by + 3, color, false);
        }
    }

    private void drawTimelinePreview(GuiGraphicsExtractor graphics) {
        List<String> timeline = data.timeline();
        if (timeline.isEmpty()) {
            return;
        }
        int top = buttonsY + BUTTON_COUNT * (BUTTON_H + BUTTON_GAP) + 2;
        int bottom = screenY + screenH - 2;
        if (top + 12 > bottom) {
            return;
        }
        outline(graphics, contentX - 3, top, contentW + 6, bottom - top, 0xFF7A4A1E);
        String last = timeline.get(0);
        if (last.length() > 32) {
            last = last.substring(0, 32);
        }
        graphics.text(this.font, Component.literal(last).withStyle(ChatFormatting.DARK_AQUA),
                contentX - 1, top + 3, TEXT_DIM, false);
    }

    /** The client only blocks obviously-not-ready buttons; the server has the final say. */
    private boolean isEnabled(int index) {
        return index != 0 || data.freezeCooldown() <= 0;
    }

    private Component buttonLabel(int index) {
        return switch (index) {
            case 0 -> data.freezeCooldown() > 0
                    ? Component.translatable("tvatech.mobile.frozen_wait",
                    String.format("%.0f", data.freezeCooldown() / 20.0))
                    : Component.translatable("tvatech.mobile.freeze");
            case 1 -> Component.translatable("tvatech.mobile.scan");
            case 2 -> Component.translatable("tvatech.mobile.timeline");
            case 3 -> Component.translatable("tvatech.mobile.anchor");
            default -> Component.translatable("tvatech.mobile.close");
        };
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();

        double mouseX = event.x();
        double mouseY = event.y();

        for (int i = 0; i < BUTTON_COUNT; i++) {
            int bx = contentX;
            int by = buttonsY + i * (BUTTON_H + BUTTON_GAP);
            boolean inside = mouseX >= bx && mouseX < bx + contentW
                    && mouseY >= by && mouseY < by + BUTTON_H;
            if (!inside) {
                continue;
            }
            if (!isEnabled(i)) {
                return true;
            }
            int action = switch (i) {
                case 0 -> TvaNetwork.ACTION_FREEZE;
                case 1 -> TvaNetwork.ACTION_SCAN;
                case 2 -> TvaNetwork.ACTION_TIMELINE;
                case 3 -> TvaNetwork.ACTION_ANCHOR;
                default -> TvaNetwork.ACTION_CLOSE;
            };
            if (action == TvaNetwork.ACTION_CLOSE) {
                this.onClose();
            } else {
                TvaNetwork.sendToServer(new TvaNetwork.MobileActionPayload(action));
            }
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    private void outline(GuiGraphicsExtractor graphics, int x, int y, int w, int h, int color) {
        graphics.outline(x, y, w, h, color);
    }
}