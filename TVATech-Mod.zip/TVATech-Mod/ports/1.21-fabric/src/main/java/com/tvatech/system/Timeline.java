package com.tvatech.system;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import com.tvatech.TvaConfig;
import com.tvatech.TVATech;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Glue between the world and {@link TimelineHistory}.
 *
 * <p>Recording happens in two steps. The break/place events stash the state a
 * block had <i>before</i> the change, and the neighbour notification that
 * follows the actual world edit commits the record. Doing it in that order
 * means a cancelled break never leaves a phantom change behind.</p>
 */
public final class Timeline {

    private Timeline() {}

    /** Pre-change states waiting for the block edit that follows them. */
    private static final Map<Long, Integer> PENDING_BEFORE = new HashMap<>();

    /**
     * Set while the mod is rewriting the world for another day, so the blocks
     * it writes are not mistaken for player edits.
     */
    private static boolean applying;

    /** Blocks written by the mod itself, so they are never recorded either. */
    private static boolean armed;

    // ------------------------------------------------------------------
    // Event entry points
    // ------------------------------------------------------------------

    /** Called from {@code BlockEvent.BreakEvent}: remember the doomed block. */
    public static void stashBreak(BlockPos pos, BlockState state) {
        if (applying || !TvaConfig.timelineBlocks) {
            return;
        }
        PENDING_BEFORE.put(pos.asLong(), Block.getId(state));
    }

    /** Called from {@code BlockEvent.EntityPlaceEvent}: remember what was replaced. */
    public static void stashPlace(BlockPos pos, BlockState replaced) {
        if (applying || !TvaConfig.timelineBlocks) {
            return;
        }
        PENDING_BEFORE.put(pos.asLong(), Block.getId(replaced));
    }

    /**
     * Called from {@code BlockEvent.NeighborNotifyEvent}, which fires once a
     * block has really changed. This is where a record is written.
     */
    public static void commit(ServerLevel level, BlockPos pos) {
        if (applying || !TvaConfig.timelineBlocks || level.isClientSide()) {
            return;
        }
        // Neighbour notifications fire for practically every block edit in the
        // world, so this only handles the ones a player made - the periodic
        // sweep is what catches fire, decay, pistons and fluids. Keeping the
        // hot path this cheap matters more than handling them here.
        Integer before = PENDING_BEFORE.remove(pos.asLong());
        if (before == null) {
            return;
        }
        int live = Block.getId(level.getBlockState(pos));
        if (before != live) {
            history(level).record(pos.asLong(), WorldTime.hourIndex(level), before, live);
        }
    }

    /** Drops a stashed pre-state that never turned into a real change. */
    public static void forget(BlockPos pos) {
        PENDING_BEFORE.remove(pos.asLong());
    }

    // ------------------------------------------------------------------
    // Day switches
    // ------------------------------------------------------------------

    /**
     * Rebuilds the world for a day and remembers it, so a restart reloads the
     * right version of every chunk.
     *
     * @return how many blocks were rebuilt
     */
    public static int switchTo(ServerLevel level, long hour) {
        TimelineHistory history = history(level);
        applying = true;
        try {
            return history.applyTo(level, hour);
        } finally {
            applying = false;
            PENDING_BEFORE.clear();
        }
    }

    /**
     * Queues a chunk to be rebuilt the moment it is safely loaded.
     *
     * <p>Doing the work inside {@code ChunkEvent.Load} is a trap: the event
     * fires while the chunk is still being built, so reading a block from it
     * can block on the chunk pipeline and hang the server. The work is deferred
     * to the next server tick instead.</p>
     */
    public static void onChunkLoaded(ServerLevel level, ChunkPos pos) {
        if (!TvaConfig.timelineBlocks || armed) {
            return;
        }
        TimelineHistory history = history(level);
        if (history.size() == 0) {
            return;
        }
        PENDING_CHUNKS.add(new ChunkRef(level.dimension(), pos));
    }

    private static final Set<ChunkRef> PENDING_CHUNKS = new HashSet<>();

    private record ChunkRef(ResourceKey<Level> dimension, ChunkPos pos) {
    }

    /** Applies any chunks that finished loading since the last tick. */
    public static void drainPendingChunks(ServerLevel level) {
        if (PENDING_CHUNKS.isEmpty() || armed) {
            return;
        }
        ResourceKey<Level> dimension = level.dimension();
        List<ChunkRef> ready = new ArrayList<>();
        for (ChunkRef ref : PENDING_CHUNKS) {
            if (ref.dimension().equals(dimension)) {
                ready.add(ref);
            }
        }
        PENDING_CHUNKS.removeAll(ready);

        TimelineHistory history = history(level);
        if (history.size() == 0) {
            return;
        }
        long hour = WorldTime.hourIndex(level);
        armed = true;
        try {
            for (ChunkRef ref : ready) {
                history.applyChunk(level, ref.pos(), hour);
            }
        } finally {
            armed = false;
        }
    }

    /** The catch-up sweep for changes no event reported. */
    public static void sweep(ServerLevel level) {
        if (!TvaConfig.timelineBlocks || applying) {
            return;
        }
        TimelineHistory history = history(level);
        if (history.size() == 0 || history.isFull()) {
            return;
        }
        applying = true;
        try {
            history.sweep(level, WorldTime.hourIndex(level));
        } finally {
            applying = false;
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** The per-dimension history, created on first use. */
    public static TimelineHistory history(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(TimelineHistory.TYPE, TimelineHistory.STORAGE_KEY);
    }

    /** Test hook: lets the self-test drive the "ignore changes" switch. */
    public static void setApplying(boolean value) {
        applying = value;
    }

    /** Test hook: records a change directly. */
    public static void recordForTest(ServerLevel level, BlockPos pos, BlockState before,
                                     BlockState after, long hour) {
        history(level).record(pos.asLong(), hour, Block.getId(before), Block.getId(after));
    }

    /** Test hook: makes sure a pending stash cannot leak into a test. */
    public static void clearPending() {
        PENDING_BEFORE.clear();
    }
}