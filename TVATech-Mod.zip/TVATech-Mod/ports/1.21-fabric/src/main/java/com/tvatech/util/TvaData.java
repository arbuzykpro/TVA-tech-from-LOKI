package com.tvatech.util;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import com.tvatech.TVATech;

import java.util.ArrayList;
import java.util.List;

/**
 * Small NBT helpers.
 *
 * <p>Two storage areas are used:</p>
 * <ul>
 *   <li><b>Item stacks</b> - via the vanilla {@code minecraft:custom_data} component,
 *       so charge / pinned coordinates survive crafting, dropping and re-picking up.</li>
 *   <li><b>Entities</b> - via Forge's persistent entity data, which is written to the
 *       entity's save file automatically.</li>
 * </ul>
 *
 * <p>Note: {@link CompoundTag} getters return {@link java.util.Optional} in this
 * Minecraft version, hence the small amount of unwrapping below.</p>
 */
public final class TvaData {

    private TvaData() {}

    public static final String VARIANT_KEY = "tva_variant";
    public static final String FROZEN_UNTIL = "tva_frozen_until";
    public static final String FROZEN_BY = "tva_frozen_by";
    public static final String TIMELINE = "tva_timeline";
    public static final String ANCHOR = "tva_anchor";

    // ---------------- item stacks ----------------

    public static CompoundTag read(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data != null ? data.copyTag() : new CompoundTag();
    }

    public static void write(ItemStack stack, CompoundTag tag) {
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    public static int getInt(ItemStack stack, String key, int fallback) {
        return read(stack).getInt(key);
    }

    public static long getLong(ItemStack stack, String key, long fallback) {
        return read(stack).getLong(key);
    }

    public static void setInt(ItemStack stack, String key, int value) {
        CompoundTag tag = read(stack);
        tag.putInt(key, value);
        write(stack, tag);
    }

    public static void setLong(ItemStack stack, String key, long value) {
        CompoundTag tag = read(stack);
        tag.putLong(key, value);
        write(stack, tag);
    }

    public static boolean getBoolean(ItemStack stack, String key) {
        return read(stack).getBoolean(key);
    }

    public static void setBoolean(ItemStack stack, String key, boolean value) {
        CompoundTag tag = read(stack);
        tag.putBoolean(key, value);
        write(stack, tag);
    }

    public static String getString(ItemStack stack, String key) {
        return read(stack).getString(key);
    }

    public static void setString(ItemStack stack, String key, String value) {
        CompoundTag tag = read(stack);
        tag.putString(key, value);
        write(stack, tag);
    }

    public static int[] getIntArray(ItemStack stack, String key) {
        return read(stack).getIntArray(key);
    }

    public static void setIntArray(ItemStack stack, String key, int[] value) {
        CompoundTag tag = read(stack);
        tag.putIntArray(key, value);
        write(stack, tag);
    }

    public static void remove(ItemStack stack, String key) {
        CompoundTag tag = read(stack);
        tag.remove(key);
        write(stack, tag);
    }

    // ---------------- entities ----------------

    /**
     * Per-entity NBT that is written to the entity's save file.
     *
     * <p>This replaces Forge's {@code getPersistentData()}: a persistent Fabric
     * data attachment with the same lifetime and the same NBT container type, so
     * every reader below is unchanged in shape.</p>
     */
    public static final AttachmentType<CompoundTag> ENTITY_DATA = AttachmentRegistry.createPersistent(
            ResourceLocation.fromNamespaceAndPath(TVATech.MODID, "entity_data"),
            CompoundTag.CODEC);

    /** The mutable, saved data bag for an entity. */
    public static CompoundTag data(Entity entity) {
        return entity.getAttachedOrCreate(ENTITY_DATA, CompoundTag::new);
    }

    public static int variantOf(Entity entity) {
        return data(entity).getInt(VARIANT_KEY);
    }

    public static void setVariant(Entity entity, int variant) {
        data(entity).putInt(VARIANT_KEY, variant);
    }

    /** Frozen entities remember until when (in level game time) they stay locked. */
    public static int frozenUntil(Entity entity) {
        return data(entity).getInt(FROZEN_UNTIL);
    }

    public static void setFrozenUntil(Entity entity, int tick) {
        data(entity).putInt(FROZEN_UNTIL, tick);
    }

    public static long frozenBy(Entity entity) {
        return data(entity).getLong(FROZEN_BY);
    }

    public static void setFrozenBy(Entity entity, long uuid) {
        data(entity).putLong(FROZEN_BY, uuid);
    }

    // ---------------- player records ----------------

    /** Timeline log: newest first. */
    public static List<String> timeline(Entity entity) {
        List<String> out = new ArrayList<>();
        ListTag list = data(entity).getList(TIMELINE, 10);
        for (var tag : list) {
            if (tag instanceof CompoundTag entry) {
                out.add(entry.getString("t"));
            }
        }
        return out;
    }

    public static void pushTimeline(Entity entity, String line, int maxEntries) {
        CompoundTag entry = new CompoundTag();
        entry.putString("t", line);

        CompoundTag tag = data(entity);
        ListTag list = tag.getList(TIMELINE, 10);
        list.add(entry);
        while (list.size() > Math.max(1, maxEntries)) {
            list.remove(list.size() - 1);
        }
        tag.put(TIMELINE, list);
    }

    /** Records the world position a pruned player should return to. */
    public static void setAnchor(Entity player, String dimension, int x, int y, int z) {
        CompoundTag tag = new CompoundTag();
        tag.putString("dim", dimension);
        tag.putInt("x", x);
        tag.putInt("y", y);
        tag.putInt("z", z);
        data(player).put(ANCHOR, tag);
    }

    public static CompoundTag anchor(Entity player) {
        CompoundTag tag = data(player).getCompound(ANCHOR);
        return tag.isEmpty() ? null : tag;
    }

    public static void clearAnchor(Entity player) {
        data(player).remove(ANCHOR);
    }

    // ---------------- one-shot feature flags ----------------

    /** Did this entity already receive a one-time feature (like Miss Minutes)? */
    public static boolean flag(Entity entity, String key) {
        return data(entity).getBoolean(key);
    }

    public static void setFlag(Entity entity, String key) {
        data(entity).putBoolean(key, true);
    }

    // ---------------- time collar ----------------

    public static final String COLLAR_HI = "tva_collar_hi";
    public static final String COLLAR_LO = "tva_collar_lo";

    /**
     * The UUID (as two halves) of whoever clamped a collar on this creature,
     * or {@code null} when it wears none.
     */
    public static java.util.UUID collarPlacer(Entity entity) {
        CompoundTag tag = data(entity);
        if (!tag.contains(COLLAR_HI)) {
            return null;
        }
        return new java.util.UUID(tag.getLong(COLLAR_HI), tag.getLong(COLLAR_LO));
    }

    /** Cues a collar onto this creature, remembering who put it there. */
    public static void setCollar(Entity entity, java.util.UUID placer) {
        CompoundTag tag = data(entity);
        tag.putLong(COLLAR_HI, placer.getMostSignificantBits());
        tag.putLong(COLLAR_LO, placer.getLeastSignificantBits());
    }

    /** Takes a collar back off - the creature forgets who held it. */
    public static void clearCollar(Entity entity) {
        data(entity).remove(COLLAR_HI);
        data(entity).remove(COLLAR_LO);
    }
}