package com.tvatech;

/**
 * All tunables live here.
 *
 * <p>The Forge build read these from a TOML config file. The Fabric build keeps
 * the exact same field names and defaults as plain constants, so gameplay code
 * is identical on both loaders. A JSON config can be layered on later without
 * touching any caller.</p>
 */
public final class TvaConfig {

    private TvaConfig() {}

    // --- general ----------------------------------------------------------
    public static boolean allowPruning = true;
    public static boolean allowTemporalHop = true;
    public static boolean shiftWorldTime = true;
    public static int travelAnimationTicks = 30;
    public static int timeShiftHours = 6;

    // --- tempad -----------------------------------------------------------
    public static int tempadMaxCharge = 5;
    public static int hopCost = 1;
    public static int hopCooldownTicks = 20;
    public static int batteryCharge = 2;

    // --- chrono freeze ----------------------------------------------------
    public static int freezeRadius = 8;
    public static int freezeDurationTicks = 200;
    public static int freezeCooldownTicks = 400;
    public static int freezeCost = 2;
    public static boolean freezeRequiresReactor = true;
    public static int reactorRange = 12;
    public static double nauseaChance = 0.3;
    public static int nauseaDurationTicks = 300;

    // --- timeline ---------------------------------------------------------
    public static boolean timelineBlocks = true;
    public static int timelineSweepTicks = 40;
    public static int timelineMaxEntries = 200000;

    // --- variants ---------------------------------------------------------
    public static int timelineLogSize = 12;
    public static boolean announceTimeline = false;
}
