package com.tvatech.client;

import net.minecraft.client.Minecraft;
import com.tvatech.network.TvaNetwork;

/**
 * Client-only entry points.
 *
 * <p>Deliberately <b>not</b> annotated {@code @OnlyIn}: Forge 26.x throws
 * {@code UnsupportedOperationException} the moment a mod class carrying that
 * annotation is loaded. These classes are only ever reached from client-side
 * code paths (a received payload, a client tick), so a dedicated server never
 * loads them and needs no marker.</p>
 */
public final class TvaClient {

    private TvaClient() {}

    /** Called from the network handler when the server pushes phone state. */
    public static void openMobile(TvaNetwork.OpenMobilePayload payload) {
        var minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        minecraft.setScreen(new MobileScreen(payload));
    }

    /** Called from the network handler when the server opens the TemPad menu. */
    public static void openTempadMenu(TvaNetwork.OpenTemPadMenuPayload payload) {
        var minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        minecraft.setScreen(new TempadMenuScreen(payload));
    }

    /**
     * Miss Minutes says a line: spoken aloud by the game narrator (text to
     * speech) while the hologram yaps over the world.
     */
    public static void minutesSay(TvaNetwork.MinutesPayload payload) {
        var minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        minecraft.getNarrator().say(
                net.minecraft.network.chat.Component.literal(payload.line()));
    }

    /**
     * Dev preview: opens the TemPad menu with sample data.
     *
     * <p>Launch the dev client with {@code TVA_SHOWMENU=1} (or
     * {@code -Dtva.showmenu=true}) to eyeball the layout without needing a
     * server or a world.</p>
     */
    public static void debugOpenMenuIfRequested() {
        if (!requested()) {
            return;
        }
        openPreview(Minecraft.getInstance());
    }

    /** Env var as well as a system property: ForgeGradle's forked JVM only inherits one of them. */
    private static boolean requested() {
        return Boolean.getBoolean("tva.showmenu") || "1".equals(System.getenv("TVA_SHOWMENU"));
    }

    private static void openPreview(net.minecraft.client.Minecraft minecraft) {
        // Wait until the main menu is up and idle.
        if (minecraft.getOverlay() != null) {
            return;
        }
        var current = minecraft.screen;
        if (current != null && !(current instanceof net.minecraft.client.gui.screens.TitleScreen)) {
            return;
        }
        com.tvatech.TVATech.LOG.info("TVA: opening the TemPad menu preview");
        minecraft.setScreen(new TempadMenuScreen(new TvaNetwork.OpenTemPadMenuPayload(
                java.util.List.of("MARK-01", "MARK-02", "MARK-03"),
                java.util.List.of("minecraft:overworld", "minecraft:overworld", "minecraft:the_nether"),
                new int[]{128, -940, 64}, new int[]{71, 64, 62}, new int[]{-256, 512, 8},
                new long[]{412, 418, 77}, new int[]{14, 9, 3},
                0, 14)));
    }
}