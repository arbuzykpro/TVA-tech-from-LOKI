package com.tvatech.system;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import com.tvatech.TVATech;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Remembers what was lying around and stored away on every day.
 *
 * <p>Same idea as the block timeline, for the two things that are not blocks:</p>
 * <ul>
 *   <li><b>Containers</b> - chests, barrels, shulker boxes and every other
 *       storage block. Whatever is inside on day 3 is what you find on day 3,
 *       even if you emptied it on day 7.</li>
 *   <li><b>Dropped items</b> - a stack you dropped on day 3 and picked up on
 *       day 7 is lying there again when you go back to day 3.</li>
 * </ul>
 *
 * <p>One record per day per subject, same resolution rule as the block
 * timeline: the newest record on or before the day you land on wins.</p>
 */
public final class TimelineObjects extends SavedData {

    public TimelineObjects() {
    }

    public static final SavedDataType<TimelineObjects> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(TVATech.MODID, "timeline_objects_hourly"),
            TimelineObjects::new,
            Codec.STRING.xmap(TimelineObjects::fromJson, TimelineObjects::toJson),
            DataFixTypes.LEVEL);

    /**
     * Per-day records for one subject. {@code payload} is an inventory blob for
     * a container, a stack blob for an item; {@code extra} holds the item's
     * alive flag and position.
     */
    private static final class Records {
        long[] days = new long[2];
        String[] payloads = new String[2];
        String[] extras = new String[2];
        String before;
        String beforeExtra;
        int size;

        void add(long day, String payload, String extra, String beforePayload,
                 String beforeExtra) {
            if (size > 0 && days[size - 1] == day) {
                payloads[size - 1] = payload;
                extras[size - 1] = extra;
                return;
            }
            if (size == days.length) {
                long[] d = new long[days.length * 2];
                String[] p = new String[payloads.length * 2];
                String[] e = new String[extras.length * 2];
                System.arraycopy(days, 0, d, 0, size);
                System.arraycopy(payloads, 0, p, 0, size);
                System.arraycopy(extras, 0, e, 0, size);
                days = d;
                payloads = p;
                extras = e;
            }
            int at = size;
            while (at > 0 && days[at - 1] > day) {
                at--;
            }
            for (int i = size; i > at; i--) {
                days[i] = days[i - 1];
                payloads[i] = payloads[i - 1];
                extras[i] = extras[i - 1];
            }
            days[at] = day;
            payloads[at] = payload;
            extras[at] = extra;
            if (size == 0) {
                before = beforePayload;
                beforeExtra = beforeExtra;
            }
            size++;
        }

        /** Index of the newest record on or before {@code day}, or -1. */
        int indexFor(long day) {
            int found = -1;
            for (int i = 0; i < size; i++) {
                if (days[i] <= day) {
                    found = i;
                } else {
                    break;
                }
            }
            return found;
        }

        String payloadFor(long day) {
            int at = indexFor(day);
            return at < 0 ? before : payloads[at];
        }

        String extraFor(long day) {
            int at = indexFor(day);
            return at < 0 ? beforeExtra : extras[at];
        }
    }

    private final Map<Long, Records> containers = new HashMap<>();
    private final Map<String, Records> items = new HashMap<>();
    private final Map<ChunkPos, List<Long>> byChunk = new HashMap<>();

    // ------------------------------------------------------------------
    // Recording
    // ------------------------------------------------------------------

    /** Files a container's contents for a day, if they changed. */
    public void recordContainer(ServerLevel level, BlockPos pos, long day) {
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (!(blockEntity instanceof Container container)) {
            return;
        }
        HolderLookup.Provider registries = level.registryAccess();
        NonNullList<ItemStack> snapshot = NonNullList.withSize(container.getContainerSize(),
                ItemStack.EMPTY);
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            snapshot.set(slot, container.getItem(slot).copy());
        }
        String blob = Nbt.saveItems(registries, snapshot);
        recordContainerRaw(pos.asLong(), day, blob, pos);
    }

    /** Same, but with contents already serialised (used by the sweep). */
    public boolean recordContainerRaw(long posKey, long day, String blob, BlockPos pos) {
        Records records = containers.computeIfAbsent(posKey, key -> {
            byChunk.computeIfAbsent(ChunkPos.containing(pos), k -> new ArrayList<>()).add(posKey);
            return new Records();
        });
        String existing = records.payloadFor(day);
        if (blob.equals(existing)) {
            return false;
        }
        records.add(day, blob, null, existing, null);
        setDirty();
        return true;
    }

    public void recordItem(String uuid, long day, boolean alive, String stackBlob, String extra) {
        Records records = items.computeIfAbsent(uuid, key -> {
            Records fresh = new Records();
            // Before the first sighting the item simply was not there.
            fresh.add(day - 1, "", "0", "", "0");
            return fresh;
        });
        String extraValue = alive ? extra : "0";
        String existingExtra = records.extraFor(day);
        String existingPayload = records.payloadFor(day);
        if (extraValue.equals(existingExtra) && stackBlob.equals(existingPayload)) {
            return;
        }
        records.add(day, stackBlob, extraValue, existingPayload, existingExtra);
        setDirty();
    }

    // ------------------------------------------------------------------
    // Reading
    // ------------------------------------------------------------------

    public String containerContents(long posKey, long day) {
        Records records = containers.get(posKey);
        return records == null ? null : records.payloadFor(day);
    }

    public String[] itemState(String uuid, long day) {
        Records records = items.get(uuid);
        if (records == null) {
            return null;
        }
        return new String[]{records.extraFor(day), records.payloadFor(day)};
    }

    /**
     * Re-checks every known container and files its contents if they moved.
     *
     * @return how many containers changed
     */
    public int sweepContainers(ServerLevel level, long day) {
        int changed = 0;
        for (Map.Entry<Long, Records> entry : containers.entrySet()) {
            BlockPos pos = BlockPos.of(entry.getKey());
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (!(blockEntity instanceof Container container)) {
                continue;
            }
            HolderLookup.Provider registries = level.registryAccess();
            NonNullList<ItemStack> snapshot = NonNullList.withSize(container.getContainerSize(),
                    ItemStack.EMPTY);
            for (int slot = 0; slot < container.getContainerSize(); slot++) {
                snapshot.set(slot, container.getItem(slot).copy());
            }
            if (recordContainerRaw(pos.asLong(), day, Nbt.saveItems(registries, snapshot), pos)) {
                changed++;
            }
        }
        return changed;
    }

    /** Every tracked dropped-item id. */
    public List<String> itemUuids() {
        return new ArrayList<>(items.keySet());
    }

    public boolean hasContainers() {
        return !containers.isEmpty();
    }

    public boolean hasItems() {
        return !items.isEmpty();
    }

    public int containerCount() {
        return containers.size();
    }

    public int itemCount() {
        return items.size();
    }

    // ------------------------------------------------------------------
    // Applying
    // ------------------------------------------------------------------

    /**
     * Restores containers for a day.
     *
     * @return how many inventories changed
     */
    public int applyContainers(ServerLevel level, long day) {
        int changed = 0;
        for (Map.Entry<Long, Records> entry : containers.entrySet()) {
            BlockPos pos = BlockPos.of(entry.getKey());
            if (!level.isLoaded(pos) || !level.getChunkSource()
                    .hasChunk(pos.getX() >> 4, pos.getZ() >> 4)) {
                continue;
            }
            String blob = entry.getValue().payloadFor(day);
            if (blob == null) {
                continue;
            }
            if (level.getBlockEntity(pos) instanceof Container container) {
                if (restoreContainer(level, pos, container, blob)) {
                    changed++;
                }
            }
        }
        return changed;
    }

    private boolean restoreContainer(ServerLevel level, BlockPos pos, Container container, String blob) {
        HolderLookup.Provider registries = level.registryAccess();
        NonNullList<ItemStack> wanted = NonNullList.withSize(container.getContainerSize(),
                ItemStack.EMPTY);
        Nbt.loadItems(registries, blob, wanted);

        boolean different = false;
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack live = container.getItem(slot);
            ItemStack target = wanted.get(slot);
            if (!ItemStack.matches(live, target) || live.getCount() != target.getCount()) {
                different = true;
                break;
            }
        }
        if (!different) {
            return false;
        }
        container.clearContent();
        for (int slot = 0; slot < Math.min(container.getContainerSize(), wanted.size()); slot++) {
            container.setItem(slot, wanted.get(slot));
        }
        container.setChanged();
        level.sendBlockUpdated(pos, level.getBlockState(pos), level.getBlockState(pos), 3);
        return true;
    }

    /** Whether a stored item should be lying on the ground on {@code day}. */
    public boolean itemAlive(String uuid, long day) {
        String[] state = itemState(uuid, day);
        return state != null && !"0".equals(state[0]);
    }

    public Map<String, Records> itemRecords() {
        return items;
    }

    // ------------------------------------------------------------------
    // Saving
    // ------------------------------------------------------------------

    public String toJson() {
        JsonObject root = new JsonObject();

        JsonArray containerList = new JsonArray();
        for (Map.Entry<Long, Records> entry : containers.entrySet()) {
            BlockPos pos = BlockPos.of(entry.getKey());
            JsonArray line = new JsonArray();
            line.add(pos.getX());
            line.add(pos.getY());
            line.add(pos.getZ());
            line.add(writeRecords(entry.getValue()));
            containerList.add(line);
        }
        root.add("c", containerList);

        JsonArray itemList = new JsonArray();
        for (Map.Entry<String, Records> entry : items.entrySet()) {
            JsonArray line = new JsonArray();
            line.add(entry.getKey());
            line.add(writeRecords(entry.getValue()));
            itemList.add(line);
        }
        root.add("i", itemList);

        return root.toString();
    }

    private static JsonArray writeRecords(Records records) {
        JsonArray list = new JsonArray();
        if (records.before != null) {
            JsonArray seed = new JsonArray();
            seed.add(records.before);
            seed.add(records.beforeExtra);
            list.add(seed);
        }
        for (int i = 0; i < records.size; i++) {
            JsonArray record = new JsonArray();
            record.add(records.days[i]);
            record.add(records.payloads[i] == null ? "" : records.payloads[i]);
            record.add(records.extras[i] == null ? "" : records.extras[i]);
            list.add(record);
        }
        return list;
    }

    public static TimelineObjects fromJson(String json) {
        TimelineObjects objects = new TimelineObjects();
        if (json == null || json.isBlank()) {
            return objects;
        }
        try {
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            if (root.has("c")) {
                for (JsonElement lineElement : root.getAsJsonArray("c")) {
                    JsonArray line = lineElement.getAsJsonArray();
                    BlockPos pos = new BlockPos(line.get(0).getAsInt(), line.get(1).getAsInt(),
                            line.get(2).getAsInt());
                    objects.containers.put(pos.asLong(), readRecords(line.get(3).getAsJsonArray()));
                    objects.byChunk.computeIfAbsent(ChunkPos.containing(pos),
                            key -> new ArrayList<>()).add(pos.asLong());
                }
            }
            if (root.has("i")) {
                for (JsonElement lineElement : root.getAsJsonArray("i")) {
                    JsonArray line = lineElement.getAsJsonArray();
                    objects.items.put(line.get(0).getAsString(), readRecords(line.get(1).getAsJsonArray()));
                }
            }
        } catch (RuntimeException e) {
            TVATech.LOG.warn("TVA: could not read the item timeline, starting empty", e);
        }
        return objects;
    }

    private static Records readRecords(JsonArray array) {
        Records records = new Records();
        for (JsonElement element : array) {
            JsonArray row = element.getAsJsonArray();
            if (row.size() < 3) {
                continue;
            }
            records.add(row.get(0).getAsLong(), row.get(1).getAsString(), row.get(2).getAsString(),
                    "", "");
        }
        return records;
    }
}