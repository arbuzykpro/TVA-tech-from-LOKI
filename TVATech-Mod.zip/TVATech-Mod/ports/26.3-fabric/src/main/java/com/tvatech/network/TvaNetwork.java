package com.tvatech.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import com.tvatech.TVATech;

import java.util.ArrayList;
import java.util.List;

/**
 * Network plumbing for the Mobius Mobile and the TemPad.
 *
 * <p>Two directions:</p>
 * <ul>
 *   <li>server -&gt; client: phone state and the TemPad destination menu.</li>
 *   <li>client -&gt; server: a button press on either screen.</li>
 * </ul>
 *
 * <p>Fabric splits receiver registration by side: the server-bound receivers
 * are registered here, the client-bound ones from the client initialiser, so a
 * dedicated server never touches client classes.</p>
 */
public final class TvaNetwork {

    private TvaNetwork() {}

    private static boolean initialized;

    /** Registers the payload types and the server-bound receivers. */
    public static synchronized void init() {
        if (initialized) {
            return;
        }
        initialized = true;

        PayloadTypeRegistry.clientboundPlay().register(OpenMobilePayload.TYPE, OpenMobilePayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(OpenTemPadMenuPayload.TYPE, OpenTemPadMenuPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(MinutesPayload.TYPE, MinutesPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(MobileActionPayload.TYPE, MobileActionPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(TemPadMenuActionPayload.TYPE, TemPadMenuActionPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(MobileActionPayload.TYPE, (payload, context) ->
                context.server().execute(() ->
                        com.tvatech.system.MobileAbilities.handleAction(context.player(), payload.action())));

        ServerPlayNetworking.registerGlobalReceiver(TemPadMenuActionPayload.TYPE, (payload, context) ->
                context.server().execute(() ->
                        com.tvatech.system.TemPadMenu.handle(context.player(), payload)));
    }

    /** Registers the client-bound receivers. Client initialiser only. */
    public static void initClient() {
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                OpenMobilePayload.TYPE, (payload, context) ->
                        context.client().execute(() -> com.tvatech.client.TvaClient.openMobile(payload)));
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                OpenTemPadMenuPayload.TYPE, (payload, context) ->
                        context.client().execute(() -> com.tvatech.client.TvaClient.openTempadMenu(payload)));
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                MinutesPayload.TYPE, (payload, context) ->
                        context.client().execute(() -> com.tvatech.client.TvaClient.minutesSay(payload)));
    }

    /** True once {@link #init()} has run - used by the startup self-test. */
    public static boolean isInitialized() {
        return initialized;
    }

    public static void sendToPlayer(ServerPlayer player, CustomPacketPayload payload) {
        ServerPlayNetworking.send(player, payload);
    }

    public static void sendToServer(CustomPacketPayload payload) {
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(payload);
    }

    // ------------------------------------------------------------------
    // Server -> client: the whole state of the phone
    // ------------------------------------------------------------------
    public record OpenMobilePayload(int variantId, int charge, int maxCharge,
                                    int freezeCooldown, boolean reactorLinked,
                                    List<String> timeline) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<OpenMobilePayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(TVATech.MODID, "open_mobile"));

        public static final StreamCodec<RegistryFriendlyByteBuf, OpenMobilePayload> CODEC = StreamCodec.of(
                (buf, value) -> {
                    buf.writeVarInt(value.variantId);
                    buf.writeVarInt(value.charge);
                    buf.writeVarInt(value.maxCharge);
                    buf.writeVarInt(value.freezeCooldown);
                    buf.writeBoolean(value.reactorLinked);
                    buf.writeVarInt(value.timeline.size());
                    for (String line : value.timeline) {
                        buf.writeUtf(line, 256);
                    }
                },
                buf -> {
                    int variantId = buf.readVarInt();
                    int charge = buf.readVarInt();
                    int maxCharge = buf.readVarInt();
                    int freezeCooldown = buf.readVarInt();
                    boolean reactorLinked = buf.readBoolean();
                    int size = buf.readVarInt();
                    List<String> timeline = new ArrayList<>(Math.max(0, Math.min(size, 64)));
                    for (int i = 0; i < size; i++) {
                        timeline.add(buf.readUtf(256));
                    }
                    return new OpenMobilePayload(variantId, charge, maxCharge, freezeCooldown, reactorLinked, timeline);
                });

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // ------------------------------------------------------------------
    // Server -> client: Miss Minutes says a line
    // ------------------------------------------------------------------
    public record MinutesPayload(String line) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<MinutesPayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(TVATech.MODID, "minutes_line"));

        public static final StreamCodec<RegistryFriendlyByteBuf, MinutesPayload> CODEC = StreamCodec.of(
                (buf, value) -> buf.writeUtf(value.line, 256),
                buf -> new MinutesPayload(buf.readUtf(256)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // ------------------------------------------------------------------
    // Client -> server: a button press
    // ------------------------------------------------------------------
    public record MobileActionPayload(int action) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<MobileActionPayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(TVATech.MODID, "mobile_action"));

        public static final StreamCodec<RegistryFriendlyByteBuf, MobileActionPayload> CODEC = StreamCodec.of(
                (buf, value) -> buf.writeVarInt(value.action()),
                buf -> new MobileActionPayload(buf.readVarInt()));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Action ids shared by the GUI buttons and the server handlers. */
    public static final int ACTION_FREEZE = 0;
    public static final int ACTION_SCAN = 1;
    public static final int ACTION_TIMELINE = 2;
    public static final int ACTION_ANCHOR = 3;
    public static final int ACTION_CLOSE = 4;

    // ------------------------------------------------------------------
    // TemPad menu
    // ------------------------------------------------------------------
    public static final int MENU_MAKE_MARK = 0;
    public static final int MENU_DELETE_MARK = 1;
    public static final int MENU_TRAVEL = 2;
    public static final int MENU_CLOSE = 3;
    public static final int MENU_RENAME_MARK = 4;
    /** MANUAL view submit: the boxes carry the coordinates and dimension. */
    public static final int MENU_MANUAL_MARK = 10;

    // ------------------------------------------------------------------
    // Server -> client: the TemPad destination menu
    // ------------------------------------------------------------------
    public record OpenTemPadMenuPayload(List<String> labels, List<String> dimensions,
                                         int[] xs, int[] ys, int[] zs,
                                         long[] markedDays, int[] markedHours,
                                         long day, int hour) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<OpenTemPadMenuPayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(TVATech.MODID, "open_tempad_menu"));

        public static final StreamCodec<RegistryFriendlyByteBuf, OpenTemPadMenuPayload> CODEC =
                StreamCodec.of((buf, value) -> {
                    buf.writeVarInt(value.labels.size());
                    for (int i = 0; i < value.labels.size(); i++) {
                        buf.writeUtf(value.labels.get(i), 64);
                        buf.writeUtf(value.dimensions.get(i), 128);
                        buf.writeVarInt(value.xs[i]);
                        buf.writeVarInt(value.ys[i]);
                        buf.writeVarInt(value.zs[i]);
                        buf.writeVarLong(value.markedDays[i]);
                        buf.writeVarInt(value.markedHours[i]);
                    }
                    buf.writeVarLong(value.day);
                    buf.writeVarInt(value.hour);
                }, buf -> {
                    int size = buf.readVarInt();
                    List<String> labels = new ArrayList<>();
                    List<String> dims = new ArrayList<>();
                    int[] xs = new int[size];
                    int[] ys = new int[size];
                    int[] zs = new int[size];
                    long[] days = new long[size];
                    int[] hours = new int[size];
                    for (int i = 0; i < size; i++) {
                        labels.add(buf.readUtf(64));
                        dims.add(buf.readUtf(128));
                        xs[i] = buf.readVarInt();
                        ys[i] = buf.readVarInt();
                        zs[i] = buf.readVarInt();
                        days[i] = buf.readVarLong();
                        hours[i] = buf.readVarInt();
                    }
                    long day = buf.readVarLong();
                    int hour = buf.readVarInt();
                    return new OpenTemPadMenuPayload(labels, dims, xs, ys, zs, days, hours,
                            day, hour);
                });

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // ------------------------------------------------------------------
    // Client -> server: a TemPad menu button
    // ------------------------------------------------------------------
    public record TemPadMenuActionPayload(int action, int index, long day, int hour,
                                         boolean useTime, String name,
                                         int mx, int my, int mz, String mdim,
                                         boolean cell) implements CustomPacketPayload {

        public TemPadMenuActionPayload(int action, int index, long day, int hour,
                                       boolean useTime, String name) {
            this(action, index, day, hour, useTime, name, 0, 0, 0, "", false);
        }

        public static final CustomPacketPayload.Type<TemPadMenuActionPayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(TVATech.MODID, "tempad_menu_action"));

        public static final StreamCodec<RegistryFriendlyByteBuf, TemPadMenuActionPayload> CODEC =
                StreamCodec.of((buf, value) -> {
                    buf.writeVarInt(value.action);
                    buf.writeVarInt(value.index);
                    buf.writeVarLong(value.day);
                    buf.writeVarInt(value.hour);
                    buf.writeBoolean(value.useTime);
                    buf.writeUtf(value.name, 64);
                    buf.writeVarInt(value.mx);
                    buf.writeVarInt(value.my);
                    buf.writeVarInt(value.mz);
                    buf.writeUtf(value.mdim, 128);
                    buf.writeBoolean(value.cell);
                }, buf -> new TemPadMenuActionPayload(
                        buf.readVarInt(), buf.readVarInt(), buf.readVarLong(),
                        buf.readVarInt(), buf.readBoolean(), buf.readUtf(64),
                        buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readUtf(128),
                        buf.readBoolean()));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}