package com.tvatech.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Framed pictures on the Authority's walls.
 *
 * <p>Floor plans, wiring diagrams, the mark on the gate. One block with a
 * choice of artwork, hung in the Vault so there is something to look at while
 * you walk around, and the same artwork reproduced in the field manual.</p>
 *
 * <p>It has no item on purpose: these are part of the building, not something
 * you carry off the wall.</p>
 */
public class TvaPictureBlock extends Block {

    /** Which picture this is. */
    public static final IntegerProperty ART = IntegerProperty.create("art", 0, 5);

    public TvaPictureBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(getStateDefinition().any().setValue(ART, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ART);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos,
                               CollisionContext context) {
        // A picture is thin. A full cube would make every corridor feel narrow.
        return Shapes.block();
    }
}
