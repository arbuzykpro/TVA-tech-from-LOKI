package com.tvatech.system;

import net.minecraft.server.level.ServerLevel;

/**
 * Reads and writes the world clock.
 *
 * <p>On 1.21.1 the clock is the plain level day time: tick 0 of the day is
 * 06:00, tick 6000 is noon and 12000 is 18:00. {@link ServerLevel#getDayTime()}
 * reads it and {@link ServerLevel#setDayTime(long)} writes it.</p>
 */
public final class WorldTime {

    private WorldTime() {}

    public static final int TICKS_PER_DAY = 24000;

    /** Current clock as {@code [day, hour24, minute]}. */
    public static long[] now(ServerLevel level) {
        long ticks = level.getDayTime();
        long day = Math.floorDiv(ticks, TICKS_PER_DAY);
        long timeOfDay = Math.floorMod(ticks, TICKS_PER_DAY);
        return new long[]{day, tickToHour(timeOfDay), minuteOf(timeOfDay)};
    }

    /** Tick 0 is 06:00, so shift by six hours. */
    public static long tickToHour(long timeOfDay) {
        return Math.floorMod(Math.floorDiv(timeOfDay, 1000) + 6, 24);
    }

    public static long minuteOf(long timeOfDay) {
        return Math.floorMod(timeOfDay, 1000) * 60 / 1000;
    }

    /** Converts a 24h clock reading into Minecraft's tick-of-day. */
    public static long hourToTick(int hour24) {
        return Math.floorMod(hour24 - 6, 24) * 1000L;
    }

    /**
     * Sets the local clock to a specific day and hour.
     *
     * <p>Arrival times are always on the hour: the TemPad's dial only moves in
     * whole hours, so the clock lands at {@code :00} rather than wherever the
     * world happened to be.</p>
     *
     * @param day   world day, 0-based (the "day 1 of the world" counter minus one)
     * @param hour  0-23
     */
    public static void setTime(ServerLevel level, long day, int hour) {
        long safeDay = Math.max(0, day);
        int safeHour = Math.floorMod(hour, 24);

        long ticks = safeDay * TICKS_PER_DAY + hourToTick(safeHour);
        level.setDayTime(ticks);
    }

    /** Shifts the clock by whole days, keeping the time of day. */
    public static void shiftDays(ServerLevel level, long days) {
        shiftHours(level, (int) (days * 24));
    }

    /** Shifts the clock by a number of hours. */
    public static void shiftHours(ServerLevel level, int hours) {
        if (hours == 0) {
            return;
        }
        level.setDayTime(level.getDayTime() + hours * 1000L);
    }

    /**
     * Pulls the clock forward by {@code extra} ticks in one go.
     *
     * <p>A time cell makes the world run twenty times faster while it holds
     * somebody; each natural tick, the cell adds the remaining nineteen.</p>
     */
    public static void fastForward(ServerLevel level, long extraTicks) {
        if (extraTicks <= 0) {
            return;
        }
        level.setDayTime(level.getDayTime() + extraTicks);
    }

    /**
     * The timeline's key for "right now": a running count of world hours.
     *
     * <p>Using hours rather than days means the world remembers the afternoon as
     * separate from the morning, so a build you knocked down at 2 pm can still be
     * found at 10 am the same day. Day 1 at midnight is 24.</p>
     */
    public static long hourIndex(ServerLevel level) {
        long[] now = now(level);
        return now[0] * 24L + now[1];
    }

    /** The hour index for a day and hour, without touching the clock. */
    public static long hourIndex(long day, int hour) {
        return Math.max(0, day) * 24L + Math.floorMod(hour, 24);
    }

    public static String format(long day, int hour) {
        int h = Math.floorMod(hour, 24);
        String suffix = h < 12 ? "AM" : "PM";
        int display = h % 12;
        if (display == 0) {
            display = 12;
        }
        return String.format("day %d \u00b7 %d %s", day, display, suffix);
    }
}
