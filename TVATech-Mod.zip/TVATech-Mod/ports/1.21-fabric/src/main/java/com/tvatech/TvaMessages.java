package com.tvatech;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Every piece of text the mod can show the player. */
public final class TvaMessages {

    private TvaMessages() {}

    private static final ChatFormatting ACCENT = ChatFormatting.AQUA;

    /**
     * Builds a prefixed "[TVA] " message.
     *
     * @param key translation key <b>without</b> the {@code tvatech.} namespace,
     *            which is added here
     */
    private static MutableComponent msg(String key, Object... args) {
        return Component.translatable("tvatech.text")
                .withStyle(ACCENT)
                .append(Component.translatable("tvatech." + key, args));
    }

    public static MutableComponent pinned(String coords) {
        return msg("message.pinned", coords);
    }

    public static MutableComponent noPin() {
        return msg("message.no_pin");
    }

    public static MutableComponent hopped(String coords) {
        return msg("message.hopped", coords);
    }

    public static MutableComponent travelDisabled() {
        return msg("message.travel_disabled");
    }

    public static MutableComponent doorOpened(int seconds) {
        return msg("message.door_opened", String.valueOf(seconds));
    }

    public static MutableComponent doorExpired() {
        return msg("message.door_expired");
    }

    public static MutableComponent doorClosed() {
        return msg("message.door_closed");
    }

    public static MutableComponent noRoomForDoor() {
        return msg("message.no_room_for_door");
    }

    public static MutableComponent markRenamed() {
        return msg("message.mark_renamed");
    }

    public static MutableComponent wrongDimension() {
        return msg("message.wrong_dimension");
    }

    public static MutableComponent outOfCharge() {
        return msg("message.out_of_charge");
    }

    public static MutableComponent cooldown(long ticks) {
        return msg("message.cooldown", String.format("%.1f", ticks / 20.0));
    }

    public static MutableComponent charged(int amount) {
        return msg("message.charged", amount);
    }

    public static MutableComponent alreadyCharged() {
        return msg("message.already_charged");
    }

    public static MutableComponent pruned(String entityName) {
        return msg("message.pruned", entityName);
    }

    public static MutableComponent pruningDisabled() {
        return msg("message.pruning_disabled");
    }

    public static MutableComponent scanned(String entityName, int variant) {
        return msg("message.scanned", entityName, variant);
    }

    public static MutableComponent scannerTagged(String entityName, int variant) {
        return msg("message.tagged", entityName, variant);
    }

    public static MutableComponent alreadyScanned(String entityName, int variant) {
        return msg("message.already_scanned", entityName, variant);
    }

    public static MutableComponent markMade(String count) {
        return msg("message.mark_made", count);
    }

    public static MutableComponent noMarkSelected() {
        return msg("message.no_mark");
    }

    public static MutableComponent holdTemPad() {
        return msg("message.hold_tempad");
    }

    public static MutableComponent arrivedTva() {
        return msg("message.tva");
    }

    public static MutableComponent returnedFromTva() {
        return msg("message.tva_return");
    }

    public static MutableComponent tvaUnavailable() {
        return msg("message.tva_unavailable");
    }

    public static MutableComponent nauseous() {
        return msg("message.nauseous");
    }

    public static MutableComponent alreadyTravelling() {
        return msg("message.already_travelling");
    }

    public static MutableComponent noTarget() {
        return msg("message.no_target");
    }

    public static MutableComponent noMobile() {
        return msg("message.no_mobile");
    }

    public static MutableComponent frozen(int count, int seconds) {
        return msg("message.frozen", count, String.format("%.0f", seconds));
    }

    public static MutableComponent freezeCooling(long ticks) {
        return msg("message.freeze_cooldown", String.format("%.1f", ticks / 20.0));
    }

    public static MutableComponent needsReactor() {
        return msg("message.needs_reactor");
    }

    public static MutableComponent anchorSet(String coords) {
        return msg("message.anchor_set", coords);
    }

    public static MutableComponent anchorCleared() {
        return msg("message.anchor_cleared");
    }

    public static MutableComponent doorToggled(boolean open) {
        return msg("message.door", open ? "open" : "closed");
    }

    public static MutableComponent unanchored(int variant) {
        return msg("message.unanchored", variant);
    }

    public static MutableComponent timelineHeader() {
        return msg("message.timeline_header");
    }

    public static MutableComponent prunedRespawn() {
        return msg("message.pruned_respawn");
    }

    public static MutableComponent yourVariant(int variant) {
        return msg("message.your_variant", variant);
    }
}